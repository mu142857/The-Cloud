"""第三章 · 结局三：云层星的风帆小镇 town + 晨暂住的小屋 town_room。

    "/Users/jiamulin/Desktop/程序programs/AI Oscar/.venv/bin/python" tools/cloud_town_art.py --sketch 目录   # 先出两张广场草图
    "/Users/jiamulin/Desktop/程序programs/AI Oscar/.venv/bin/python" tools/cloud_town_art.py [--preview 目录]

方向（作者定的）：风帆小镇。低矮的白色圆顶屋，屋顶和杆子上挂成排浅蓝半透明的布帆（都往右鼓：风从左来），几座风车；
喷泉靠风车带动的水车出水。粉白、淡蓝、麦黄。小镇坐在粉色云层上（作者 art/cloud/ 云海的粉紫，换成白天的亮色），
不在湿地上。和母星的灰色方楼、河流小镇的蓝色月夜石头房子都拉开。

光从左上来（太阳）。云：一团团圆鼓的云朵从后往前叠，每团按球面受光分档（亮顶偏暖、暗底偏丁香紫）。
晨脚下那一层（main 的云面、广场石砖）比背景压一档明度，晨一眼看得见。
所有随机固定 seed；alpha 只有 0/255，布帆和水是固定的半透明（SAIL_A / WATER_A）。不碰 art/手改清单.json 里的文件。
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "art" / "cloud_town"


# ======================================================================= 颜色
def hexc(s):
    s = s.lstrip("#")
    return np.array([int(s[i:i + 2], 16) for i in (0, 2, 4)], np.uint8)


# 天：上淡蓝 → 地平线一带粉、麦黄的暖光
SKY = ["#a8d3ee", "#b4d9f0", "#c1e0f2", "#cfe6f3", "#dcebf2", "#e8edf0", "#f2ebea", "#f8e5e1", "#fbe2d8", "#fbe6cf"]
# 云（粉）：亮 → 暗。0 是向阳的顶，5、6 是丁香紫的底
CLOUD = ["#fff8f4", "#fdeceb", "#f8dde3", "#f0cdd9", "#e5bccf", "#d6abc6", "#c59bba"]
# 白墙：亮 → 暗（暗面偏冷的丁香灰）
WHITE = ["#fffdf8", "#f8f1ec", "#ede2e3", "#dccfd8", "#cbbccb", "#b7a7bc"]
# 布帆（浅蓝）：亮 → 暗
SAIL = ["#e6f5fc", "#cdeaf8", "#b2dcf2", "#98cbe9", "#83badf"]
SAIL_A = 205
# 麦黄（风车顶、木头、长椅、篮子）：亮 → 暗
WHEAT = ["#fbe9b8", "#f3d690", "#e6bf6f", "#d0a35c", "#b58658", "#97705a"]
# 广场石砖（奶粉）：亮 → 暗，WET 是湿砖映的天
STONE = ["#f7ece8", "#eedfdc", "#e3d1d2", "#d4c0c6", "#c3aebb"]
WET = ["#e6f1f6", "#d2e6f1", "#bcd9ec"]
# 水
WATER = ["#eefafd", "#c9ecf8", "#a6dcf1", "#86c8e6"]
WATER_A = 215
# 门（淡蓝木门）、窗玻璃
DOOR = ["#bcdff2", "#9ccbe6", "#7fb3d6", "#6c9cc4"]
GLASS = ["#dff1fa", "#b6dcf0", "#93c4e3", "#7aaed5"]
# 花圃：花（粉、麦黄、白）、叶（嫩的灰绿）、土
FLOWER = ["#f7b9cb", "#ef9fb8", "#fbe3a0", "#f3cf72", "#fffaf4"]
LEAF = ["#cfe3b8", "#b5d3a0", "#9cc08f", "#86ab84"]
SOIL = ["#d8b49a", "#c49c88", "#ad8778"]

LIGHT = np.array([-0.55, -0.72, 0.42])
LIGHT = LIGHT / np.linalg.norm(LIGHT)


# ======================================================================= 画布
class Layer:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.a = np.zeros((h, w, 4), np.uint8)
        self.yy, self.xx = np.mgrid[0:h, 0:w]
        self.yy = self.yy + 0.5
        self.xx = self.xx + 0.5

    def put(self, mask, col, alpha=255):
        if isinstance(col, str):
            col = hexc(col)
        self.a[mask, :3] = col
        self.a[mask, 3] = alpha

    def px(self, x, y, col, alpha=255):
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            self.a[y, x, :3] = hexc(col) if isinstance(col, str) else col
            self.a[y, x, 3] = alpha

    def rect(self, x0, y0, x1, y1, col, alpha=255):
        x0, y0, x1, y1 = (int(round(v)) for v in (x0, y0, x1, y1))
        x0, y0 = max(x0, 0), max(y0, 0)
        if x1 > x0 and y1 > y0:
            self.a[y0:y1, x0:x1, :3] = hexc(col) if isinstance(col, str) else col
            self.a[y0:y1, x0:x1, 3] = alpha

    def over(self, other: "Layer", dx=0, dy=0):
        """other 叠在上面（other 的不透明像素盖住；半透明的照 alpha 混）"""
        h, w = other.h, other.w
        x0, y0 = max(dx, 0), max(dy, 0)
        x1, y1 = min(dx + w, self.w), min(dy + h, self.h)
        if x1 <= x0 or y1 <= y0:
            return
        src = other.a[y0 - dy:y1 - dy, x0 - dx:x1 - dx].astype(np.float32)
        dst = self.a[y0:y1, x0:x1].astype(np.float32)
        sa = src[..., 3:4] / 255.0
        da = dst[..., 3:4] / 255.0
        oa = sa + da * (1 - sa)
        rgb = np.where(oa > 0, (src[..., :3] * sa + dst[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6), 0)
        self.a[y0:y1, x0:x1, :3] = np.round(rgb).astype(np.uint8)
        self.a[y0:y1, x0:x1, 3] = np.round(oa[..., 0] * 255).astype(np.uint8)


def ellipse(L: Layer, cx, cy, rx, ry):
    return ((L.xx - cx) / rx) ** 2 + ((L.yy - cy) / ry) ** 2 <= 1.0


def poly_mask(L: Layer, pts):
    """多边形（偶奇规则，像素中心取样）"""
    pts = np.asarray(pts, np.float64)
    x, y = L.xx, L.yy
    inside = np.zeros((L.h, L.w), bool)
    n = len(pts)
    j = n - 1
    for i in range(n):
        xi, yi = pts[i]
        xj, yj = pts[j]
        cond = ((yi > y) != (yj > y))
        with np.errstate(divide="ignore", invalid="ignore"):
            xint = (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi
        inside ^= cond & (x < xint)
        j = i
    return inside


def line4(x0, y0, x1, y1):
    """四邻接的一像素线（拐角处补一格，错位时有边相连，不只是角碰角）"""
    x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
    dx, dy = abs(x1 - x0), abs(y1 - y0)
    sx = 1 if x1 > x0 else -1
    sy = 1 if y1 > y0 else -1
    x, y, ix, iy = x0, y0, 0, 0
    out = [(x, y)]
    while ix < dx or iy < dy:                              # 每一步只走一个方向 → 四邻接
        if dy == 0 or (dx > 0 and ix < dx and (0.5 + ix) / dx < (0.5 + iy) / dy):
            x += sx
            ix += 1
        else:
            y += sy
            iy += 1
        out.append((x, y))
    return out


def curve4(pts):
    """折线点串 → 四邻接像素（相邻点之间 line4）"""
    out = []
    for (a, b) in zip(pts[:-1], pts[1:]):
        seg = line4(a[0], a[1], b[0], b[1])
        if out and out[-1] == seg[0]:
            seg = seg[1:]
        out.extend(seg)
    return out


def stroke(L: Layer, pix, col, width=1, alpha=255):
    c = hexc(col) if isinstance(col, str) else col
    for (x, y) in pix:
        for k in range(width):
            L.px(x + k, y, c, alpha)


def band(v, cuts):
    """v 按 cuts（升序）分档：返回档号 0..len(cuts)"""
    return np.searchsorted(np.asarray(cuts), v)


def noise2(h, w, sx, sy, seed):
    """平滑噪声（双线性插值的随机格点），-1..1"""
    rng = np.random.default_rng(seed)
    gh, gw = int(h / sy) + 3, int(w / sx) + 3
    g = rng.uniform(-1, 1, (gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / sy, xx / sx
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty = ty * ty * (3 - 2 * ty)
    tx = tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return a * (1 - ty) + b * ty


# ======================================================================= 云
def lobe_light(L: Layer, cx, cy, rx, ry):
    nx = (L.xx - cx) / rx
    ny = (L.yy - cy) / ry
    r2 = nx * nx + ny * ny
    nz = np.sqrt(np.clip(1 - r2, 0, 1))
    return nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2], r2


def cloud(L: Layer, lobes, ramp, cuts=(-0.1, 0.25, 0.5, 0.72), bottom=None, offset=0, rimdark=True):
    """一团云：lobes = [(cx, cy, rx, ry), …] 从后往前画。每团按球面受光分档：亮 → ramp[offset]，越暗档号越大。
    bottom：平底（这一行以下不画）。rimdark：每团的下沿外圈压一档，团和团之间分得开。"""
    n = len(ramp)
    for (cx, cy, rx, ry) in lobes:
        m = ellipse(L, cx, cy, rx, ry)
        if bottom is not None:
            m &= L.yy < bottom
        if not m.any():
            continue
        lit, r2 = lobe_light(L, cx, cy, rx, ry)
        idx = len(cuts) - band(lit, cuts)            # 亮的档号小
        if rimdark:
            low = (r2 > 0.78) & (L.yy > cy)
            idx = np.where(low, idx + 1, idx)
        idx = np.clip(idx + offset, 0, n - 1)
        for k in range(n):
            mk = m & (idx == k)
            if mk.any():
                L.put(mk, ramp[k])


def cloud_row(rng, x0, x1, y, r_min, r_max, dy=3, flat=0.62):
    """一排云团（大小错落，上沿起伏），从后往前：先高的后低的"""
    lobes = []
    x = x0 - r_max
    while x < x1 + r_max:
        r = rng.uniform(r_min, r_max)
        lobes.append((x + r, y + rng.uniform(-dy, dy) - r * 0.25, r, r * flat))
        x += r * rng.uniform(0.9, 1.4)
    lobes.sort(key=lambda l: l[1])
    return lobes


# ======================================================================= 杂点清理
def despeckle(L: Layer, passes=3):
    """孤立的单像素（和上下左右四格颜色都不一样）→ 改成周围最多的那个颜色；孤立的不透明点 / 透明洞也补掉。"""
    a = L.a
    for _ in range(passes):
        key = (a[..., 0].astype(np.int64) << 24) | (a[..., 1].astype(np.int64) << 16) | (a[..., 2].astype(np.int64) << 8) | a[..., 3]
        k = np.pad(key, 1, mode="edge")
        c = k[1:-1, 1:-1]
        nb = [k[:-2, 1:-1], k[2:, 1:-1], k[1:-1, :-2], k[1:-1, 2:]]
        alone = np.ones_like(c, bool)
        for q in nb:
            alone &= q != c
        ys, xs = np.nonzero(alone)
        if len(ys) == 0:
            break
        P = np.pad(a, ((1, 1), (1, 1), (0, 0)), mode="edge")
        for y, x in zip(ys, xs):
            cand = [k[y, x + 1], k[y + 2, x + 1], k[y + 1, x], k[y + 1, x + 2]]
            vals, cnt = np.unique(cand, return_counts=True)
            best = vals[np.argmax(cnt)]
            for (yy, xx) in ((y, x + 1), (y + 2, x + 1), (y + 1, x), (y + 1, x + 2)):
                if k[yy, xx] == best:
                    a[y, x] = P[yy, xx]
                    break
    return L


def find_speckles(a):
    key = (a[..., 0].astype(np.int64) << 24) | (a[..., 1].astype(np.int64) << 16) | (a[..., 2].astype(np.int64) << 8) | a[..., 3]
    k = np.pad(key, 1, mode="constant", constant_values=-1)
    c = k[1:-1, 1:-1]
    alone = (a[..., 3] > 0)
    for q in (k[:-2, 1:-1], k[2:, 1:-1], k[1:-1, :-2], k[1:-1, 2:]):
        alone &= q != c
    return list(zip(*np.nonzero(alone)))


# ======================================================================= 白圆顶屋
def dome_house(L: Layer, x, base, w, wall_h, dome_h, door=None, windows=(), finial=True, shade_off=0):
    """低矮的白色圆顶屋：一圈白墙（圆柱受光：左亮右暗）+ 扁圆顶（球面受光）。返回圆顶的顶点 (cx, top)。
    door = (dx, dw, dh, 颜色档) 门在墙上的位置（相对 x）；windows = [(dx, dy, ww, wh), …]（dy 从墙顶往下）。"""
    cx = x + w / 2.0
    wall_top = base - wall_h
    m_wall = (L.xx >= x) & (L.xx < x + w) & (L.yy >= wall_top) & (L.yy < base)
    u = (L.xx - cx) / (w / 2.0)
    lit = -u * 0.85 + 0.25
    idx = np.clip(2 - band(lit, (-0.55, -0.05, 0.45)), 0, 3) + 1 + shade_off
    idx = np.clip(idx, 0, len(WHITE) - 1)
    for k in range(len(WHITE)):
        mk = m_wall & (idx == k)
        if mk.any():
            L.put(mk, WHITE[k])
    # 圆顶：半个椭圆，底宽 = 墙宽（底下是竖的切线，和墙接得顺，没有台阶）
    m_dome = ellipse(L, cx, wall_top + 0.5, w / 2.0, dome_h) & (L.yy < wall_top + 0.5)
    lit, r2 = lobe_light(L, cx, wall_top + 0.5, w / 2.0, dome_h)
    idx = np.clip(3 - band(lit, (-0.05, 0.3, 0.62)) + shade_off, 0, len(WHITE) - 1)
    for k in range(len(WHITE)):
        mk = m_dome & (idx == k)
        if mk.any():
            L.put(mk, WHITE[k])
    # 墙顶一道浅浅的阴影（圆顶的檐压在墙上），右边深一档
    sh = (L.yy >= wall_top + 0.5) & (L.yy < wall_top + 1.5) & m_wall
    L.put(sh & (L.xx < cx), WHITE[2 + shade_off])
    L.put(sh & (L.xx >= cx), WHITE[min(4, 3 + shade_off)])
    if door is not None:
        dx, dw, dh, dc = door
        arch_door(L, x + dx, base, dw, dh, dc)
    for (wx, wy, ww, wh) in windows:
        arch_window(L, x + wx, wall_top + wy, ww, wh)
    top = wall_top - dome_h
    if finial:
        fx = int(round(cx - 0.5))
        L.rect(fx, top - 2, fx + 1, top + 1, WHEAT[3])
        L.rect(fx - 1, top - 4, fx + 2, top - 2, WHEAT[1])
        L.px(fx + 1, top - 4, WHEAT[2])
        L.px(fx + 1, top - 3, WHEAT[2])
    return cx, top


def arch_door(L: Layer, x, base, w, h, palette=None):
    pal = palette or DOOR
    m = (L.xx >= x) & (L.xx < x + w) & (L.yy >= base - h + w / 2.0) & (L.yy < base)
    m |= ellipse(L, x + w / 2.0, base - h + w / 2.0, w / 2.0, w / 2.0) & (L.yy < base - h + w / 2.0 + 0.5)
    L.put(m, pal[1])
    # 门洞里的阴影：上沿和右边深一档（光从左上来）
    inner = m.copy()
    sh = m & ~np.roll(m, 1, axis=0)
    sh |= np.roll(sh, 1, axis=0) & m
    L.put(sh, pal[3])
    L.put(m & ~np.roll(m, -1, axis=1), pal[2])
    # 门板的竖缝（中间一道，连续）
    mid = int(x + w // 2)
    col = m[:, mid] & (L.yy[:, 0] > base - h + w / 2.0 + 1)
    L.a[col, mid, :3] = hexc(pal[2])
    # 门把手
    L.px(mid + 1, base - h // 2 + 1, WHEAT[2])
    # 门前一块浅影
    return inner


def arch_window(L: Layer, x, y, w, h):
    """拱窗：白框里一块玻璃（上浅下深，映着天），一道斜高光；不是实心色块"""
    w, h = int(w), int(h)
    r = w / 2.0
    m = (L.xx >= x) & (L.xx < x + w) & (L.yy >= y + r) & (L.yy < y + h)
    m |= ellipse(L, x + r, y + r, r, r) & (L.yy < y + r + 0.5)
    # 窗洞外圈压暗一圈（墙的厚度，右下）
    rim = np.roll(m, 1, axis=0) | np.roll(m, 1, axis=1)
    L.put(rim & ~m, WHITE[3])
    t = (L.yy - y) / max(h, 1)
    idx = np.clip(band(t, (0.3, 0.6, 0.85)), 0, 3)
    for k in range(4):
        L.put(m & (idx == k), GLASS[k])
    # 斜高光（两格，连着）
    hx_, hy = int(x + 1), int(y + r)
    L.px(hx_, hy + 1, GLASS[0])
    L.px(hx_, hy, GLASS[0])
    L.px(hx_ + 1, hy, GLASS[0])
    # 窗台：麦黄的一小条
    L.rect(x - 1, y + h, x + w + 1, y + h + 1, WHEAT[2])
    return m


# ======================================================================= 布帆
def jib(L: Layer, mx, top, bot, reach, bulge, lift=2, alpha=SAIL_A, dark=0):
    """桅杆上的三角帆，往右（顺风）鼓：前缘贴着桅杆（mx 右边一列），帆脚从桅杆往右，后缘外凸。"""
    head = np.array([mx + 1.0, top])
    tack = np.array([mx + 1.0, bot])
    clew = np.array([mx + 1.0 + reach, bot - lift])
    pts = [tuple(tack), tuple(head)]
    d = clew - head
    nrm = np.array([d[1], -d[0]]) / (np.linalg.norm(d) + 1e-9)
    for t in np.linspace(0, 1, 14)[1:]:
        p = head + d * t + nrm * bulge * math.sin(math.pi * t)
        pts.append(tuple(p))
    for t in np.linspace(0, 1, 6)[1:-1]:                 # 帆脚微微往下兜
        p = clew + (tack - clew) * t + np.array([0, 1.2 * math.sin(math.pi * t)])
        pts.append(tuple(p))
    m = poly_mask(L, pts) & (L.xx > mx + 1)
    u = (L.xx - (mx + 1)) / max(reach + bulge, 1)
    v = (L.yy - top) / max(bot - top, 1)
    s = u * 0.9 + v * 0.35
    idx = np.clip(band(s, (0.32, 0.62, 0.92)) + dark, 0, len(SAIL) - 1)
    for k in range(len(SAIL)):
        L.put(m & (idx == k), SAIL[k], alpha)
    return m


def mast(L: Layer, x, top, bot, col=None, w=1):
    L.rect(x, top, x + w, bot, col or WHEAT[3])
    L.px(x, top - 1, WHEAT[1])


def panel_rope(L: Layer, x0, y0, x1, y1, sag, panels, swing, rng, alpha=SAIL_A, rope_col=None):
    """两根杆之间一条下垂的绳子，绳上挂一排布帆（长方的布，下摆被风往右吹）。panels = [(位置 0..1, 宽, 长), …]"""
    xs = np.linspace(x0, x1, 40)
    ys = y0 + (y1 - y0) * (xs - x0) / (x1 - x0) + sag * np.sin(np.pi * (xs - x0) / (x1 - x0))
    rope = curve4(list(zip(xs, ys)))

    def rope_y(x):
        return y0 + (y1 - y0) * (x - x0) / (x1 - x0) + sag * math.sin(math.pi * (x - x0) / (x1 - x0))

    for (t, pw, ph) in panels:
        px0 = x0 + (x1 - x0) * t
        px1 = px0 + pw
        ya, yb = rope_y(px0) + 1, rope_y(px1) + 1
        sw = swing * ph / 14.0
        pts = [(px0, ya)]
        for k in range(1, 7):                              # 左边：顺风弯出去的一道弧
            f = k / 6
            pts.append((px0 + sw * f * f + 1.2 * math.sin(math.pi * f), ya + ph * f))
        for k in range(1, 6):                              # 下摆：微微兜
            f = k / 5
            pts.append((px0 + sw + pw * f, ya + ph + 0.8 * math.sin(math.pi * f) - (yb - ya) * 0 ))
        for k in range(1, 7):
            f = 1 - k / 6
            pts.append((px1 + sw * f * f + 1.6 * math.sin(math.pi * f), yb + ph * f))
        m = poly_mask(L, pts)
        u = (L.xx - px0 - sw * ((L.yy - ya) / ph) ** 2) / pw
        idx = np.clip(band(u, (0.34, 0.7)) + 1, 0, len(SAIL) - 1)
        for k in range(len(SAIL)):
            L.put(m & (idx == k), SAIL[k], alpha)
    stroke(L, rope, rope_col or WHEAT[4])
    return rope


# ======================================================================= 风车
def windmill_tower(L: Layer, cx, base, w, h, roof_h, door=True):
    """白色圆塔（下宽上窄一点，边每几行收一格），麦黄的尖草顶。返回转子中心。"""
    top = base - h
    half_b, half_t = w / 2.0, w / 2.0 - 2
    t = np.clip((base - L.yy) / h, 0, 1)
    half = half_b + (half_t - half_b) * t
    m = (np.abs(L.xx - cx) < half) & (L.yy >= top) & (L.yy < base)
    u = (L.xx - cx) / half
    lit = -u * 0.85 + 0.25
    idx = np.clip(3 - band(lit, (-0.55, -0.05, 0.45)), 0, 3) + 0
    for k in range(4):
        L.put(m & (idx == k), WHITE[k])
    # 草顶：低的圆锥，檐比塔宽 2 格，檐口往下弯
    rw = half_t + 3
    pts = [(cx - rw, top + 2), (cx - rw + 1, top), (cx - 2, top - roof_h + 1), (cx, top - roof_h),
           (cx + 2, top - roof_h + 1), (cx + rw - 1, top), (cx + rw, top + 2), (cx + rw - 3, top + 2.5), (cx - rw + 3, top + 2.5)]
    rm = poly_mask(L, pts)
    u = (L.xx - cx) / rw
    v = (L.yy - (top - roof_h)) / roof_h
    s = u * 0.8 + (1 - v) * -0.1
    idx = np.clip(band(s, (-0.45, 0.0, 0.42)), 0, 3)
    for k in range(4):
        L.put(rm & (idx == k), WHEAT[k + 1])
    # 草顶上几道顺坡的草纹（连续的斜线，不是点）
    for f in (-0.55, -0.15, 0.3):
        p = curve4([(cx + f * 2, top - roof_h + 3), (cx + f * rw * 0.95, top + 1)])
        for (x, y) in p:
            if rm[min(max(y, 0), L.h - 1), min(max(x, 0), L.w - 1)]:
                L.px(x, y, WHEAT[3] if f < 0 else WHEAT[4])
    if door:
        arch_door(L, int(cx - 3), base, 6, 10, [WHEAT[1], WHEAT[2], WHEAT[3], WHEAT[4]])
    arch_window(L, int(cx - 2), top + 9, 4, 6)
    return cx, top + 3


def rotor(size, ang, arms=8, r=None, hub=2, sail_frac=(0.22, 0.95), alpha=SAIL_A, thick=2):
    """风车的转子（正对着看）：arms 根木条 + 每根挂一面三角布帆（帆在木条的逆风那侧）。返回 Layer。"""
    L = Layer(size, size)
    c = size / 2.0
    r = r or (size / 2.0 - 1)
    for i in range(arms):
        a = ang + i * 2 * math.pi / arms
        ca, sa = math.cos(a), math.sin(a)
        a2 = a + 2 * math.pi / arms * 0.62
        p1 = (c + ca * r * sail_frac[0], c + sa * r * sail_frac[0])
        p2 = (c + ca * r * sail_frac[1], c + sa * r * sail_frac[1])
        p3 = (c + math.cos(a2) * r * 0.8, c + math.sin(a2) * r * 0.8)
        m = poly_mask(L, [p1, p2, p3])
        # 帆：靠木条那边亮，外角暗一档
        d = (L.xx - p1[0]) * ca + (L.yy - p1[1]) * sa
        idx = np.clip(band(d / r, (0.45,)), 0, 1) + 1
        L.put(m & (idx == 1), SAIL[1], alpha)
        L.put(m & (idx == 2), SAIL[2], alpha)
    for i in range(arms):
        a = ang + i * 2 * math.pi / arms
        p = line4(c - 0.5, c - 0.5, c - 0.5 + math.cos(a) * r, c - 0.5 + math.sin(a) * r)
        for (x, y) in p:
            L.px(x, y, WHEAT[3])
            if thick > 1:
                L.px(x + (1 if abs(math.sin(a)) > 0.7 else 0), y + (1 if abs(math.sin(a)) <= 0.7 else 0), WHEAT[4])
    hm = ellipse(L, c, c, hub + 0.6, hub + 0.6)
    L.put(hm, WHEAT[2])
    L.put(hm & (L.xx < c) & (L.yy < c), WHEAT[1])
    return L


# ======================================================================= 水车 / 喷泉
def waterwheel(size, ang, spokes=8, alpha=255):
    L = Layer(size, size)
    c = size / 2.0
    r = size / 2.0 - 2.5
    ring = ellipse(L, c, c, r, r) & ~ellipse(L, c, c, r - 2, r - 2)
    L.put(ring, WHEAT[3])
    L.put(ring & ((L.yy - c) * LIGHT[1] + (L.xx - c) * LIGHT[0] > 0), WHEAT[2])
    for i in range(spokes):
        a = ang + i * 2 * math.pi / spokes
        ca, sa = math.cos(a), math.sin(a)
        for (x, y) in line4(c - 0.5, c - 0.5, c - 0.5 + ca * (r - 1), c - 0.5 + sa * (r - 1)):
            L.px(x, y, WHEAT[4])
        # 桨板：轮缘外一小块
        bx, by = c + ca * (r + 1), c + sa * (r + 1)
        bm = ((L.xx - bx) * ca + (L.yy - by) * sa) ** 2 <= 2.3 ** 2
        bm &= (((L.xx - bx) * -sa + (L.yy - by) * ca) ** 2 <= 2.0 ** 2)
        L.put(bm, WHEAT[2])
        L.put(bm & (((L.xx - bx) * ca + (L.yy - by) * sa) > 0.8), WHEAT[3])
    hm = ellipse(L, c, c, 2.6, 2.6)
    L.put(hm, WHEAT[4])
    L.put(ellipse(L, c - 0.6, c - 0.6, 1.4, 1.4), WHEAT[2])
    return L


def fountain(L: Layer, cx, base, bw=86, bh=13, col_h=26, bowl_w=34):
    """喷泉（侧面看）：一圈矮的白石池壁 + 中间一根柱子托着上面的浅碗。返回 (上碗沿 y, 池沿 y)。"""
    x0 = cx - bw / 2.0
    rim_y = base - bh
    # 池壁：下面圆一点（两头圆角，不是直角），上沿一道亮边
    m = (L.xx >= x0) & (L.xx < x0 + bw) & (L.yy >= rim_y) & (L.yy < base)
    m &= ~((L.xx < x0 + 2) & (L.yy >= base - 2) & ((L.xx - (x0 + 2)) ** 2 + (L.yy - (base - 2)) ** 2 > 4))
    m &= ~((L.xx > x0 + bw - 2) & (L.yy >= base - 2) & ((L.xx - (x0 + bw - 2)) ** 2 + (L.yy - (base - 2)) ** 2 > 4))
    u = (L.xx - cx) / (bw / 2.0)
    idx = np.clip(2 - band(-u * 0.8 + 0.2, (-0.55, 0.0, 0.5)), 0, 3) + 1
    for k in range(len(WHITE)):
        L.put(m & (idx == k), WHITE[k])
    L.put(m & (L.yy < rim_y + 2), WHITE[0])
    L.put(m & (L.yy >= rim_y + 2) & (L.yy < rim_y + 3), WHITE[3])
    # 池壁上的一道浅浅的石缝（横的，连续）
    L.put(m & (L.yy >= base - 5) & (L.yy < base - 4) & (np.abs(L.xx - cx) < bw / 2.0 - 3), WHITE[3])
    # 柱子
    cm = (np.abs(L.xx - cx) < 3.5) & (L.yy >= rim_y - col_h) & (L.yy < rim_y)
    L.put(cm, WHITE[2])
    L.put(cm & (L.xx < cx - 1), WHITE[1])
    L.put(cm & (L.xx > cx + 1.5), WHITE[3])
    # 上碗：浅碗（下圆上平），碗沿一道亮
    by = rim_y - col_h
    bm = ellipse(L, cx, by, bowl_w / 2.0, 6) & (L.yy >= by)
    bm |= (np.abs(L.xx - cx) < 4.5) & (L.yy >= by + 5) & (L.yy < by + 9)
    lit, _ = lobe_light(L, cx, by, bowl_w / 2.0, 6)
    idx = np.clip(3 - band(lit, (-0.25, 0.15, 0.5)), 0, 4)
    for k in range(len(WHITE)):
        L.put(bm & (idx == k), WHITE[k])
    L.put(bm & (L.yy < by + 1.5), WHITE[0])
    return by, rim_y


def water_curtain(L: Layer, cx, top_y, rim_y, bowl_w, phase=0.0, alpha=WATER_A):
    """从上碗沿四周落下的水帘 + 碗顶一小股往上冒的水；phase 0..1 让亮纹往下流。"""
    hw = bowl_w / 2.0
    for side in (-1, 1):
        # 水帘：从碗沿外侧弯下来（抛物线），落到池里
        pts_out = []
        pts_in = []
        for k in range(16):
            f = k / 15
            yv = top_y + (rim_y - top_y) * f
            xo = cx + side * (hw + 1 + 7 * math.sqrt(f))
            xi = cx + side * (hw - 2 + 5 * math.sqrt(f))
            pts_out.append((xo, yv))
            pts_in.append((xi, yv))
        poly = pts_out + pts_in[::-1]
        m = poly_mask(L, poly)
        # 亮纹往下流
        s = (L.yy - top_y) / max(rim_y - top_y, 1) * 3.0 - phase * 1.0 + (L.xx * 0.13)
        fr = s - np.floor(s)
        idx = np.where(fr < 0.28, 0, np.where(fr < 0.6, 1, 2))
        for k in range(3):
            L.put(m & (idx == k), WATER[k + 0], alpha)
    # 碗里的水面（一条），碗顶冒起来的一小股
    wm = (np.abs(L.xx - cx) < hw - 1) & (L.yy >= top_y - 1) & (L.yy < top_y + 1)
    L.put(wm, WATER[1], alpha)
    h = 9 + 1.5 * math.sin(phase * 2 * math.pi)
    jm = ellipse(L, cx, top_y - h / 2.0, 2.2, h / 2.0 + 0.5)
    L.put(jm, WATER[0], alpha)
    L.put(jm & (L.xx > cx + 0.5), WATER[1], alpha)


# ======================================================================= 远近：天、云海、远处的小镇
def mix(c1, c2, t):
    a, b = hexc(c1).astype(float), hexc(c2).astype(float)
    v = np.round(a * (1 - t) + b * t).astype(int)
    return "#%02x%02x%02x" % tuple(v)


def haze(ramp, t, to="#f3e6ea"):
    return [mix(c, to, t) for c in ramp]


def draw_sky(w=480, h=270, horizon=150, seed=1):
    """天：横向色带（上淡蓝 → 地平线粉、麦黄），带边缓缓起伏；左上一团很淡的太阳光。钉在屏幕上（scroll 0）。"""
    L = Layer(w, h)
    nz = noise2(h, w, 70, 9, seed) * 2.2
    t = (L.yy + nz) / horizon
    t = np.clip(t, 0, 1.2)
    idx = np.clip((t ** 1.15 * (len(SKY) - 1) + 0.5).astype(int), 0, len(SKY) - 1)
    for k in range(len(SKY)):
        L.put(idx == k, SKY[k])
    # 太阳光：左上一圈圈很淡的亮（两档）
    sx, sy = 92, 52
    d = np.sqrt(((L.xx - sx) / 1.35) ** 2 + (L.yy - sy) ** 2) + nz * 0.8
    L.put((d < 46) & (idx <= 4), mix(SKY[2], "#fff6e6", 0.45))
    L.put((d < 30), mix(SKY[2], "#fffbf2", 0.75))
    L.put((d < 15), "#fffdf6")
    return L


def draw_far_towers(L: Layer, rng, items, ramp):
    """地平线上几座远远的积云塔（作者云海里那种一层层堆高的云，白天是粉白的）"""
    for (cx, base, wdt, hgt) in items:
        lobes = []
        y = base
        r = wdt / 2.0
        while y > base - hgt:
            n = max(1, int(r / 6))
            for i in range(n):
                lobes.append((cx + rng.uniform(-r * 0.7, r * 0.7), y - rng.uniform(0, 4), r * rng.uniform(0.45, 0.7), r * rng.uniform(0.3, 0.42)))
            y -= r * 0.32
            r *= 0.9
        lobes.sort(key=lambda l: -l[1])
        lobes = lobes[::-1]
        cloud(L, sorted(lobes, key=lambda l: l[1]), ramp, bottom=base + 2)


def draw_cloud_sea(w, y0, rows, seed, hz):
    """云海：一排排圆鼓的云顶，越远越小越淡（hz：往天色混多少）。rows = [(y, r_min, r_max, 混色), …] 从远到近。"""
    L = Layer(w, 270)
    rng = np.random.default_rng(seed)
    for (y, rmin, rmax, t) in rows:
        lobes = cloud_row(rng, 0, w, y, rmin, rmax, dy=2.5, flat=0.55)
        cloud(L, lobes, haze(CLOUD, t), bottom=270)
    return L


# ======================================================================= 地面：云台 + 广场
def cloud_ground(L: Layer, x0, x1, surf_top, front_y, seed, press=1):
    """晨走的那层云台：上面一条平缓的云面（远处亮、晨脚下压一档），前沿一排滚下去的云团（画面下沿）。"""
    rng = np.random.default_rng(seed)
    nz = noise2(L.h, L.w, 60, 6, seed + 3) * 2.0
    # 云面：从后往前分档
    m = (L.xx >= x0) & (L.xx < x1) & (L.yy >= surf_top)
    t = (L.yy + nz - surf_top) / max(front_y - surf_top, 1)
    idx = np.clip(band(t, (0.12, 0.42, 0.78)) + press, 0, len(CLOUD) - 1)
    for k in range(len(CLOUD)):
        L.put(m & (idx == k), CLOUD[k])
    # 云面上几道横着的软起伏（亮一档的长条，边是噪声，不是直线）
    for _ in range(int((x1 - x0) / 70)):
        cx = rng.uniform(x0, x1)
        cy = rng.uniform(surf_top + 6, front_y - 6)
        e = ellipse(L, cx, cy, rng.uniform(26, 60), rng.uniform(1.6, 2.6)) & m
        k = int(np.clip(band((cy - surf_top) / max(front_y - surf_top, 1), (0.12, 0.42, 0.78)) + press - 1, 0, 6))
        L.put(e, CLOUD[k])
    # 前沿：一排云团
    lobes = cloud_row(rng, x0, x1, front_y + 6, 9, 18, dy=2, flat=0.62)
    cloud(L, lobes, CLOUD, bottom=L.h, offset=press + 1)


def pavement(L: Layer, x0, x1, y0, y1, seed):
    """广场石砖：横着一排排（越往前一排越高一点），砖缝连续；砖与砖之间深浅差一档。返回石砖区域的 mask。"""
    rng = np.random.default_rng(seed)
    nz = noise2(L.h, L.w, 30, 30, seed) * 3
    # 两头不是直边：软软地收进云里（左右各一道圆弧）
    m = (L.yy >= y0) & (L.yy < y1)
    mid = (y0 + y1) / 2.0
    hw = (y1 - y0) / 2.0
    ex = np.sqrt(np.clip(1 - ((L.yy - mid) / (hw + 2)) ** 2, 0, 1)) * 10
    m &= (L.xx >= x0 + 10 - ex + nz * 0.5) & (L.xx < x1 - 10 + ex + nz * 0.5)
    L.put(m, STONE[1])
    rows = []
    y = y0
    hgt = 4
    while y < y1:
        rows.append((y, min(y + hgt, y1)))
        y += hgt + 1
        hgt = min(hgt + 1, 7)
    for (ya, yb) in rows:
        x = x0 - rng.uniform(0, 14)
        while x < x1:
            wdt = rng.uniform(10, 20) + (yb - ya) * 0.8
            tm = m & (L.yy >= ya) & (L.yy < yb) & (L.xx >= x) & (L.xx < x + wdt - 1)
            k = rng.choice([0, 1, 1, 1, 2, 2])
            L.put(tm, STONE[k])
            vj = m & (L.yy >= ya) & (L.yy < yb) & (L.xx >= x + wdt - 1) & (L.xx < x + wdt)
            L.put(vj, STONE[3])
            x += wdt
        hj = m & (L.yy >= yb) & (L.yy < yb + 1)
        L.put(hj, STONE[3])
    return m


def reflect_onto(L: Layer, area, objs, seed, strength=0.42):
    """湿石砖：objs = [(Layer, 底边 y), …] 每件东西按自己的底边倒过来映在石砖上（往下越远越淡、按行轻轻错位）；
    再在几处水洼里映天。混完收进石砖 + 湿色的小调色板里，不出碎色。"""
    H, W = L.h, L.w
    refl = np.zeros((H, W, 4), np.float32)
    rng = np.random.default_rng(seed)
    wob = np.round(noise2(H, 1, 1, 3, seed)[:, 0] * 1.4).astype(int)
    for (O, base) in objs:
        for y in range(int(base), H):
            sy = int(2 * base - y - 1)
            if sy < 0:
                continue
            fade = max(0.0, 1 - (y - base) / 26.0)
            row = np.roll(O.a[sy].astype(np.float32), wob[y], axis=0)
            a = row[:, 3:4] / 255.0 * fade
            refl[y, :, :3] = row[:, :3] * a + refl[y, :, :3] * (1 - a)
            refl[y, :, 3:4] = a + refl[y, :, 3:4] * (1 - a)
    base_rgb = L.a[..., :3].astype(np.float32)
    a = refl[..., 3:4] * strength
    out = base_rgb * (1 - a) + refl[..., :3] * a
    # 水洼：几块扁的，映天的淡蓝
    pud = np.zeros((H, W), bool)
    ys, xs = np.nonzero(area)
    if len(ys):
        for _ in range(int(area.sum() / 900)):
            i = rng.integers(len(ys))
            pud |= ellipse(L, xs[i], ys[i], rng.uniform(10, 26), rng.uniform(1.6, 2.8))
    pud &= area
    out[pud] = out[pud] * 0.45 + hexc(WET[1]).astype(np.float32) * 0.55
    pal = [hexc(c).astype(np.float32) for c in STONE + WET + [mix(s, c, 0.4) for s in STONE[:3] for c in (SAIL[1], WHEAT[1], WHITE[0])]]
    pal = np.array(pal)
    sel = area
    d = ((out[sel][:, None, :] - pal[None]) ** 2).sum(-1)
    L.a[sel, :3] = pal[np.argmin(d, axis=1)].astype(np.uint8)
    L.a[sel, 3] = 255


def bench(L: Layer, x, base, w=26):
    """长椅（侧面）：麦黄的木条座面 + 靠背，两条白石腿"""
    seat = base - 12
    for lx in (x + 3, x + w - 6):
        L.rect(lx, seat + 2, lx + 3, base, WHITE[2])
        L.rect(lx + 2, seat + 2, lx + 3, base, WHITE[3])
    L.rect(x, seat, x + w, seat + 2, WHEAT[2])
    L.rect(x, seat, x + w, seat + 1, WHEAT[1])
    # 靠背：两根细柱 + 一条横板
    for lx in (x + 4, x + w - 5):
        L.rect(lx, seat - 8, lx + 1, seat, WHEAT[3])
    L.rect(x + 1, seat - 9, x + w - 1, seat - 6, WHEAT[2])
    L.rect(x + 1, seat - 9, x + w - 1, seat - 8, WHEAT[1])
    # 椅下的影子
    L.rect(x + 1, base, x + w - 1, base + 1, STONE[3])


def tuft(L: Layer, x0, x1, base, rng, ramp=CLOUD, r=(4, 8), offset=1):
    """房子 / 风车脚下的一圈小云团（把底边埋进云里：坐在云上，不是悬着）"""
    lobes = cloud_row(rng, x0, x1, base + 1, r[0], r[1], dy=1.2, flat=0.6)
    cloud(L, lobes, ramp, bottom=base + 4, offset=offset)


# ======================================================================= 草图（广场那一屏，480×270）
def far_islands(L: Layer, rng, items, t):
    """远处的云岛：一小团云 + 上面几个小白点圆顶、细杆小帆（很淡）"""
    ramp = haze(CLOUD, t)
    wr = haze(WHITE, t)
    for (cx, base, wdt) in items:
        lobes = cloud_row(rng, cx - wdt / 2, cx + wdt / 2, base, 3, 7, dy=1.2, flat=0.6)
        cloud(L, lobes, ramp, bottom=base + 5)
        x = cx - wdt / 2 + 4
        while x < cx + wdt / 2 - 8:
            dw = int(rng.integers(5, 9))
            m = ellipse(L, x + dw / 2, base - 2, dw / 2, dw * 0.45) & (L.yy < base - 1)
            m |= (L.xx >= x) & (L.xx < x + dw) & (L.yy >= base - 3) & (L.yy < base)
            L.put(m, wr[1])
            L.put(m & (L.xx >= x + dw * 0.6), wr[3])
            x += dw + rng.integers(1, 5)


def mid_town(L: Layer, rng, x0, x1, base, t, n_mills=1, mills_at=(), houses=None):
    """中景的云丘 + 一簇小白顶屋（比主层小、淡一点）。返回风车转子的位置（给动画用）"""
    ramp = haze(CLOUD, t)
    lobes = cloud_row(rng, x0, x1, base + 4, 10, 20, dy=3, flat=0.55)
    cloud(L, lobes, ramp, bottom=L.h)
    rot = []
    return rot


def sketch(variant: str):
    W, H = 480, 270
    rng = np.random.default_rng(7 if variant == "a" else 11)
    img = draw_sky(W, H, horizon=150)
    # 地平线上远远的积云塔
    far = Layer(W, H)
    draw_far_towers(far, rng, [(400, 150, 70, 60), (330, 150, 34, 26), (40, 150, 40, 22)], haze(CLOUD, 0.55, "#f6e8ec"))
    img.over(far)
    sea = draw_cloud_sea(W, 150, [(150, 4, 8, 0.62), (156, 5, 10, 0.5), (164, 7, 13, 0.38)], 3, 0.5)
    img.over(sea)
    isl = Layer(W, H)
    far_islands(isl, rng, [(70, 160, 70), (200, 158, 50), (440, 162, 60)], 0.45)
    img.over(isl)

    # ---------------- 中景（一簇小屋 + 一座小风车）
    mid = Layer(W, H)
    hz = 0.22
    lobes = cloud_row(rng, -20, W + 20, 190, 12, 24, dy=4, flat=0.5)
    cloud(mid, lobes, haze(CLOUD, hz), bottom=H)
    WH = WHITE
    for (hx, hb, hw, wh, dh) in ([(14, 184, 20, 8, 7), (40, 182, 14, 6, 5), (300, 183, 22, 8, 8), (330, 185, 16, 6, 6), (440, 184, 26, 9, 9)]
                                 if variant == "a" else
                                 [(230, 182, 22, 8, 8), (258, 184, 16, 6, 6), (380, 183, 24, 9, 8), (410, 185, 14, 6, 5), (452, 183, 20, 8, 7)]):
        cx_, top = dome_house(mid, hx, hb, hw, wh, dh, door=None, windows=[(hw // 2 - 1, 2, 3, 4)], finial=False, shade_off=0)
        mast(mid, int(cx_), top - 14, top + 1)
        jib(mid, int(cx_), top - 13, top - 2, 8, 2.2)
    for (mx, mb) in ([(100, 186)] if variant == "a" else [(330, 186)]):
        windmill_tower(mid, mx, mb, 10, 26, 6, door=False)
        rl = rotor(26, 0.3, r=12, thick=1)
        mid.over(rl, int(mx - 13), int(mb - 26 + 3 - 13))
    tuft(mid, 0, W, 186, rng, haze(CLOUD, hz), r=(3, 6), offset=1)
    # 中景压一层薄薄的空气（整体往天色混一点）
    m = mid.a[..., 3] > 0
    mid.a[m, :3] = np.round(mid.a[m, :3] * 0.86 + hexc("#f4e8ee") * 0.14).astype(np.uint8)
    img.over(mid)

    # ---------------- 主层
    main = Layer(W, H)
    objs = []
    # 后面一道云丘（房子背后）
    back = cloud_row(rng, -20, W + 20, 206, 14, 26, dy=4, flat=0.5)
    cloud(main, back, CLOUD, bottom=H, offset=0)
    cloud_ground(main, 0, W, 204, 244, 5, press=1)
    if variant == "a":
        area = pavement(main, 70, 430, 208, 242, 9)
    else:
        area = pavement(main, 150, 480 + 40, 208, 242, 9)

    def house(hx, hb, hw, wh, dh, door, wins, sails=()):
        O = Layer(W, H)
        cx_, top = dome_house(O, hx, hb, hw, wh, dh, door=door, windows=wins)
        for (ofs, hgt, reach) in sails:
            mx = int(cx_) + ofs
            mast(O, mx, top - hgt, top + 2)
            jib(O, mx, top - hgt + 1, top - 3, reach, reach * 0.22)
        tuft(O, hx - 4, hx + hw + 4, hb, rng)
        main.over(O)
        objs.append((O, hb + 2))
        return cx_, top

    if variant == "a":
        house(40, 205, 30, 14, 12, (10, 7, 12, None), [(3, 4, 4, 6)], sails=[(0, 26, 16)])
        h1 = house(-6, 209, 56, 24, 18, (34, 9, 15, None), [(8, 6, 5, 8), (22, 6, 5, 8)], sails=[(0, 34, 22)])
        h2 = house(68, 210, 34, 16, 12, (8, 7, 12, None), [(21, 4, 4, 6)])
        # 风车 + 水车 + 喷泉
        O = Layer(W, H)
        mcx, mty = windmill_tower(O, 286, 207, 26, 60, 13)
        tuft(O, 268, 304, 207, rng)
        main.over(O)
        objs.append((O, 209))
        h4 = house(330, 209, 40, 18, 14, (6, 8, 13, None), [(26, 5, 5, 7)], sails=[(2, 28, 18)])
        h5 = house(378, 211, 62, 26, 20, (40, 9, 15, None), [(8, 7, 5, 8), (24, 7, 5, 8)], sails=[(-8, 40, 24), (10, 30, 18)])
        h6 = house(446, 207, 40, 16, 13, None, [(10, 4, 5, 7)])
        # 一排帆（左簇屋顶两根桅杆之间，右簇两根之间）
        S = Layer(W, H)
        panel_rope(S, 23, 156, 56, 170, 4, [(0.1, 8, 11), (0.42, 8, 12), (0.72, 7, 10)], 3, rng)
        panel_rope(S, 401, 143, 470, 168, 6, [(0.06, 9, 13), (0.3, 10, 14), (0.55, 9, 13), (0.78, 8, 11)], 3, rng)
        main.over(S)
        # 风车带水车：转子在塔顶前面
        R = rotor(60, 0.25, r=28)
        main.over(R, int(mcx - 30), int(mty - 30))
        # 水车立在池子里（左边），池沿挡住下半
        fcx, fbase = 232, 225
        WW = waterwheel(40, 0.2)
        main.over(WW, 168, 182)
        # 风车到水车的长轴（在喷泉柱子后面）
        main.rect(188, 201, 276, 203, WHEAT[3])
        main.rect(188, 201, 276, 202, WHEAT[2])
        F = Layer(W, H)
        top_y, rim_y = fountain(F, fcx, fbase, bw=96, bh=12, col_h=22, bowl_w=34)
        # 木槽：水车顶 → 上碗
        trough = poly_mask(F, [(190, 181), (216, 189), (216, 192), (190, 184)])
        F.put(trough, WHEAT[2])
        F.put(trough & (F.yy > 182 + (F.xx - 190) * 0.3 + 1.5), WHEAT[3])
        water_curtain(F, fcx, top_y, rim_y, 34, phase=0.0)
        tw = poly_mask(F, [(191, 180), (217, 188), (217, 189.5), (191, 181.5)])
        F.put(tw, WATER[1], WATER_A)
        main.over(F)
        objs.append((F, fbase))
        benches = [(104, 228), (352, 228)]
    else:
        # B：风车在左边高一点的云丘上，水车贴着塔脚，一道木渠架在两根木腿上把水送到右边的喷泉；
        #    广场上空一张大帆篷（两根高桅杆之间），淡蓝的影子落在湿石砖上。
        hill = cloud_row(rng, 30, 170, 196, 16, 26, dy=2, flat=0.55)
        cloud(main, hill, CLOUD, bottom=H, offset=0)
        O = Layer(W, H)
        mcx, mty = windmill_tower(O, 92, 196, 28, 66, 14)
        tuft(O, 70, 116, 196, rng)
        main.over(O)
        objs.append((O, 198))
        house(6, 206, 44, 18, 14, (8, 8, 13, None), [(28, 5, 5, 7)], sails=[(0, 28, 18)])
        house(124, 206, 30, 14, 11, None, [(12, 4, 4, 6)])
        house(408, 208, 50, 22, 17, (30, 9, 15, None), [(8, 6, 5, 8)])
        house(452, 205, 40, 16, 12, None, [(8, 4, 4, 6)])
        R = rotor(64, 0.1, r=30)
        main.over(R, int(mcx - 32), int(mty - 32))
        WW = waterwheel(36, 0.2)
        main.over(WW, 106, 172)
        # 木渠：水车顶 → 喷泉上碗；两根木腿
        fcx, fbase = 300, 225
        F = Layer(W, H)
        top_y, rim_y = fountain(F, fcx, fbase, bw=100, bh=12, col_h=24, bowl_w=36)
        ch = poly_mask(F, [(122, 171), (280, 185), (280, 189), (122, 175)])
        F.put(ch, WHEAT[2])
        F.put(ch & (F.yy > 172 + (F.xx - 122) * (14 / 158) + 1.8), WHEAT[3])
        cw = poly_mask(F, [(123, 170), (281, 184), (281, 185.5), (123, 171.5)])
        F.put(cw, WATER[1], WATER_A)
        for lx, ly in ((170, 179), (226, 184)):
            F.rect(lx, ly, lx + 2, 210, WHEAT[3])
            F.rect(lx + 1, ly, lx + 2, 210, WHEAT[4])
        tuft(F, 160, 236, 210, rng, r=(3, 6))
        water_curtain(F, fcx, top_y, rim_y, 36, phase=0.0)
        # 槽口的一小股水落进上碗
        F.put(poly_mask(F, [(280, 185), (283, 185), (284, top_y), (281, top_y)]), WATER[0], WATER_A)
        main.over(F)
        objs.append((F, fbase))
        # 大帆篷：两根高桅杆，帆顺风往右兜
        for px_ in (190, 470):
            main.rect(px_, 96, px_ + 2, 214, WHEAT[3])
            main.rect(px_ + 1, 96, px_ + 2, 214, WHEAT[4])
            main.rect(px_ - 1, 93, px_ + 3, 96, WHEAT[1])
        S = Layer(W, H)
        top = [(192 + (470 - 192) * f, 100 + 10 * math.sin(math.pi * f)) for f in np.linspace(0, 1, 20)]
        bot = [(192 + (470 - 192) * f + 14 * math.sin(math.pi * f), 120 + 30 * math.sin(math.pi * f)) for f in np.linspace(1, 0, 20)]
        cm = poly_mask(S, top + bot)
        v = (S.yy - 100) / 50
        idx = np.clip(band(v + (S.xx - 192) / 278 * 0.4, (0.25, 0.55, 0.85)), 0, 3)
        for k in range(4):
            S.put(cm & (idx == k), SAIL[k], SAIL_A)
        # 篷边的绳：从篷角拉到桅杆
        stroke(S, curve4([(192, 100), (192, 120)]), WHEAT[4])
        main.over(S)
        benches = [(200, 228), (380, 228)]
        # 帆篷落在地上的影子（淡蓝，扁）
        shm = ellipse(main, 336, 233, 120, 7) & area
        main.a[shm, :3] = np.round(main.a[shm, :3] * 0.8 + hexc(SAIL[2]) * 0.2).astype(np.uint8)
    for (bx, bb) in benches:
        B = Layer(W, H)
        bench(B, bx, bb)
        main.over(B)
        objs.append((B, bb))
    reflect_onto(main, area & (main.yy > 210), objs, 21)
    # 前沿再压一排云团（盖住石砖的前沿，石砖软软地收进云里）
    lobes = cloud_row(rng, -10, W + 10, 252, 8, 16, dy=2, flat=0.6)
    cloud(main, lobes, CLOUD, bottom=H, offset=2)
    despeckle(main)
    img.over(main)
    return img


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sketch", default="")
    ap.add_argument("--preview", default="")
    args = ap.parse_args()
    if args.sketch:
        d = Path(args.sketch)
        d.mkdir(parents=True, exist_ok=True)
        for v in ("a", "b"):
            im = sketch(v)
            Image.fromarray(im.a, "RGBA").save(d / f"town_sketch_{v}.png")
            Image.fromarray(im.a, "RGBA").resize((W3 := 480 * 3, 270 * 3), Image.NEAREST).save(d / f"town_sketch_{v}_x3.png")
            print("草图:", d / f"town_sketch_{v}.png")
        return


if __name__ == "__main__":
    main()
