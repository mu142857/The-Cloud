extends Node2D
## 通用角色（河流篇的妮芙、阿汀、摊主，背景里走过的小人）：读 art/characters/<id>/<id>.json，格式见
## docs/river_rooms_contract.md 第 2 节。鹿、弥洛不用这个（各有自己的脚本）。
##
## 节点的 position = 脚底（踩在地面那一行下面一格，和晨一样：position.y = round(地面) + 1）。
## 帧时长：每个动作自己的 ms（默认 json 顶层 ms，再默认 100）；绝不加速，走得快慢只改移动速度。
## 找动作：anims[名字] → alias[名字] → GENERIC_ALIAS → idle（resolve 返回 "" 时由 story_runner 打 MISSING_ANIM）。
## 每个动作可选：then = 播完（不循环的）接哪段（坐下 → 坐着晃脚）；shadow = false 这段不画脚下的影子（跳上长椅以后）。
## forms：多套形态（妮芙 land / swim），每套里写的键覆盖顶层；没有图的那套 = 占位色块。
## hover / bob / bob_s（可选）：整只离地 hover 像素悬浮、上下浮 bob 像素（平滑正弦，bob_s 秒一圈，取整到像素，不改帧）。
## bob_top（可选，帧里的一行）：只有这一行以上往下点 bob 像素再回来，这行和下面不动（大嘴鸟蹲在自带的树桩上：头和身子轻轻起伏，
## 脚和树桩不动）。上半截画在下半截后面，往下压的那一行被脚挡住，不露缝、不改图。shadow_w（可选）：影子宽（默认 12）。
## no_flip（可选）：转身不翻图（奥斯卡的大象：一帧的大图，一翻就是闪现）。
## 缺图 / 没有 json：画 color 的竖条色块 + 名字（森林规矩：缺图不卡）。
## 跟随（story_runner 的 follow）：follow_to(x) 每帧给目标，弹簧追（先缓起再缓停），停下转向晨；走路动画帧速不变。

const CHEN_GD := preload("res://scripts/chen.gd")
## 11-04 作者「闪现」（--qa_live）：剧本催人走（WALK_HURRY 2.2 倍）和跟随追赶最快不超过这些（像素 / 秒）：
## 再快一帧就 6、7 像素，看着像瞬移（妮芙在家里下楼一帧 7 像素）。晨跑最快 225
const WALK_MAX := 200.0
const FOLLOW_MAX := 190.0   # 走坡 / 台阶：slope_k、STEP_V 和晨用同一套
const DIR := "res://art/characters/%s/"
const LOOP_ANIMS := ["idle", "walk", "talk", "swim"]
## 剧本里常见的动作名 → 通用的几个（json 里没有对应的就再往下退）
const GENERIC_ALIAS := {
	"hand": "give", "push": "give", "point": "point", "look": "idle", "hold": "hold", "read": "read", "write": "write",
	"nod": "nod", "laugh": "laugh", "smile": "laugh", "wave": "wave", "sit": "sit", "crouch": "crouch", "stand": "idle",
}
const PH_SIZE := Vector2i(12, 34)
const HOP_S := 0.36                    # 蹦一下多久
const HOP_H := 5.0                     # 蹦多高（像素）

var npc_id := ""
var cfg := {}                          # json 原样
var form := ""                         # 现在的形态（没有 forms = ""）
var cur := {}                          # 合并过的当前形态配置
var head := 40.0                       # 对话框锚点：脚底往上多少
var speed := 36.0
var facing := 1
var _hop_t := 0.0                      # 还要蹦多久（见 hop）
var shadow := true
var ground_fn: Callable                # func(x) -> 地面世界 y（走路时贴地；没有就 y 不变）
var spr: Sprite2D
var _top: Sprite2D                     # bob_top 的上半截（没有 bob_top = null）
var _shadow: Sprite2D
var _label: Label
var _label_on := false                 # 这套占位要写名字（在不在画面里另算，见 _keep_label_on_screen）
var _ph := false                       # 这套形态是占位色块
var _anim := "idle"
var _anim_def := {}
var _anim_t := 0.0
var _done := false
var _walk_x := NAN
var _walk_speed := 0.0
var _x := 0.0
var _vel := 0.0                         # 跟随的弹簧速度
var _talking := false
var _t := 0.0
var _tex_cache := {}


func setup(id: String) -> void:
	npc_id = id
	name = "Npc_" + id
	var art_id := "rabbit" if id.begins_with("rabbit_") else id
	var p := (DIR % art_id) + art_id + ".json"
	if FileAccess.file_exists(p):
		var j = JSON.parse_string(FileAccess.get_file_as_string(p))
		if j is Dictionary:
			cfg = j
		else:
			print("NPC_WARN %s: json 读不出来" % id)
	_shadow = Sprite2D.new()
	_shadow.texture = _shadow_tex()
	_shadow.offset = Vector2(-6, -1)
	_shadow.centered = false
	add_child(_shadow)
	spr = Sprite2D.new()
	spr.centered = false
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(spr)
	_label = Label.new()
	_label.add_theme_font_size_override("font_size", 8)
	_label.add_theme_font_override("font", ThemeDB.fallback_font)
	_label.add_theme_color_override("font_color", Color(0.9, 0.95, 1.0, 0.8))
	_label.position = Vector2(-16, -PH_SIZE.y - 12)
	_label.visible = false
	add_child(_label)
	var forms: Dictionary = cfg.get("forms", {})
	set_form(str(cfg.get("form", "land" if forms.has("land") else (forms.keys()[0] if not forms.is_empty() else ""))))


func has_form(f: String) -> bool:
	return (cfg.get("forms", {}) as Dictionary).has(f)


func set_form(f: String) -> void:
	form = f
	cur = cfg.duplicate()
	cur.erase("forms")
	var forms: Dictionary = cfg.get("forms", {})
	if forms.has(f) and forms[f] is Dictionary:
		for k in forms[f]:
			cur[k] = forms[f][k]
	head = float(cur.get("head", 40))
	speed = float(cur.get("speed", 36))
	var sheet := _sheet(str(cur.get("sheet", "")))
	_ph = sheet == null or not cur.has("frame")
	if _ph:
		var c := Color(str(cur.get("color", _ph_color())))
		spr.texture = _ph_tex(c)
		spr.hframes = 1
		spr.vframes = 1
		spr.frame = 0
		_label.text = npc_id + ("·" + f if f != "" else "")
		_label_on = shadow and npc_id != "niff"        # 背景走过的小人（shadow = false）占位不写名字；妮芙有图，万一缺图也不写
		_label.visible = _label_on
	else:
		_label.visible = false
	var tint: bool = cur.get("tint", true)
	spr.modulate = Color(0.86, 0.87, 0.9) if tint else Color.WHITE
	play(_anim if _anim != "" else "idle", true)


## 占位的名字标签不出屏（11-06 --qa_live：芦苇地的大象站在画面边上，标签 elephant 出屏）：
## 方块还看得见就把标签挪回画面里，方块整个在画面外就不显示。
func _keep_label_on_screen() -> void:
	if not _label_on or not is_inside_tree():      # setup 时还没进树，拿不到镜头（下一帧 _process 再摆）
		return
	var ct := get_canvas_transform()
	var k := maxf(ct.x.x, 0.001)
	var left := -ct.origin.x / k
	var right := left + get_viewport_rect().size.x / k
	var gx := global_position.x
	_label.visible = gx + PH_SIZE.x / 2.0 > left and gx - PH_SIZE.x / 2.0 < right
	if _label.visible:
		_label.position.x = roundf(clampf(-16.0, left - gx + 2.0, right - gx - 2.0 - _label.get_minimum_size().x))      # 离屏幕边 2 像素


func _ph_color() -> String:
	match npc_id:
		"niff":
			return "#7fc6d6"
		"ting":
			return "#8a7a68"
		"keeper":
			return "#7d746a"
	return "#6d7680"


func _sheet(file: String) -> Texture2D:
	if file == "":
		return null
	if _tex_cache.has(file):
		return _tex_cache[file]
	var art_id := "rabbit" if npc_id.begins_with("rabbit_") else npc_id
	var p := file if file.begins_with("res://") else (DIR % art_id) + file
	var t: Texture2D = null
	if ResourceLoader.exists(p):
		t = load(p)
	elif FileAccess.file_exists(p):
		var img := Image.load_from_file(ProjectSettings.globalize_path(p))
		if img != null and not img.is_empty():
			t = ImageTexture.create_from_image(img)
	_tex_cache[file] = t
	return t


static func _ph_tex(c: Color) -> ImageTexture:
	var img := Image.create_empty(PH_SIZE.x, PH_SIZE.y, false, Image.FORMAT_RGBA8)
	img.fill(c)
	var d := c.darkened(0.3)
	for x in PH_SIZE.x:
		img.set_pixel(x, 0, d)
		img.set_pixel(x, PH_SIZE.y - 1, d)
	for y in PH_SIZE.y:
		img.set_pixel(0, y, d)
		img.set_pixel(PH_SIZE.x - 1, y, d)
	img.fill_rect(Rect2i(PH_SIZE.x - 5, 5, 2, 2), Color("#e8f0f4"))     # 眼睛：看得出朝哪边
	return ImageTexture.create_from_image(img)


static func _shadow_tex() -> ImageTexture:
	var img := Image.create_empty(12, 2, false, Image.FORMAT_RGBA8)
	img.fill_rect(Rect2i(1, 0, 10, 2), Color(0.02, 0.04, 0.05, 0.35))
	img.fill_rect(Rect2i(0, 0, 12, 1), Color(0.02, 0.04, 0.05, 0.35))
	return ImageTexture.create_from_image(img)


# ======================================================================= 动作
## 名字 → json 里真有的动作名（没有 = ""）
func resolve(n: String) -> String:
	var anims: Dictionary = cur.get("anims", {})
	if anims.has(n):
		return n
	var al: Dictionary = cur.get("alias", {})
	if al.has(n) and anims.has(str(al[n])):
		return str(al[n])
	for pre in GENERIC_ALIAS:
		if n.begins_with(pre) and anims.has(GENERIC_ALIAS[pre]):
			return str(GENERIC_ALIAS[pre])
	if form == "swim" and anims.has("swim") and n in ["idle", "walk"]:
		return "swim"
	return ""


func has_anim(n: String) -> bool:
	return resolve(n) != ""


## 播一个动作（没有就退回 idle）；返回有没有这个动作
func play(n: String, force := false) -> bool:
	var r := resolve(n)
	var ok := r != ""
	if not ok:
		r = resolve("idle")
	if r == _anim and not force and not _done:
		return ok
	_anim = r if r != "" else "idle"
	_anim_def = (cur.get("anims", {}) as Dictionary).get(_anim, {})
	_anim_t = 0.0
	_done = false
	_show_frame()
	return ok


func talk(on: bool) -> void:
	_talking = on
	if on and has_anim("talk") and _anim in ["idle", "swim", ""]:
		play("talk")
	elif not on and _anim == "talk":
		play("idle")


## 转身：json 写 "turn_fade": 秒 的（阿汀：奥斯卡的阴险守卫，背后的黑团子很大，一翻就整团从左跳到右）不硬翻，
## 留一个旧朝向的替身原地 4 档淡出、新朝向 4 档淡入（11-02 作者：阿汀翻转的动静巨大，很破坏氛围）
func face(dir: int) -> void:
	if dir == 0:
		return
	var nf := 1 if dir > 0 else -1
	if nf == facing:
		return
	var tf := float(cur.get("turn_fade", 0.0))
	if tf > 0.0 and visible and is_inside_tree() and spr != null and spr.texture != null:
		var g := spr.duplicate() as Sprite2D
		add_child(g)
		g.z_index = spr.z_index
		facing = nf
		_show_frame()
		var me := spr
		var tw := create_tween()
		tw.tween_method(func(k: float):
			var a := floorf(k * 4.0) / 4.0
			if is_instance_valid(me):
				me.modulate.a = a
			if is_instance_valid(g):
				g.modulate.a = 1.0 - a, 0.0, 1.0, tf)
		tw.tween_callback(func():
			if is_instance_valid(g):
				g.queue_free()
			if is_instance_valid(me):
				me.modulate.a = 1.0)
		return
	facing = nf
	_show_frame()


## story_runner 和鹿 / 弥洛用同一个名字转身
func _set_facing(dir: int) -> void:
	face(dir)


func walk_to(x: float, sp := -1.0) -> void:
	_walk_x = round(x)
	_walk_speed = sp if sp > 0.0 else speed
	_x = position.x
	face(1 if x > position.x else -1)


func is_walking() -> bool:
	return not is_nan(_walk_x)


func stop() -> void:
	_walk_x = NAN
	_vel = 0.0
	if _anim in ["walk", "swim"] or resolve("walk") == _anim:
		play("idle")


## 跟随：每帧给目标 x（弹簧追，欠阻尼一点点就停稳），dir_to = 停下以后朝哪看（晨的 x）
## w = 弹簧有多硬（默认 6：很快贴上）；跟着晨走用软一点的（story_runner.FOLLOW_W），起步慢、慢慢加速追上、到了慢慢停
func follow_to(tx: float, look_x: float, delta: float, w := 6.0) -> void:
	if is_walking():
		return
	var d := tx - position.x
	var acc := w * w * d - 2.0 * 0.9 * w * _vel
	var vmax := minf(speed * 2.2, FOLLOW_MAX)
	_vel = clampf(_vel + acc * delta, -vmax, vmax)
	if absf(d) < 1.0 and absf(_vel) < 4.0:
		_vel = 0.0
		if absf(look_x - position.x) > 2.0:
			face(1 if look_x > position.x else -1)
		if resolve(_anim) == resolve("walk") and _anim != resolve("idle"):
			play("idle")
		return
	if absf(_x - position.x) > 0.5:
		_x = position.x
	_x += _vel * delta * CHEN_GD.slope_k(ground_fn, position.x, signf(_vel))
	position.x = round(_x)
	_snap_walk(delta)
	if absf(_vel) > 6.0:
		face(1 if _vel > 0.0 else -1)
		play("walk")


## 走路 / 跟随时脚下地面一下子高一截、低一截：每秒最多 chen.gd 的 STEP_V 像素地跟过去（不一帧跳过去，11-04 --qa_live）
func _snap_walk(delta: float) -> void:
	var fr := Engine.get_process_frames()
	if int(get_meta("y_frame", -1)) == fr:
		return                                 # 一帧只落一次（跟随、让路、自己 _process 都会叫到）
	set_meta("y_frame", fr)
	if ground_fn.is_valid():
		var gy: float = round(float(ground_fn.call(position.x))) + 1.0
		position.y = round(move_toward(position.y, gy, maxf(CHEN_GD.STEP_V * delta, 1.0)))
		if absf(position.y - gy) >= 1.0:
			set_meta("y_lag", true)
		elif has_meta("y_lag"):
			remove_meta("y_lag")


func _snap_y() -> void:
	if ground_fn.is_valid():
		position.y = round(float(ground_fn.call(position.x))) + 1.0


## 原地蹦两下（剧本 anim hop；南桥妮芙跟着脚印走的时候）
func hop(times := 2) -> void:
	_hop_t = HOP_S * times


func _process(delta: float) -> void:
	_t += delta
	_hop_t = maxf(0.0, _hop_t - delta)
	if not is_nan(_walk_x):
		var d := _walk_x - position.x
		var step := minf(_walk_speed, WALK_MAX) * delta
		if absf(d) <= step:
			position.x = _walk_x
			_walk_x = NAN
			_snap_walk(delta)                  # 到了：脚下还差的那点高度接着慢慢落（_process 里 y_lag），不一帧补上
			play("talk" if _talking and has_anim("talk") else "idle")
		else:
			if absf(_x - position.x) > 0.5:
				_x = position.x
			_x += signf(d) * step * CHEN_GD.slope_k(ground_fn, position.x, signf(d))
			position.x = round(_x)
			_snap_walk(delta)
			play("walk")
	if is_nan(_walk_x) and has_meta("y_lag"):
		_snap_walk(delta)
	_anim_t += delta
	_show_frame()


func _show_frame() -> void:
	if spr == null:
		return
	var bob: float = -float(cur.get("hover", 0.0)) - roundf(float(get_meta("pass_lift", 0.0)))   # 浮着走过晨的时候从晨头顶飘过去（story_runner._pass_over）
	if _hop_t > 0.0:                       # 蹦两下：两段抛物线，只动画面不动脚下的位置
		var hu := fmod(_hop_t / HOP_S, 1.0)
		bob -= roundf(HOP_H * 4.0 * hu * (1.0 - hu))
	var amp := float(cur.get("bob", 0.0))
	if amp > 0.0:
		bob -= round(amp * (0.5 - 0.5 * cos(TAU * _t / maxf(float(cur.get("bob_s", 2.4)), 0.1))))
	if _ph:
		spr.offset = Vector2(-PH_SIZE.x / 2, -PH_SIZE.y + bob)
		spr.flip_h = facing < 0
		_shadow.visible = shadow
		_keep_label_on_screen()
		return
	var d: Dictionary = _anim_def
	var sheet := _sheet(str(d.get("sheet", cur.get("sheet", ""))))
	if sheet == null:
		return
	var fr: Vector2 = _v2(d.get("frame", cur.get("frame", [16, 16])))
	var an: Vector2 = _v2(d.get("anchor", cur.get("anchor", [fr.x / 2, fr.y - 1])))
	if spr.texture != sheet:
		spr.texture = sheet
	spr.hframes = maxi(int(sheet.get_width() / fr.x), 1)
	spr.vframes = maxi(int(sheet.get_height() / fr.y), 1)
	var frames: Array = d.get("frames", [0])
	if frames.is_empty():
		frames = [0]
	var ms := float(d.get("ms", cur.get("ms", 100)))
	var i := int(_anim_t * 1000.0 / maxf(ms, 1.0))
	var loop: bool = d.get("loop", _anim in LOOP_ANIMS)
	if loop:
		i = i % frames.size()
	elif i >= frames.size():
		i = frames.size() - 1
		if not _done:
			_done = true
			if d.has("then"):
				play(str(d["then"]), true)
				return
			if not d.get("hold", false):
				play("idle", true)
				return
	spr.frame = clampi(int(frames[i]), 0, spr.hframes * spr.vframes - 1)
	var faces = cur.get("faces", "right")
	var drawn_right := not (str(faces) == "left" or (faces is float and float(faces) < 0.0) or (faces is int and int(faces) < 0))
	spr.flip_h = (facing < 0) == drawn_right and not cur.get("no_flip", false)
	var ax := an.x if not spr.flip_h else fr.x - 1.0 - an.x
	spr.offset = Vector2(-ax, -an.y - 1.0 + bob)
	_shadow.visible = shadow and form != "swim" and d.get("shadow", true)
	_shadow.scale.x = 2.0 if cur.get("hover", 0.0) > 0.0 else 1.0      # 悬浮的鲸壳比人宽，影子拉宽一倍
	if cur.has("shadow_w"):
		_shadow.scale.x = float(cur["shadow_w"]) / 12.0
	_split_top(fr, ax, an.y)


## bob_top：同一帧切成上下两截（region），上半截往下点 0..bob 像素
func _split_top(fr: Vector2, ax: float, ay: float) -> void:
	var cut := int(cur.get("bob_top", 0))
	if cut <= 0 or cut >= int(fr.y):
		spr.region_enabled = false
		if _top != null:
			_top.visible = false
		return
	if _top == null:
		_top = Sprite2D.new()
		_top.centered = false
		_top.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		add_child(_top)
		move_child(_top, spr.get_index())      # 画在下半截后面
	var f := spr.frame
	var cell: Vector2 = Vector2(f % spr.hframes, floori(float(f) / float(spr.hframes))) * fr
	var dip := roundf(float(cur.get("bob", 0.0)) * (0.5 - 0.5 * cos(TAU * _t / maxf(float(cur.get("bob_s", 2.4)), 0.1))))
	var y0 := -ay - 1.0 - float(cur.get("hover", 0.0))
	spr.hframes = 1
	spr.vframes = 1
	spr.frame = 0
	spr.region_enabled = true
	spr.region_rect = Rect2(cell + Vector2(0, cut), Vector2(fr.x, fr.y - cut))
	spr.offset = Vector2(-ax, y0 + cut)
	_top.texture = spr.texture
	_top.modulate = spr.modulate
	_top.flip_h = spr.flip_h
	_top.region_enabled = true
	_top.region_rect = Rect2(cell, Vector2(fr.x, cut))
	_top.offset = Vector2(-ax, y0 + dip)
	_top.visible = true


static func _v2(v) -> Vector2:
	if v is Array and (v as Array).size() >= 2:
		return Vector2(float(v[0]), float(v[1]))
	return Vector2(16, 16)
