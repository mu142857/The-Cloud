extends Node2D
## 第一关：木星的森林。开场、标题、坠毁、捡起第一块发光木头，然后整个森林章节由剧本引擎接着播到飞船起飞。
##
## 章节剧情：scripts/story_runner.gd（读 data/story_forest.json，见 docs/forest_chapter.md）。这里只负责：
##   开场 / 标题 / 坠毁 / 木头拾取过场（原来的），晨爬起来以后播剧本的 intro，木头过场里播剧本 at = wood 的那个 scene；
##   自由走的时候：hotspot 互动（E / 空格 / 回车 / 点那个东西）、走进 trigger:"enter" 的点自动触发、左右不可见的墙；
##   剧情播放时锁晨、把按键转给对话框；树屋室内镜头固定；背包里所有物品 + 日记；上船（_board_ship：绕到船后从另一侧舱门进去）；
##   起飞过场（story_takeoff：预热 → 反重力离地、土留在原地 → 悬停 → 沿机头方向 ease-in 飞走）；剧本让镜头停住 / 移动（camera_*）；章节结束卡。
## 开场一起坠毁的外星人同伴（Alien）在森林里不出现（ALIEN_IN_FOREST = false，代码留着，以后河边用）。
##
## 流程（state）：
##   HEADPHONES  黑屏显示「建议佩戴耳机」，停留后自动继续。
##   INTRO       黑屏先听见清晰的雷雨，淡入云层小镇时雷雨慢慢变闷，云风淡入。
##   TITLE       标题界面：背景是云层小镇，游戏名、正中「开始游戏」、右下角设置齿轮；镜头慢慢左右漂
##   CRASH       点开始：画面往下落，穿过云层到全黑，再落就是森林（风和鸟叫交叉）。落到位接开场动画（上下黑边）：
##               三次闪电 + 近雷 → 冒烟的飞船从右上斜着坠下 → 撞地（震屏、尘土、浓烟）
##               → 晨和另一个外星人（梧桐画的旧主角，npc_alien.gd）先后被甩出来、脸朝下趴着 → 她先爬起来，晨再爬起来
##               （晨：真抛物线 + 角速度衰减的翻滚、落地弹一下滑一下扬尘轻震，见 _chen_thrown）
##               → 对话「啊……糟糕……」。确认键 / 点击按两次可以跳过。她之后一直站在残骸尾巴旁边待机（不说话）。
##   PLAY        自由走（←/→、A/D，或者鼠标点地面走过去）。发光木头上方有一个很轻的小箭头。
##   CINE        走到木头旁边：黑边滑入、锁操作、晨自己走到木头前捡起来 → 木头飞进背包 → 对话「太好了……」
##               → 燃烧值从 10 滚到 60，「燃烧值到 200 就能起飞」→ 收进左上角 → 黑边滑出、恢复操作
## 任何时候：Esc / 右下角齿轮 = 设置；Tab / B / I / 右上角背包图标 = 背包（捡到第一件东西以后才出现）。
## 章节结束卡出来 3 秒以后按任意键回标题（重新开始）。
## 只在 debug 构建：标题界面按 F1~F5 进 forest / river / underwater / cloud / flight 的测试场景，Esc 回标题（见 SceneBrowser）。
##
## 调试（命令行 -- 后面，建议加 --fixed-fps 60 让时间可重复）：
##   --stage=headphones|title|settings|crash|play|wood|bag   直接跳到某一段
##   --lang=zh|en       临时换语言（不存）
##   --quality=lite     临时换画质（不存）
##   --shot=绝对路径.png --shot_at=秒   这一段开始后多少秒存一张图后退出（默认 1 秒）
##   --shots=目录 --start=帧 --every=帧 --count=张   连拍 shot_000.png …
##   --win=宽x高        窗口改成这么大（不全屏），看不是 16:9 的窗口
##   --aspect=expand    临时把 stretch aspect 换成 expand（不留黑边，看镜头在房间上下外面能看到什么）
##   --autoplay         耳机提示自己跳过、标题界面自己点开始，能走的时候自己往右走（录 GIF / 完整跑一遍用）
##   --title_hot        标题界面的「开始」显示成悬停的样子（截图看悬停反馈用）
##   --browse=1..5 --browse_out=目录   标题界面 0.5 秒后自己按 F1..F5 进测试场景，2.5 秒后存 目录/scene.png、
##                      自己按 Esc 回标题，再过 2 秒存 目录/back.png 后退出（测场景浏览用；别同时给 --shot，测试场景自己也认它）
##   --story=路径       用哪份剧本（默认 data/story_forest.json，没有就 data/story_forest_sample.json）
##   --beat=flag名      直接跳到那个节拍（剧情瞬间过一遍到设这个 flag 的 scene 播完；flags、物品、NPC 位置都补齐）
##   --story_auto[=full]  自动玩整章到结束卡，打印 STORY_DONE 统计后退出（full = 闲聊、选错的分支也走）
##   --story_shots=目录   每播到一个新 scene 存一张图
##   --story_shot_delay=秒  每个 scene 开始后多久存图（默认 0.5）
##   --story_check      只检查剧本、打印 STORY_CHECK 后退出
##   --story_fuzz=秒 [--seed=n]  像人一样乱玩：随机按方向键（按住一会儿）、互动、确认、背包、Esc、乱点鼠标，玩这么多秒；
##                      一直检测「没有对话框、没有剧情在播、没有黑屏，但晨收不到输入超过 3 秒」→ 打印 SOFTLOCK 和当时的状态；
##                      剧情的某一步停了 20 秒以上、又没有对话框 / 点选 / 带路在等人 → STUCK_SCENE。结束打印 FUZZ_DONE。
##                      可以和 --beat 一起用（从某个节拍开始乱玩）
##   --hide=节点名,节点名  把这几个节点藏起来（查画面上某一层是谁用）
##   --dev [--dev_tab=0..3]（0 传送 1 状态 2 开关 3 探索）  一开始就打开 F12 面板（截图 / 测面板用）
##   F12（只在 debug 构建）：开发者面板（跳节拍、传送、状态、快走 / 跳过对话 / 显示范围 / 雾 / 前景层开关、重开本章……），
##                      见 scripts/dev_panel.gd 和 docs/forest_chapter.md 末尾
##   --chen_x=x         （和 --beat 一起）跳完以后让晨站到这个 x（截互动提示用）
##   --free=forest|river|reeds 直接进自由探索（F12 第 5 页「探索」同一套）。不播开场、剧情、对话、目标、卡关提示，剧情的墙不算，NPC 藏着；
##                      换地方的交互照常（E / 点击：进出屋、上下楼、市集 / 旧街 / 仓库 / 南桥，走到边上的出口），不看剧情 flag。
##                      拍截图也可以直接给房间名（treehouse / cockpit / river_home / market / oldstreet / warehouse / southbridge），
##                      和 --chen_x=x|left|mid|right、--shot= 一起用（面板不开；要开加 --dev）
##   --free_check [--free_shots=目录]  （和 --free=forest|river 一起）自测：按进出口把这一章走一遍（河岸 → 妮芙家 → 上楼 → 下楼 → 出门 →
##                      市集 → 旧街 → 仓库 → 回旧街 → 南桥 → 回旧街；森林 → 树屋段 → 树屋 → 出来 → 回旧路），每一步打印 FREE_TOUR，
##                      一路有没有对话 / 点选 / 目标 / 剧情 hotspot 出来过；给了目录就每一步存一张图。打印 FREE_CHECK 后退出
##                      --free_tour=market,river_bank 只走这几步（房间名 / up / down / edge:left|right）；
##                      --free_npcs 一开始就打开面板的「角色」
##   --open_bag=物品id [--bag_line=n]  （和 --beat 一起）跳完以后打开背包、选中这件，描述翻到第 n 行（截背包 / 日记用）
## 例：Godot --path . --fixed-fps 60 -- --stage=crash --shot=/tmp/a.png --shot_at=3.6
##     Godot --path . --fixed-fps 60 -- --story_auto --story_shots=/tmp/shots

enum S { HEADPHONES, INTRO, TITLE, CRASH, PLAY, CINE }

const LOOK := 36.0            # 镜头往晨面朝的方向多看多少像素（和 forest_test 一样）
const FOLLOW := 3.0
## 坠毁现场（船、晨、行李、碎片、左墙）整体往左挪了 960：到发光木头中间留一段什么都不能点的空林子（约 7 秒路）。
## 960 = Main 层和地面（chen.ground_y）的循环宽，所以坠毁那一屏的近景树干、光柱、地面起伏和原来一模一样。
## 剧本 story_forest.json 里坠毁现场的 markers（wreck、chen_start、treeline_gap、home_enter……）跟着一起挪了，改这里要一起改。
const CRASH_DX := -960.0
const TITLE_CAM_X := 236.0 + CRASH_DX    # 标题界面镜头中心；晨爬起来时镜头也在这
const CHEN_X := 250.0 + CRASH_DX         # 晨趴着的地方
const WRECK_X := 120.0 + CRASH_DX        # 坠毁飞船（锚点 = 船身中心的 x 和地面）
const ALIEN_X := 204.0 + CRASH_DX        # 另一个外星人（梧桐画的旧主角）趴着、站着的地方：残骸尾巴旁边，在晨左边，不挡去木头的路
const WOOD_X := 372.0         # 发光木头
const PICK_DIST := 26.0       # 晨走到离木头这么近就进入拾取过场
const LIE_LIFT := 9.0         # 没有 lie / getup 动画时的老办法：趴着时精灵往上抬几像素（转 90° 以后身体的厚度一半在地下）
const CHEN_GD := preload("res://scripts/chen.gd")
const STORY_GD := preload("res://scripts/story_runner.gd")
const ALIEN_IN_FOREST := false
const DEV_GD := preload("res://scripts/dev_panel.gd")
const TEXT_PAGE := preload("res://scripts/text_page.gd")
const DESC_C := Color("#b9c9bf")
const STRUCK_C := Color("#6f877b")
const KEEPSAKE_C := Color("#dcc39a")         # 背包里纪念品名字的暖色
const DEV_BEAT_META := "level_forest_dev_beat"
const DEV_STAGE_META := "level_forest_dev_stage"
const DEV_FREE_META := "level_forest_dev_free"   # F12「探索」：自由探索哪个场景（跨重新载入一直留着，退出探索时清掉）
const DEV_FREE_CH_META := "level_forest_dev_free_ch"   # F12 传送页的地图：在哪一章自由探索（有它就不查 FREE_ROOMS，哪章哪个房间都行）
const FREE_CLI_META := "level_forest_free_cli"   # --free= 只在第一次载入时用（退出探索重开本章时不再进去）
## 自由探索能去的场景：id → 章节（id 就是房间名；river_home 是河岸里的小屋，treehouse 是森林里的树屋）
## 面板给 forest、river、reeds 三个入口（river = 从河岸起）；别的房间名只给命令行拍截图用
## reeds = 云层星的芦苇地：第三章（final）剧本里的 reed_field 房间，在终章的世界里进（F12 地图也是终章那张）
const FREE_ROOMS := {"forest": "forest", "river": "river", "treehouse": "forest", "cockpit": "flight1", "river_bank": "river",
	"river_home": "river", "market": "river", "stairwell": "river", "oldstreet": "river", "warehouse": "river", "southbridge": "river",
	"reeds": "final", "reed_field": "final"}
const FREE_ALIAS := {"reeds": "reed_field"}   # 自由探索入口 id → 房间 id（入口名和房间名不一样的）
const FREE_STAIR := "free_stair_"   # 自由探索给多层小屋楼梯口加的 marker（上楼 / 下楼的进出口）
const FREE_SHIFT := 1.0            # 自由探索按住 Shift：晨每帧走的距离再多这么多倍（chen.gd 的 Shift 已经 ×1.5，合起来 ×3；动画帧速不变）
const DEV_OPEN_META := "level_forest_dev_open"   # 开场的外星人同伴：森林里不出现（那套图以后是河边的泥芙）
## 晨的精灵配置里有没有「趴着 / 爬起来」两段（tools/level1_chen_getup.py）。没有就退回把站立帧转 90° 的老办法。
var _has_getup: bool = CHEN_GD.ANIMS.has("lie") and CHEN_GD.ANIMS.has("getup")
## getup 一段多长（秒），和各帧什么时候换（跪坐、站直那两下扬一点土）
const GETUP_KNEEL_AT := 0.3       # chen.gd 里 getup 每帧 100ms：第 3 帧（跪坐）
const GETUP_STAND_AT := 0.6       # 第 6 帧（站直）
const GETUP_TIME := 0.7

## 调试场景浏览（只在 debug 构建、标题界面）：F1~F5；F7 兔子舞步 demo
const TEST_SCENES := {
	KEY_F1: "res://scenes/forest_test.tscn",
	KEY_F2: "res://scenes/river_test.tscn",
	KEY_F3: "res://scenes/underwater_test.tscn",
	KEY_F4: "res://scenes/cloud_test.tscn",
	KEY_F5: "res://scenes/flight_test.tscn",
	KEY_F7: "res://scenes/rabbit_dance_demo.tscn",
}
const SELF_SCENE := "res://scenes/level_forest.tscn"

## 标题界面
const TITLE_Y := 54.0
const TITLE_COLOR := Color("#d8cfe2")     # 11-06 背景换成云层小镇：字从森林的薄荷灰换成小镇天上那颗星的淡紫
const TITLE_SPACING := 3
const SUB_COLOR := Color("#9a8fb4")
const SUB_SPACING := 4
const START_Y := 150.0
const START_COLOR := Color("#b9aecb")
const START_HOT := Color("#efe9f5")
const START_SPACING := 2
const GEAR_A := 0.45
const GEAR_PLAY_A := 0.6
const LANG_ON := Color("#b9aecb")      # 左下角语言切换：当前语言
const LANG_OFF := Color("#6d6385")     # 另一种语言（悬停时亮成 START_HOT）

## 闪电：不再是整屏白闪，而是冷色的天光从林冠后面亮一下（远景几层被照亮，近处的树干、林冠成了剪影），
## 再叠一层很淡的冷色。下面是每层被照亮多少（0 = 不动）和冷光的颜色（乘到图层上，>1 = 变亮）。
const FLASH_LAYERS := {"Sky": 1.0, "Ridge": 0.9, "Far": 0.75, "MidFar": 0.45, "Mid": 0.18}
const FLASH_GAIN := Color(0.35, 0.62, 0.9)      # 闪到最亮时远景乘 (1+0.35, 1+0.62, 1+0.9)：偏青蓝，不是白
const FLASH_TINT := Color(0.55, 0.72, 0.86)      # 整屏那层薄薄的冷光
const FLASH_TINT_A := 0.09                       # 它最多这么不透明
const SKY_FLASH_A := 0.22                        # 下落途中（盖着开始界面）那层冷光最多这么不透明：全黑那段要靠它才看得出闪
const IMPACT_TINT := Color(1.0, 0.72, 0.45)      # 撞地那一下是暖的、很弱
const BAR_H := 26             # 电影黑边高度
const BAG_SLOTS := 24         # 背包格子 4 × 6
const DLG_TIME := 10.0        # 对话框最多停多久
const DLG_WALK := 56.0        # 晨离开说话的地方这么远，对话框就淡出

const SFX_DIR := "res://audio/sfx/"
const RAIN_DB := -18.0        # 森林的环境音（变量名还叫 rain）：11-05 作者给的鸟叫录音 audio/ambient/forest_birds.ogg（Pixabay，只有鸟叫，见那里的 LICENSE.txt）；11-04 的合成 forest_night.ogg 作者还是嫌白噪音大，不用了
const RAIN_ROOM_DB := -60.0   # 进树屋这类房间：鸟叫淡出去（11-05 作者「进入树屋这个音效会淡出」），出来再淡回来
const FIREFLIES := preload("res://scripts/fireflies.gd")
const TEX_BAG := preload("res://art/forest_story/c1_bag.png")    # 11-04 作者：右上角的背包要和地上捡的那只一样（旧的 art/level1/icon_bag.png 是灰色工具箱样子）
const TEX_GEAR := preload("res://art/level1/icon_gear.png")
const TEX_FLAME := preload("res://art/level1/icon_flame.png")
const TEX_HEADPHONES := preload("res://art/level1/icon_headphones.png")

@onready var cam: Camera2D = $Camera
@onready var chen: Node2D = $Chen
@onready var shafts: Node2D = $Main/Shafts
@onready var shadows: Node = $ForestShadows
@onready var puffs_back: Node2D = $PuffsBack
@onready var puffs_front: Node2D = $PuffsFront
@onready var wreck: Sprite2D = $Wreck
@onready var ship: Sprite2D = $Ship
@onready var alien: Node2D = $Alien
@onready var wood: Node2D = $Wood
@onready var wood_glow: Sprite2D = $Wood/Glow
@onready var wood_hint: Sprite2D = $Wood/Hint
@onready var flash: ColorRect = $Overlay/Flash
@onready var ui: CanvasLayer = $UI
@onready var fade: ColorRect = $Top/Fade

var state := S.HEADPHONES
var _t := 0.0                 # 总时间
var _state_t := 0.0           # 进入当前 state 多久了
var _seq: Array = []          # 定时事件 [[秒, Callable], …]，按时间排好
var _seq_t := 0.0
var _tweens: Array[Tween] = []   # 过场里的 tween，跳过时一起停掉
var _shake := 0.0
var _shake_amp := 0.0
var _rng := RandomNumberGenerator.new()
var _fireflies: Node2D
var _ship_frame_t := 0.0
var _skip_armed := 0.0        # >0：已经按过一次，这段时间内再按就跳过
var _walk_target := NAN       # 自动走到这个 x（点了够不着的东西、剧本让走）
var _cine_target := NAN       # 拾取过场：自动走到这个 x
var _moved_from := NAN        # 晨开始能动时的位置（用来藏「← →」提示）
var _hint_wait := 0.0
var _bag_seen := false
var _flash_k := 0.0           # 闪电的亮度 0..1（tween 它，_apply_flash 每帧套到远景和那层冷光上）
var _impact_k := 0.0          # 撞地那一下的暖光 0..1
var _title_k := 0.0           # 标题淡入进度 0..1（字往上飘 3 像素，按整像素走）
var _start_hot := 0.0         # 「开始」悬停 / 聚焦的高亮 0..1（两边的小横线跟着伸出来）
var _start_hover := false
var _start_fc := Color(0, 0, 0, 0)   # 「开始」现在的字色（变了才重设，免得每帧发主题变更）

# ---- 对话框
var _dlg: PanelContainer
var _dlg_name: Label
var _dlg_text: Label
var _dlg_on := false
var _dlg_age := 0.0
var _dlg_x := 0.0
var _dlg_chars := 0.0
var _dlg_cps := 26.0
var _dlg_tw: Tween

# ---- 界面
var _title_root: Control
var _title_label: Label
var _title_sub: Label         # 标题下面另一种语言的名字（英文版写「云」，中文版写 THE CLOUD）
var _title_lines: Array[ColorRect] = []   # 副标题两边的细线
var _start_btn: Button
var _start_marks: Array[ColorRect] = []   # 「开始」两边悬停时伸出来的小横线
var _credits_btn: Button         # 「开始」下面的「制作人员」（更小、更暗）
var _credits_page = null         # 打开着的制作人员页（scripts/credits_page.gd）
var _leaving_title := false      # 设置面板点了「返回标题」，正在淡到黑（_back_to_title）
var _gear: TextureButton
var _lang_corner: HBoxContainer   # 标题界面左下角的「EN / 中文」，跟着标题一起出现、消失
var _lang_btns := {}
var _bag_btn: TextureButton
var _hud_burn: HBoxContainer
var _hud_burn_label: Label
const ACHIEVEMENT_SAVE := "user://achievements.cfg"
var _achievement_data: Array = []
var _achievement_seen := ConfigFile.new()
var _achievement_progress := -1
var _achievement_toasts: CanvasLayer

var _hud_obj: Label
var _hud_side: RichTextLabel                    # 任务列表
var _hud_dim := 1.0                     # 对话框盖到左上角目标时淡下去（_hud_covered）
const HUD_UNDER := 0.0
var _hud_flame: TextureRect
var _obj_key := "-"
var _bars: Array[ColorRect] = []
var _skip_label: Label
var _keys_hint: Label
var _key_prompt: Label                  # 剧本 key_prompt 那一行
var _kp_until := ""                     # run / bag / ""：做到了就淡掉
var _kp_left := 0.0                     # 还剩几秒
var _kp_done := 0.0                     # 已经做到了多久（跑起来要持续一下才算）
var _kp_delay := 0.0                    # 还有几秒才出
var _pixel_fx: Control                  # 像素块溶解（fade_to style pixel）
var _zoom_tw: Tween
var _burn_pop: Control
var _burn_pop_num: Label
var _burn_pop_sub: Label
var _burn_pop_fill: ColorRect
var _burn_shown := 0.0
var _fuel_shown := -1.0                  # 飞行段燃料表正在滚的数（-1 = 不在滚，直接读 StoryState）
var _fuel_tw: Tween
var _hp_root: Control
var _dim: ColorRect
var _settings: PanelContainer
var _pause_gate: CanvasLayer             # 齿轮、设置面板在这一层（scripts/pause_gate.gd）
var _sett_dim: ColorRect                 # 设置面板后面的暗幕（背包用 _dim，在 UI 层）
var _settings_widgets := {}
var _bag: Panel
var _bag_slots: Array[Button] = []
var _bag_sel := 0
var _bag_after_story := false             # 拾取背包特写结束后，剧情收尾时自动打开背包
var _bag_w := {}
var _panel_prev_focus: Control

# ---- 剧本
var story: Node                 # story_runner.gd
var _story_path := ""
var _story_auto := ""
var _story_shots := ""
var _story_shot_delay := 0.5
var _story_check := false
var _qa_text := false                    # --qa_text：所有章节的字量一遍框（scripts/qa_text.gd），打印 QA_TEXT 后退出
var _beat := ""
var _story_bars := false
var _burn_sub_off := false
var _pending_hs: Dictionary = {}   # 鼠标点了一个 hotspot：走过去，到了就互动
var _wall_block := false
var _end_t := -1.0
var _fuzz := 0.0                  # --story_fuzz：乱玩多少秒
var _fuzz_rng := RandomNumberGenerator.new()
var _fuzz_t := 0.0
var _fuzz_next := 0.0
var _fuzz_hold := 0
var _fuzz_hold_t := 0.0
var _fuzz_xmin := INF
var _fuzz_xmax := -INF
var _lock_t := 0.0
var _lock_reported := false
var softlocks := 0
var _dev: Node                    # F12 开发者面板（scripts/dev_panel.gd）
var _dev_tab := 0
var _dbg_hide: PackedStringArray = []
var _dbg_chen_x := NAN
var _dbg_bag := ""
var _dbg_bag_line := -1
var free_roam := ""                # 自由探索的场景 id（"" = 正常游戏）
var free_npcs := false             # 自由探索：角色、路人显示出来（排在晨旁边）
var _free_cli := ""
var _free_pos := ""                # --chen_x=left|mid|right
var _free_climb := false
var _free_check := false
var _free_shots := ""
var _free_steps: PackedStringArray = []      # --free_tour=a,b,c：只走这几步（不给就走 FREE_TOUR）
# ---- 章节（scripts/chapter_flow.gd）：forest = 森林（默认）；flight1 = 驾驶舱，同一个关卡、不播开场
const CHAPTER_GD := preload("res://scripts/chapter_flow.gd")
var chapter := "forest"
var _story_chain := false          # --story_chain：自动玩 / 测试时也接下一章（平时玩本来就接）
var _beat_cli := false             # --beat 是命令行给的（测试 / 截图：不接下一章）
var _engine_hum: AudioStreamPlayer
var _hum_done := false          # 往前一冲以后引擎声不再回来（hum_done）
const HUM_DB := -20.0           # 驾驶舱引擎声多响

# ---- 声音
var _rain: AudioStreamPlayer
var _title_rain: AudioStreamPlayer
var _title_wind: AudioStreamPlayer
var _opening_rain_fx: GPUParticles2D
var _opening_rain_tw: Tween
## 11-07 作者：「从云层往森林落的时候就要下雨、打雷、屏幕闪」。雨原来挂在 Overlay（第 10 层）最底下，可下落时开始界面的
## 云层小镇（title_cloud.gd）在第 11 层，雨和闪电的冷光都被盖住。所以雨单独一层 _opening_sky：下落时在 12（盖过小镇，
## 在界面 20 和黑边下面），落到森林、小镇释放后降到 9（森林世界之上、Overlay 的暗角和闪电冷光之下，和原来的叠法一样）。
## 同一层里还有一块冷光 _sky_flash：下落时闪电让整屏亮一下（小镇的 _root 也跟着提亮，见 _apply_flash）。
const SKY_LAYER_DESCENT := 12
const SKY_LAYER_FOREST := 9
var _opening_sky: CanvasLayer
var _sky_flash: ColorRect
var _descended := false                    # 这次坠毁是不是从开始界面落下来的（--stage=crash 等跳关直接到坠毁时为 false）
var _opening_filter: AudioEffectLowPassFilter
var _opening_filter_tw: Tween
var _title_thunder_at := 7.0
var _title_bg: Node                       # 开始界面的云层小镇（scripts/title_cloud.gd），落完就释放
var _crackle: AudioStreamPlayer2D

# ---- 调试
var _shot := ""
var _shot_at := 1.0
var _shots_dir := ""
var _shots_start := 0
var _shots_every := 3
var _shots_count := 60
var _shots_saved := 0
var _frame := 0
var _autoplay := false
var _debug_stage := ""
var _browse := 0
var _browse_out := ""
var _stage_t := 0.0


func _ready() -> void:
	if not GameSettings.loaded:
		GameSettings.load_and_apply()      # 直接 F6 跑这个场景时
	_rng.seed = 7
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--stage="):
			_debug_stage = a.trim_prefix("--stage=")
		elif a.begins_with("--lang="):
			GameSettings.set_lang(a.trim_prefix("--lang="))
		elif a.begins_with("--quality="):
			GameSettings.quality = a.trim_prefix("--quality=")
		elif a.begins_with("--shot="):
			_shot = a.trim_prefix("--shot=")
		elif a.begins_with("--shot_at="):
			_shot_at = float(a.trim_prefix("--shot_at="))
		elif a == "--aspect=expand":
			get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
		elif a.begins_with("--win="):
			_dbg_win(a.trim_prefix("--win="))
		elif a.begins_with("--shots="):
			_shots_dir = a.trim_prefix("--shots=")
		elif a.begins_with("--start="):
			_shots_start = int(a.trim_prefix("--start="))
		elif a.begins_with("--every="):
			_shots_every = int(a.trim_prefix("--every="))
		elif a.begins_with("--count="):
			_shots_count = int(a.trim_prefix("--count="))
		elif a == "--title_hot":
			_start_hover = true
		elif a.begins_with("--browse="):
			_browse = int(a.trim_prefix("--browse="))
		elif a.begins_with("--browse_out="):
			_browse_out = a.trim_prefix("--browse_out=")
		elif a == "--autoplay":
			_autoplay = true
		elif a.begins_with("--story="):
			_story_path = a.trim_prefix("--story=")
		elif a == "--story_auto":
			_story_auto = "main"
		elif a.begins_with("--story_auto="):
			_story_auto = a.trim_prefix("--story_auto=")
		elif a.begins_with("--story_shots="):
			_story_shots = a.trim_prefix("--story_shots=")
		elif a.begins_with("--story_shot_delay="):
			_story_shot_delay = float(a.trim_prefix("--story_shot_delay="))
		elif a.begins_with("--beat="):
			_beat = a.trim_prefix("--beat=")
		elif a == "--story_check":
			_story_check = true
		elif a == "--qa_text":
			_qa_text = true
		elif a == "--dev_test":
			if not Engine.has_meta(DEV_BEAT_META):
				Engine.set_meta(DEV_OPEN_META, true)
		elif a.begins_with("--hide="):
			_dbg_hide = a.trim_prefix("--hide=").split(",")
		elif a == "--dev":
			Engine.set_meta(DEV_OPEN_META, true)
		elif a.begins_with("--dev_tab="):
			_dev_tab = int(a.trim_prefix("--dev_tab="))
		elif a.begins_with("--story_fuzz="):
			_fuzz = float(a.trim_prefix("--story_fuzz="))
		elif a.begins_with("--seed="):
			_fuzz_rng.seed = int(a.trim_prefix("--seed="))
		elif a.begins_with("--chen_x="):
			var v := a.trim_prefix("--chen_x=")
			if v in ["left", "mid", "right"]:
				_free_pos = v
			else:
				_dbg_chen_x = float(v)
		elif a.begins_with("--free="):
			_free_cli = a.trim_prefix("--free=")
		elif a == "--free_check":
			_free_check = true
		elif a.begins_with("--free_shots="):
			_free_shots = a.trim_prefix("--free_shots=")
		elif a.begins_with("--free_tour="):
			_free_steps = a.trim_prefix("--free_tour=").split(",")
		elif a.begins_with("--open_bag="):
			_dbg_bag = a.trim_prefix("--open_bag=")
		elif a.begins_with("--bag_line="):
			_dbg_bag_line = int(a.trim_prefix("--bag_line="))
		elif a == "--story_chain":
			_story_chain = true
		elif a.begins_with("--ui_tour="):
			_ui_tour = a.trim_prefix("--ui_tour=")
	_beat_cli = _beat != ""
	if _shots_dir != "":
		DirAccess.make_dir_recursive_absolute(_shots_dir)
	if _story_shots != "":
		DirAccess.make_dir_recursive_absolute(_story_shots)
	if _ui_tour != "":
		DirAccess.make_dir_recursive_absolute(_ui_tour)
	if _debug_stage != "" or _shot != "" or _shots_dir != "" or _autoplay or _browse > 0 or _story_auto != "" or _beat != "" or _story_check or _qa_text or _fuzz > 0.0 or _ui_tour != "":
		GameSettings.no_save = true
		AudioServer.set_bus_mute(0, true)    # 截图 / 录像时不出声，也不吃真的键盘鼠标（见 _input）

	chen.input_enabled = false
	cam.position = Vector2(TITLE_CAM_X, 135.0)
	# 没有存档：每次进第一关都是新游戏；别的章节（换章 / --chapter=）恢复带过来的状态（chapter_flow.gd）
	Inventory.owned.clear()
	StoryState.reset()
	_free_pick()
	chapter = CHAPTER_GD.current(_story_path)
	if chapter != "forest" and (_story_path == "" or Engine.has_meta(CHAPTER_GD.PICK_META)):
		_story_path = str(CHAPTER_GD.info(chapter)["story"])   # 换章 / F12 跳章：用那一章的剧本（命令行 --story= 只管起头那一章）
	CHAPTER_GD.restore(chapter)
	_load_achievements()
	# 光柱照到晨身上（lite 档光柱关了就是 0；树屋室内没有光柱）
	chen.set_env("forest", func(c):
		if story != null and story.world != null and story.world.in_room():
			return 0.0
		return preload("res://scripts/env_light.gd").polygon_shafts(c, shafts))
	_place_world()
	var pzf := Node.new()                     # 11-05：镜头缩放时视差层的偏移修正（起身连按 Q 推近，树「离地」）
	pzf.name = "ParallaxZoomFix"
	pzf.set_script(preload("res://scripts/parallax_zoom_fix.gd"))
	add_child(pzf)
	_apply_quality()
	_build_audio()
	_build_ui()
	_build_story()
	_retext()
	if not Engine.has_meta(TITLE_FADE_META):   # 耳机提示只在启动第一次进标题时出现；全剧终 / 设置「返回标题」回来不再出（11-07 作者）
		_enter_headphones()
	if Engine.has_meta(BACK_META):          # 从测试场景按 Esc 回来：直接到标题（雨声照常）；自由探索里去的就回自由探索
		Engine.remove_meta(BACK_META)
		if free_roam == "":
			_skip_to_title()
	if Engine.has_meta(TITLE_FADE_META):    # 「全剧终」以后的制作人员放完：从黑里淡出标题（title_after_credits）
		Engine.remove_meta(TITLE_FADE_META)
		_title_fade_in()
	if _qa_text:
		var qa = load("res://scripts/qa_text.gd").new()
		qa.report(qa.run())
		get_tree().quit()
		return
	if _story_check:
		for line in story.validate():
			print("STORY_CHECK " + line)
		print("STORY_CHECK done: %s, %d scenes, %d hotspots" % [story.path, story.scenes.size(), story.hotspot_defs.size()])
		for a in OS.get_cmdline_user_args():
			if a.begins_with("--cycle_test="):
				story.cycle_test(int(a.trim_prefix("--cycle_test=")))
		get_tree().quit()
		return
	# F12 面板「跳节拍 / 重开本章」：重新载入本场景，再在这里接着跳（和 --beat / --stage 同一套）
	if Engine.has_meta(DEV_BEAT_META):
		_beat = str(Engine.get_meta(DEV_BEAT_META))
		_debug_stage = ""                   # 面板说的算（命令行的 --stage 重新载入后还在）
		Engine.remove_meta(DEV_BEAT_META)
		Engine.set_meta(DEV_OPEN_META, true)
	if Engine.has_meta(DEV_STAGE_META):
		_debug_stage = str(Engine.get_meta(DEV_STAGE_META))
		_beat = ""
		Engine.remove_meta(DEV_STAGE_META)
		Engine.set_meta(DEV_OPEN_META, true)
	if free_roam != "":
		_start_free()
	else:
		if chapter != "forest":
			_debug_stage = ""                   # 别的章节没有开场 / 标题 / 坠毁（「重开本章」= 从这一章的开头）
			_start_chapter(_beat == "")
		if _debug_stage != "":
			_jump(_debug_stage)
		if _beat != "":
			_jump_beat.call_deferred(_beat)
	# 面板一开始就建好（藏着）：F12 由面板自己先接（剧情里小游戏 / 点选会吃掉按键，关卡的 _input 收不到）
	if OS.is_debug_build():
		_make_dev(Engine.has_meta(DEV_OPEN_META))
	if Engine.has_meta(DEV_OPEN_META):
		Engine.remove_meta(DEV_OPEN_META)


func _build_story() -> void:
	var root: Control = ui.get_node("Root")
	story = STORY_GD.new()
	story.name = "Story"
	story.load_story(_story_path)
	story.entry_scene = str(CHAPTER_GD.info(chapter).get("start", ""))
	story.carry_flags = CHAPTER_GD.info(chapter).get("carry_flags", [])
	add_child(story)
	story.setup(self, root)
	root.move_child(story.dlg, _dim.get_index())        # 对话框在黑边上面、面板下面
	story.auto = _story_auto
	story.dlg.sfx = _sfx
	story.shots_dir = _story_shots
	story.shot_delay = _story_shot_delay
	if _autoplay or _shot != "" or _shots_dir != "":
		story.dlg.auto_delay = 2.5          # 这几种调试模式不吃按键：剧情对话自己往下走（像原来的定时对话框）
	story.world.extra_rects["wreck"] = func() -> Rect2:
		if not wreck.visible:
			return Rect2()
		return Rect2(wreck.position + wreck.offset + Vector2(20, 20), wreck.texture.get_size() - Vector2(40, 20))
	story.world.on_pseudo = _on_pseudo_prop
	if "--qa_live" in OS.get_cmdline_user_args():
		var qa: Node = load("res://scripts/qa_live.gd").new()      # 自动检查：字叠字、字出屏、对话框挂着不走（docs/QA_自动检查.md）
		qa.name = "QaLive"
		qa.set("story", story)
		qa.set("level", self)
		add_child(qa)
	if "wood" in story.data.get("hide_props", []) and chapter == "forest":
		wood.visible = false                   # 第一关新版：地上没有发光木头（永燃之木是兔子给的）
	if _story_auto != "" or _beat != "":
		for l in story.validate():
			if not l.begins_with("info:"):
				print("STORY_CHECK " + l)


# ======================================================================= 世界摆放
func _ground(x: float) -> float:
	return round(chen.ground_fn.call(x))


func _place_world() -> void:
	# 坠毁现场挪了 CRASH_DX：Main 层正好绕回一圈，别的视差层补上相位，标题 / 坠毁 / 起飞那几屏的远景、前景和挪之前一模一样
	for n in ["Ridge", "Far", "MidFar", "Mid", "Front"]:
		var p := get_node(n) as Parallax2D
		p.scroll_offset.x += CRASH_DX * p.scroll_scale.x
	wreck.position = Vector2(WRECK_X, _ground(WRECK_X) + 1)
	wood.position = Vector2(WOOD_X, _ground(WOOD_X))
	chen.position = Vector2(CHEN_X, _ground(CHEN_X) + 1)
	alien.position = Vector2(ALIEN_X, _ground(ALIEN_X) + 1)
	alien.watch(chen)
	if not ALIEN_IN_FOREST:
		alien.visible = false


func _apply_quality() -> void:
	var lite := GameSettings.lite()
	shafts.visible = not lite
	if _fireflies != null:
		_fireflies.queue_free()
	_fireflies = Node2D.new()
	_fireflies.set_script(FIREFLIES)
	_fireflies.set("count", 10 if lite else 26)
	_fireflies.material = (shafts.get_child(0) as CanvasItem).material   # 同一个加法混合材质
	$Main.add_child(_fireflies)
	shadows.set("interval", Vector2(14.0, 32.0) * (2.5 if lite else 1.0))
	puffs_back.density = 0.5 if lite else 1.0
	puffs_front.density = 0.5 if lite else 1.0


# ======================================================================= 声音
## 循环的环境音（ogg / wav）：编辑器还没导入时直接读文件；ogg 导入默认不循环，这里打开。
## wav 导入没开循环的（flight_engine_loop 4 秒）：复制一份设成 LOOP_FORWARD（不改缓存里那份）——原来靠 finished → play() 重开，
## 每 4 秒重开那一帧没在放又响着，--qa_audio 报 hard_start（11-05 ch1-fx 三遍都撞到，时间随机），耳朵里也是一下断口。
static func _ambient_stream(path: String) -> AudioStream:
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path)
	elif FileAccess.file_exists(path):
		s = AudioStreamOggVorbis.load_from_file(ProjectSettings.globalize_path(path))
	if s is AudioStreamOggVorbis:
		(s as AudioStreamOggVorbis).loop = true
	elif s is AudioStreamWAV and (s as AudioStreamWAV).loop_mode == AudioStreamWAV.LOOP_DISABLED:
		var w := (s as AudioStreamWAV).duplicate() as AudioStreamWAV
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = int(round(w.get_length() * w.mix_rate))
		s = w
	return s


func _build_audio() -> void:
	_rain = AudioStreamPlayer.new()
	_rain.stream = _ambient_stream("res://audio/ambient/forest_birds.ogg")
	_rain.bus = "SFX"
	_rain.volume_db = -80.0
	add_child(_rain)
	var opening_bus := AudioServer.get_bus_index(GameSettings.OPENING_BUS)
	_opening_filter = AudioServer.get_bus_effect(opening_bus, 0) as AudioEffectLowPassFilter
	_title_rain = AudioStreamPlayer.new()
	_title_rain.name = "TitleRain"
	_title_rain.stream = _ambient_stream(SFX_DIR + "rain_loop.wav")
	_title_rain.bus = GameSettings.OPENING_BUS
	_title_rain.volume_db = -60.0
	add_child(_title_rain)
	_title_wind = AudioStreamPlayer.new()
	_title_wind.name = "TitleWind"
	_title_wind.stream = _ambient_stream("res://audio/sfx/cloud_wind.ogg")
	_title_wind.bus = GameSettings.OPENING_BUS
	_title_wind.volume_db = -60.0
	add_child(_title_wind)
	_crackle = AudioStreamPlayer2D.new()
	_crackle.stream = load(SFX_DIR + "fire_crackle_loop.wav")
	_crackle.bus = "SFX"
	_crackle.volume_db = -80.0
	_crackle.max_distance = 700.0
	wreck.add_child(_crackle)
	_crackle.position = Vector2(8, -14)


func _sfx(name: String, db := 0.0, pitch := 1.0, bus := "SFX") -> void:
	var p := AudioStreamPlayer.new()
	p.stream = load(SFX_DIR + name + ".wav")
	p.bus = bus
	p.volume_db = db
	p.pitch_scale = pitch
	if get_tree().paused:
		p.process_mode = Node.PROCESS_MODE_ALWAYS   # 设置面板的声音（别的音效跟着暂停停住）
	add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


func _opening_sfx(name: String, db: float, pitch := 1.0) -> void:
	_sfx(name, db, pitch, GameSettings.OPENING_BUS)


func _fade_db(p: Node, to_db: float, sec: float) -> Tween:
	var old = (p.get_meta("fade_tw") if p.has_meta("fade_tw") else null)               # 同一个声音只留一个音量 tween（两个抢着改会跳）
	if old is Tween and (old as Tween).is_valid():
		(old as Tween).kill()
	var tw := create_tween()
	tw.tween_property(p, "volume_db", to_db, sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	p.set_meta("fade_tw", tw)
	return tw


# ======================================================================= 界面搭建
func _label(text: String, size := 14, color := UITheme.TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _build_ui() -> void:
	var root := Control.new()
	root.name = "Root"
	root.theme = UITheme.get_theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	_pause_gate = (load("res://scripts/pause_gate.gd") as GDScript).new()
	_pause_gate.level = self
	add_child(_pause_gate)

	# ---- 电影黑边（先加，在最底下）
	for i in 2:
		var b := ColorRect.new()
		b.color = Color(0.0, 0.0, 0.0, 1.0)
		b.size = Vector2(480, BAR_H)
		b.position = Vector2(0, -BAR_H if i == 0 else 270)
		b.visible = false
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(b)
		_bars.append(b)
	_skip_label = _label("", 14, UITheme.TEXT_DIM)
	_skip_label.position = Vector2(0, 270 - BAR_H + 5)
	_skip_label.size = Vector2(472, 16)
	_skip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_skip_label.modulate.a = 0.0
	root.add_child(_skip_label)

	# ---- 标题（要能直接当封面截图）：游戏名拉开字距、偏暗的薄荷灰、底下压一格深色影子；
	# 下面一行小字是另一种语言的名字，两边各一条细线；「开始」是不抢戏的小字，悬停 / 聚焦时变亮、两边伸出小横线。
	_title_root = Control.new()
	_title_root.size = Vector2(480, 270)
	_title_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_title_root.modulate.a = 0.0
	_title_root.visible = false
	root.add_child(_title_root)
	_title_label = _label("", 42, TITLE_COLOR)
	_title_label.add_theme_color_override("font_shadow_color", Color(0.05, 0.02, 0.08, 0.35))
	_title_label.add_theme_constant_override("shadow_offset_x", 0)
	_title_label.add_theme_constant_override("shadow_offset_y", 3)
	_title_label.position = Vector2(0, TITLE_Y)
	_title_root.add_child(_title_label)
	_title_sub = _label("", 14, SUB_COLOR)
	_title_sub.position = Vector2(0, TITLE_Y + 50)
	_title_root.add_child(_title_sub)
	for i in 2:
		var ln := ColorRect.new()
		ln.color = SUB_COLOR * Color(1, 1, 1, 0.6)
		ln.size = Vector2(18, 1)
		ln.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_title_root.add_child(ln)
		_title_lines.append(ln)
	_start_btn = Button.new()
	UITheme.flat_button(_start_btn)
	_start_btn.add_theme_font_override("font", UITheme.spaced_font(START_SPACING))
	_start_btn.add_theme_font_size_override("font_size", 14)
	_start_btn.add_theme_color_override("font_color", START_COLOR)
	_start_btn.add_theme_color_override("font_hover_color", START_HOT)
	_start_btn.add_theme_color_override("font_focus_color", START_HOT)
	_start_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	_start_btn.add_theme_color_override("font_shadow_color", Color(0.05, 0.02, 0.08, 0.5))   # 雾最亮的地方也看得清
	_start_btn.add_theme_constant_override("shadow_offset_x", 0)
	_start_btn.add_theme_constant_override("shadow_offset_y", 1)
	_start_btn.position = Vector2(0, START_Y)
	_start_btn.pressed.connect(_on_start)
	_start_btn.focus_entered.connect(func(): _sfx_soft())
	_start_btn.mouse_entered.connect(_on_start_hover.bind(true))
	_start_btn.mouse_exited.connect(_on_start_hover.bind(false))
	_title_root.add_child(_start_btn)
	for i in 2:
		var m := ColorRect.new()
		m.color = START_HOT
		m.size = Vector2(0, 1)
		m.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_title_root.add_child(m)
		_start_marks.append(m)
	_credits_btn = Button.new()
	UITheme.flat_button(_credits_btn)
	_credits_btn.add_theme_font_override("font", UITheme.spaced_font(START_SPACING))
	_credits_btn.add_theme_font_size_override("font_size", 12)
	for k in ["font_color", "font_pressed_color"]:
		_credits_btn.add_theme_color_override(k, SUB_COLOR)
	for k in ["font_hover_color", "font_focus_color", "font_hover_pressed_color"]:
		_credits_btn.add_theme_color_override(k, START_HOT)
	_credits_btn.add_theme_color_override("font_shadow_color", Color(0.05, 0.02, 0.08, 0.5))
	_credits_btn.add_theme_constant_override("shadow_offset_x", 0)
	_credits_btn.add_theme_constant_override("shadow_offset_y", 1)
	_credits_btn.pressed.connect(_open_credits)
	_credits_btn.mouse_entered.connect(_sfx_soft)
	_credits_btn.focus_entered.connect(_sfx_soft)
	_title_root.add_child(_credits_btn)

	# ---- 右下角设置齿轮（标题和自由走的时候都在）
	_gear = TextureButton.new()
	_gear.texture_normal = TEX_GEAR
	_gear.position = Vector2(480 - 8 - 11, 270 - 8 - 11)
	_gear.size = Vector2(11, 11)
	_gear.focus_mode = Control.FOCUS_NONE
	_gear.modulate = Color(1, 1, 1, 0.0)
	_gear.mouse_entered.connect(func(): _gear.self_modulate = Color(1.6, 1.6, 1.6))
	_gear.mouse_exited.connect(func(): _gear.self_modulate = Color.WHITE)

	# ---- 左下角语言切换（只在标题界面；设置里也能换）
	_lang_corner = HBoxContainer.new()
	_lang_corner.add_theme_constant_override("separation", 5)
	_lang_corner.position = Vector2(8, 270 - 8 - 14)
	_title_root.add_child(_lang_corner)
	for l in ["en", "zh"]:
		if l == "zh":
			_lang_corner.add_child(_label("/", 14, LANG_OFF))
		var b := Button.new()
		UITheme.flat_button(b)
		b.add_theme_font_size_override("font_size", 14)
		b.add_theme_color_override("font_hover_color", START_HOT)
		b.add_theme_color_override("font_hover_pressed_color", START_HOT)
		b.focus_mode = Control.FOCUS_NONE
		b.text = "EN" if l == "en" else "中文"
		b.pressed.connect(_on_lang_corner.bind(l))
		b.mouse_entered.connect(_sfx_soft)
		_lang_corner.add_child(b)
		_lang_btns[l] = b

	# ---- HUD：左上燃烧值、右上背包
	_hud_burn = HBoxContainer.new()
	_hud_burn.position = Vector2(8, 7)
	_hud_burn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_burn.add_theme_constant_override("separation", 4)
	# 当前目标（剧本 objectives）：在燃烧值前面；没有 objectives 就藏着，左上角照旧只显示燃烧值
	_hud_obj = _label("", 13 if chapter == "forest" else 14, UITheme.TEXT)
	_hud_obj.add_theme_color_override("font_shadow_color", Color(0.0, 0.03, 0.02, 0.6))
	_hud_obj.add_theme_constant_override("shadow_offset_x", 0)
	_hud_obj.add_theme_constant_override("shadow_offset_y", 1)
	_hud_obj.visible = false
	_hud_burn.add_child(_hud_obj)
	# 支线（第一关）：主目标下面一行、暗一点，「（可选）…」；挂在目标那行底下，跟着它淡入淡出
	_hud_side = RichTextLabel.new()
	_hud_side.bbcode_enabled = true
	_hud_side.fit_content = true
	_hud_side.scroll_active = false
	_hud_side.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_side.size.x = 255
	_hud_side.add_theme_color_override("default_color", UITheme.TEXT_DIM)
	_hud_side.add_theme_font_size_override("normal_font_size", 11)
	_hud_side.add_theme_color_override("font_shadow_color", Color(0.0, 0.03, 0.02, 0.6))
	_hud_side.add_theme_constant_override("shadow_offset_x", 0)
	_hud_side.add_theme_constant_override("shadow_offset_y", 1)
	_hud_side.position = Vector2(0, 17)
	_hud_side.modulate.a = 0.75
	_hud_obj.add_child(_hud_side)
	var fl := TextureRect.new()
	fl.texture = TEX_FLAME
	fl.stretch_mode = TextureRect.STRETCH_KEEP
	fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud_burn.add_child(fl)
	_hud_flame = fl
	_hud_burn_label = _label("", 14, UITheme.WARM)
	_hud_burn.add_child(_hud_burn_label)
	_hud_burn.modulate.a = 0.0
	root.add_child(_hud_burn)

	_bag_btn = TextureButton.new()
	_bag_btn.texture_normal = TEX_BAG
	_bag_btn.position = Vector2(480 - 8 - 13, 7)
	_bag_btn.size = Vector2(13, 12)
	_bag_btn.pivot_offset = Vector2(6.5, 6)
	_bag_btn.focus_mode = Control.FOCUS_NONE
	_bag_btn.modulate.a = 0.0
	_bag_btn.visible = false
	_bag_btn.pressed.connect(_toggle_bag)
	_bag_btn.mouse_entered.connect(func(): _bag_btn.self_modulate = Color(1.3, 1.3, 1.3))
	_bag_btn.mouse_exited.connect(func(): _bag_btn.self_modulate = Color.WHITE)
	root.add_child(_bag_btn)

	# ---- 剧本的按键提示（key_prompt：「按住 Shift 奔跑」「按 Tab 打开背包」），屏幕下方居中
	_key_prompt = _label("", 14, UITheme.TEXT)
	_key_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_key_prompt.size = Vector2(480, 16)
	_key_prompt.position = Vector2(0, 228)
	_key_prompt.modulate.a = 0.0
	root.add_child(_key_prompt)

	# ---- 「← →」提示（晨脚下，很淡）
	_keys_hint = _label("←  →", 14, UITheme.TEXT)
	_keys_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_keys_hint.size = Vector2(40, 16)
	_keys_hint.modulate.a = 0.0
	root.add_child(_keys_hint)

	# ---- 对话框
	_dlg = PanelContainer.new()
	_dlg.add_theme_stylebox_override("panel", UITheme.box(Color(0.02, 0.05, 0.04, 0.72), Color(0.5, 0.6, 0.55, 0.35), 1, Vector4(7, 4, 7, 5)))
	_dlg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_dlg.modulate.a = 0.0
	_dlg.visible = false
	var dv := VBoxContainer.new()
	dv.add_theme_constant_override("separation", 2)
	dv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_dlg.add_child(dv)
	_dlg_name = _label("", 14, UITheme.ACCENT)
	dv.add_child(_dlg_name)
	_dlg_text = _label("", 14, UITheme.TEXT)
	_dlg_text.add_theme_constant_override("line_spacing", 2)
	dv.add_child(_dlg_text)
	root.add_child(_dlg)

	# ---- 燃烧值弹出
	_burn_pop = Control.new()
	_burn_pop.size = Vector2(200, 66)
	_burn_pop.position = Vector2(140, 34)
	_burn_pop.pivot_offset = Vector2(100, 20)
	_burn_pop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_burn_pop.modulate.a = 0.0
	_burn_pop.visible = false
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.size = Vector2(200, 32)
	row.add_theme_constant_override("separation", 6)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fl2 := TextureRect.new()
	fl2.texture = TEX_FLAME
	fl2.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	fl2.custom_minimum_size = Vector2(14, 18)
	fl2.stretch_mode = TextureRect.STRETCH_SCALE
	fl2.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fl2.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(fl2)
	_burn_pop_num = _label("10", 28, UITheme.WARM)
	row.add_child(_burn_pop_num)
	_burn_pop.add_child(row)
	var track := ColorRect.new()
	track.color = Color(0.18, 0.22, 0.2, 0.9)
	track.position = Vector2(40, 37)
	track.size = Vector2(120, 3)
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_burn_pop.add_child(track)
	_burn_pop_fill = ColorRect.new()
	_burn_pop_fill.color = UITheme.WARM
	_burn_pop_fill.position = Vector2(40, 37)
	_burn_pop_fill.size = Vector2(0, 3)
	_burn_pop_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_burn_pop.add_child(_burn_pop_fill)
	var goal := ColorRect.new()                 # 终点（200）的小竖条
	goal.color = Color("#dfe8e2")
	goal.position = Vector2(160, 35)
	goal.size = Vector2(1, 7)
	goal.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_burn_pop.add_child(goal)
	_burn_pop_sub = _label("", 14, UITheme.TEXT)
	_burn_pop_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_burn_pop_sub.position = Vector2(-40, 46)
	_burn_pop_sub.size = Vector2(280, 16)
	_burn_pop_sub.modulate.a = 0.0
	_burn_pop.add_child(_burn_pop_sub)
	root.add_child(_burn_pop)

	# 面板后面压暗一层；点空白处关面板
	_dim = ColorRect.new()
	_dim.color = Color(0.0, 0.02, 0.01, 0.45)
	_dim.size = Vector2(480, 270)
	_dim.visible = false
	_dim.gui_input.connect(_on_dim_input)
	root.add_child(_dim)
	_sett_dim = ColorRect.new()
	_sett_dim.color = _dim.color
	_sett_dim.size = _dim.size
	_sett_dim.visible = false
	_sett_dim.gui_input.connect(_on_dim_input)
	_pause_gate.ui_root.add_child(_sett_dim)
	_build_settings(_pause_gate.ui_root)
	_pause_gate.ui_root.add_child(_gear)     # 齿轮在面板上面：开着的时候再点一下 = 关
	_build_bag(root)

	# ---- 耳机提示（在最上层 Top 里，盖在黑幕上）
	_hp_root = VBoxContainer.new()
	_hp_root.theme = UITheme.get_theme()
	_hp_root.position = Vector2(0, 100)
	_hp_root.size = Vector2(480, 80)
	_hp_root.alignment = BoxContainer.ALIGNMENT_CENTER
	_hp_root.add_theme_constant_override("separation", 8)
	_hp_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hp_root.modulate.a = 0.0
	var icon := TextureRect.new()
	icon.texture = TEX_HEADPHONES
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_SCALE
	icon.custom_minimum_size = Vector2(30, 22)
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hp_root.add_child(icon)
	var copy := VBoxContainer.new()
	copy.add_theme_constant_override("separation", 3)
	copy.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hp_root.add_child(copy)
	var headphones: Array = I18n.STR["headphones"]
	var english := _label(headphones[0], 14, UITheme.TEXT)
	english.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	copy.add_child(english)
	var chinese := _label(headphones[1], 11, UITheme.TEXT_DIM)
	chinese.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	copy.add_child(chinese)
	$Top.add_child(_hp_root)


func _on_dim_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		_close_panels()


func _on_start_hover(on: bool) -> void:
	_start_hover = on
	if on:
		_sfx_soft()


func _sfx_soft() -> void:
	if state == S.TITLE and _state_t > 0.5:
		_sfx("ui_click", -14.0, 1.3)


# ---------------------------------------------------------------- 设置面板
func _row(parent: Control, key: String) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 4)
	var l := _label("", 14, UITheme.TEXT_DIM)
	l.custom_minimum_size = Vector2(80, 18)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(l)
	_settings_widgets["lbl_" + key] = l
	parent.add_child(h)
	return h


func _toggle_pair(h: HBoxContainer, key: String, a_key: String, b_key: String, on_a: Callable, on_b: Callable) -> void:
	var g := ButtonGroup.new()
	for i in 2:
		var b := Button.new()
		b.toggle_mode = true
		b.button_group = g
		b.custom_minimum_size = Vector2(64, 18)
		b.pressed.connect(on_a if i == 0 else on_b)
		b.pressed.connect(func(): _sfx("ui_click", -10.0))
		h.add_child(b)
		_settings_widgets[key + ("_a" if i == 0 else "_b")] = b
	_settings_widgets[key + "_keys"] = [a_key, b_key]


func _slider(h: HBoxContainer, key: String, value: float, on_change: Callable) -> void:
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(132, 16)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.value_changed.connect(on_change)
	h.add_child(s)
	_settings_widgets[key] = s


func _build_settings(root: Control) -> void:
	_settings = PanelContainer.new()
	_settings.visible = false
	_settings.mouse_filter = Control.MOUSE_FILTER_STOP
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 5)
	_settings.add_child(v)
	var title := _label("", 14, UITheme.TEXT)
	_settings_widgets["title"] = title
	v.add_child(title)
	var sep := ColorRect.new()
	sep.color = Color(0.3, 0.4, 0.35, 0.6)
	sep.custom_minimum_size = Vector2(0, 1)
	v.add_child(sep)

	var h := _row(v, "language")
	_toggle_pair(h, "lang", "", "", func(): _set_lang("en"), func(): _set_lang("zh"))
	h = _row(v, "vol_master")
	_slider(h, "vol_master", GameSettings.vol_master, _set_vol.bind("vol_master"))
	h = _row(v, "vol_music")
	_slider(h, "vol_music", GameSettings.vol_music, _set_vol.bind("vol_music"))
	h = _row(v, "vol_sfx")
	_slider(h, "vol_sfx", GameSettings.vol_sfx, _set_vol.bind("vol_sfx"))
	h = _row(v, "quality")
	_toggle_pair(h, "q", "q_full", "q_lite", func(): _set_quality("full"), func(): _set_quality("lite"))
	h = _row(v, "fullscreen")
	_toggle_pair(h, "fs", "on", "off", func(): _set_fullscreen(true), func(): _set_fullscreen(false))
	if OS.has_feature("web"):
		h.visible = false
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 2)
	v.add_child(gap)
	var row := HBoxContainer.new()                 # 「制作人员」旁边是「返回标题」（标题界面没有这个按钮，_sync_settings）
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 6)
	v.add_child(row)
	var cr := Button.new()
	cr.custom_minimum_size = Vector2(80, 18)
	cr.pressed.connect(_open_credits)
	row.add_child(cr)
	_settings_widgets["credits"] = cr
	var bt := Button.new()
	bt.custom_minimum_size = Vector2(80, 18)
	bt.pressed.connect(_back_to_title)
	row.add_child(bt)
	_settings_widgets["back_title"] = bt
	var close := Button.new()
	close.custom_minimum_size = Vector2(80, 18)
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(_close_panels)
	v.add_child(close)
	_settings_widgets["close"] = close
	root.add_child(_settings)


func _set_vol(x: float, key: String) -> void:
	GameSettings.set_vol(key, x)
	GameSettings.apply_audio()
	GameSettings.save()


func _set_lang(l: String) -> void:
	GameSettings.set_lang(l)
	GameSettings.save()
	_retext()


func _on_lang_corner(l: String) -> void:
	if l == GameSettings.lang:
		return
	_sfx("ui_click", -10.0)
	_set_lang(l)
	_sync_settings()


func _set_quality(q: String) -> void:
	GameSettings.quality = q
	GameSettings.save()
	_apply_quality()


func _set_fullscreen(on: bool) -> void:
	GameSettings.fullscreen = on
	GameSettings.save()
	GameSettings.apply_window()


func _sync_settings() -> void:
	var w := _settings_widgets
	(w["back_title"] as Button).visible = free_roam == "" and not state in [S.HEADPHONES, S.INTRO, S.TITLE]
	(w["lang_a"] as Button).set_pressed_no_signal(GameSettings.lang == "en")
	(w["lang_b"] as Button).set_pressed_no_signal(GameSettings.lang == "zh")
	(w["q_a"] as Button).set_pressed_no_signal(not GameSettings.lite())
	(w["q_b"] as Button).set_pressed_no_signal(GameSettings.lite())
	(w["fs_a"] as Button).set_pressed_no_signal(GameSettings.fullscreen)
	(w["fs_b"] as Button).set_pressed_no_signal(not GameSettings.fullscreen)
	for k in ["vol_master", "vol_music", "vol_sfx"]:
		(w[k] as HSlider).set_value_no_signal(GameSettings.get_vol(k))


# ---------------------------------------------------------------- 背包
func _build_bag(root: Control) -> void:
	_bag = Panel.new()
	_bag.visible = false
	_bag.position = Vector2(64, 28)
	_bag.size = Vector2(352, 214)
	_bag.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(_bag)
	var title := _label("", 14, UITheme.TEXT)
	title.position = Vector2(10, 4)
	_bag.add_child(title)
	_bag_w["title"] = title
	# 右上：燃烧值总数 + 关闭
	var tot := HBoxContainer.new()
	tot.position = Vector2(180, 4)
	tot.size = Vector2(144, 16)
	tot.alignment = BoxContainer.ALIGNMENT_END
	tot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fl := TextureRect.new()
	fl.texture = TEX_FLAME
	fl.stretch_mode = TextureRect.STRETCH_KEEP
	fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tot.add_child(fl)
	var tl := _label("", 14, UITheme.WARM)
	tot.add_child(tl)
	_bag_w["total"] = tl
	_bag_w["total_row"] = tot
	_bag.add_child(tot)
	# 关闭：不用字体里的「×」（按钮里的字会被排到半格上，糊成「)(」），画一个 7×7 的像素叉，
	# 按钮 15×15、叉居中正好落在整像素上（和「60 / 200」的数字同高）
	var x := TextureButton.new()
	x.texture_normal = _pixel_cross(7, UITheme.TEXT)
	x.stretch_mode = TextureButton.STRETCH_KEEP_CENTERED
	x.ignore_texture_size = true
	x.position = Vector2(330, 4)
	x.size = Vector2(15, 15)
	x.self_modulate = Color(1, 1, 1, 0.7)
	x.mouse_entered.connect(func(): x.self_modulate = Color(1.25, 1.25, 1.25, 1.0))
	x.mouse_exited.connect(func(): x.self_modulate = Color(1, 1, 1, 0.7))
	x.focus_mode = Control.FOCUS_NONE
	x.pressed.connect(_close_panels)
	_bag.add_child(x)
	_bag_w["close"] = x
	var sep := ColorRect.new()
	sep.color = Color(0.3, 0.4, 0.35, 0.6)
	sep.position = Vector2(8, 23)
	sep.size = Vector2(336, 1)
	_bag.add_child(sep)
	# 左：格子 4 × 6（森林章节一共十几样东西）
	var grid := GridContainer.new()
	grid.columns = 4
	grid.position = Vector2(10, 30)
	grid.add_theme_constant_override("h_separation", 3)
	grid.add_theme_constant_override("v_separation", 3)
	_bag.add_child(grid)
	var slot_box := UITheme.box(Color(0.06, 0.1, 0.09, 0.9), Color(0.22, 0.3, 0.26), 1, Vector4(0, 0, 0, 0))
	var slot_hover := UITheme.box(Color(0.1, 0.16, 0.14, 0.95), Color(0.5, 0.62, 0.56), 1, Vector4(0, 0, 0, 0))
	var slot_sel := UITheme.box(Color(0.14, 0.12, 0.14, 0.95), UITheme.ACCENT, 1, Vector4(0, 0, 0, 0))
	for i in BAG_SLOTS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(26, 26)
		b.add_theme_stylebox_override("normal", slot_box)
		b.add_theme_stylebox_override("hover", slot_hover)
		b.add_theme_stylebox_override("pressed", slot_sel)
		b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		b.set_meta("sel_box", slot_sel)
		b.set_meta("box", slot_box)
		var ic := TextureRect.new()
		ic.stretch_mode = TextureRect.STRETCH_KEEP_CENTERED
		ic.set_anchors_preset(Control.PRESET_FULL_RECT)
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(ic)
		b.set_meta("icon", ic)
		var idx := i
		b.pressed.connect(func(): _bag_select(idx))
		b.focus_entered.connect(func(): _bag_select(idx))
		grid.add_child(b)
		_bag_slots.append(b)
	# 右：选中物品
	var frame := Panel.new()
	frame.position = Vector2(130, 30)
	frame.size = Vector2(212, 50)
	frame.add_theme_stylebox_override("panel", UITheme.box(Color(0.05, 0.08, 0.07, 0.9), Color(0.22, 0.3, 0.26), 1))
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bag.add_child(frame)
	var big := TextureRect.new()
	big.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	big.stretch_mode = TextureRect.STRETCH_SCALE
	big.mouse_filter = Control.MOUSE_FILTER_IGNORE
	frame.add_child(big)
	_bag_w["big"] = big
	var name_l := _label("", 14, UITheme.TEXT)
	name_l.position = Vector2(130, 84)
	_bag.add_child(name_l)
	_bag_w["name"] = name_l
	var cat := _label("", 14, UITheme.TEXT_DIM)       # 名字旁边的【纪念品】/【任务】
	cat.position = Vector2(200, 84)
	_bag.add_child(cat)
	_bag_w["cat"] = cat
	var rar := _label("", 14, UITheme.TEXT_DIM)
	rar.position = Vector2(130, 100)
	_bag.add_child(rar)
	_bag_w["rarity"] = rar
	var burn := _label("", 14, UITheme.WARM)
	burn.position = Vector2(130, 100)            # 和稀有度同一行、靠右（「私人物品，不能烧」比较长，放名字那行会挤）
	burn.size = Vector2(212, 16)
	burn.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_bag.add_child(burn)
	_bag_w["burn"] = burn
	# 描述：按整行滚（lines_skipped / max_lines_visible，顶上不会露半行字）；滚轮或 ↑↓ 滚，日记默认翻到最新那条。
	# 右边一上一下两个小三角：上面 / 下面还有字。
	# 文字页（scripts/text_page.gd）：自己换行、自己画 1 像素的删除线 / 下划线（日记里划掉的、画线的）；按整行滚，框高正好是整数行
	var desc: Control = TEXT_PAGE.new()
	desc.position = Vector2(130, 120)
	desc.size = Vector2(212, _desc_lines() * _desc_line_h() - 2.0)
	desc.mouse_filter = Control.MOUSE_FILTER_STOP
	desc.gui_input.connect(_on_desc_input)
	_bag.add_child(desc)
	_bag_w["desc"] = desc
	# 「使用」：把选中的东西用在晨身边那个 hotspot 上（日记不能用）
	var use := Button.new()
	use.focus_mode = Control.FOCUS_NONE
	use.custom_minimum_size = Vector2(40, 16)
	use.position = Vector2(298, 61)
	use.add_theme_font_size_override("font_size", 14)
	use.pressed.connect(_on_use_item)
	_bag.add_child(use)
	_bag_w["use"] = use
	for i in 2:
		var m := Control.new()
		m.size = Vector2(5, 3)
		m.position = Vector2(344, 121 if i == 0 else 120 + DESC_H - 4)
		m.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var up := i == 0
		m.draw.connect(func():
			for r in 3:
				var w := 1 + 2 * (r if up else 2 - r)
				m.draw_rect(Rect2((5 - w) / 2, r, w, 1), UITheme.TEXT_DIM))
		_bag.add_child(m)
		_bag_w["more_up" if up else "more_down"] = m


func _bag_refresh() -> void:
	_bag_w["title"].text = I18n.t("bag")
	var fuel_ok: bool = CHAPTER_GD.info(chapter).get("hud_fuel", true) or StoryState.fuel_on()
	_bag_w["total"].text = I18n.t("burn_total") % hud_fuel() if fuel_ok else ""     # 第一关新版没有燃料表（背包标题旁边不写「10 / 200」）
	# 11-07 作者「最开始打开背包的时候，默认不显示背包的关闭按钮和火焰 icon，从第二次手动打开背包才可以关闭」：
	# 第一次 = 捡到背包后自动打开、必须先看那张照片的那一次（_first_photo_pending，本来就关不掉）。
	# 这时右上角的关闭叉和燃烧值（火焰 + 数字）都藏起来；看完照片以后再手动打开就照常显示、能关。
	var locked_open := _first_photo_pending()
	_bag_w["close"].visible = not locked_open
	_bag_w["total_row"].visible = not locked_open
	for i in _bag_slots.size():
		var b := _bag_slots[i]
		var ic: TextureRect = b.get_meta("icon")
		var required := false
		if i < Inventory.owned.size():
			ic.texture = Inventory.icon(Inventory.owned[i])
			required = _first_photo_pending() and Inventory.owned[i] == "elephant_drawing"
		else:
			ic.texture = null
		var box: StyleBoxFlat = b.get_meta("sel_box") if i == _bag_sel else b.get_meta("box")
		if required:
			box = box.duplicate()
			box.border_color = Color("#f3d481")
			box.set_border_width_all(2)
		b.add_theme_stylebox_override("normal", box)
	var big: TextureRect = _bag_w["big"]
	if _bag_sel < Inventory.owned.size():
		var it := Inventory.item(Inventory.owned[_bag_sel])
		var tex: Texture2D = Inventory.icon(Inventory.owned[_bag_sel])
		var k := maxi(1, mini(int(200 / tex.get_width()), int(42 / tex.get_height())))
		big.texture = tex
		big.size = tex.get_size() * k
		big.position = ((Vector2(212, 50) - big.size) / 2).floor()
		# 不用稀有度：名字统一一种颜色，纪念品用柔和的暖色
		_bag_w["name"].text = story.txt(it.get("name", ""))
		_bag_w["name"].add_theme_color_override("font_color", KEEPSAKE_C if str(it.get("category", "")) == "keepsake" else UITheme.TEXT)
		_bag_w["rarity"].text = ""
		_bag_w["burn"].text = _burn_line(it)
		var catl: Label = _bag_w["cat"]
		var c := str(it.get("category", ""))
		catl.text = I18n.t("cat_keepsake") if c == "keepsake" else (I18n.t("cat_quest") if c == "quest" else "")
		var nw := UITheme.font().get_string_size(str(_bag_w["name"].text), HORIZONTAL_ALIGNMENT_LEFT, -1, 14).x
		catl.position = Vector2(130.0 + nw + 4.0, 84)
		var desc: Control = _bag_w["desc"]
		var parts := _item_parts(it)
		var sig := JSON.stringify(parts)
		var iid := str(it.get("id", ""))
		if desc.get_meta("sig", "") != sig or desc.get_meta("item", "") != iid:
			if iid == "journal" and desc.get_meta("item", "") != "journal":
				_sfx("page_turn", -8.0)           # 翻开日记
			desc.set_meta("sig", sig)
			desc.set_meta("item", iid)
			desc.set_parts(parts)
			# 日记：翻到最新那条；别的从头
			_desc_goto(-1 if iid == "journal" else 0)
		_desc_marks()
		var use: Button = _bag_w["use"]
		use.text = I18n.t("use")
		use.visible = iid not in ["journal", "deer_bear"] and state == S.PLAY
		if story.item_view(iid) != "" or story.paper_viewable(iid):
			use.text = I18n.t("view")
		use.modulate = Color("#ffe097") if iid == "elephant_drawing" and _first_photo_pending() else Color.WHITE
	else:
		big.texture = null
		_bag_w["name"].text = ""
		_bag_w["rarity"].text = ""
		_bag_w["burn"].text = ""
		_bag_w["cat"].text = ""
		var empty_desc: Control = _bag_w["desc"]
		empty_desc.set_parts([{"text": I18n.t("bag_empty"), "color": DESC_C}] if Inventory.owned.is_empty() else [])
		empty_desc.set_meta("sig", "")
		_bag_w["use"].visible = false


## 物品描述：剧本文字取当前语言、空的回落中文；日记 = 按时间列出所有条目；有 desc_fixed 的修好以后换（音乐盒：musicbox_fixed）
## 物品描述（一段一段，给 text_page.gd 画）：日记 = 按时间列出所有条目（划掉的颜色淡一点、画删除线；画过线的画下划线）；
## desc_from_tag = 描述后面接上带这个 tag 的条目；有 desc_fixed 的修好以后换（音乐盒：musicbox_fixed）
func _item_parts(it: Dictionary) -> Array:
	var out: Array = []
	if str(it.get("id", "")) == "journal":
		var head: String = story.txt(it.get("desc", ""))
		if head != "":
			out.append({"text": head, "color": DESC_C})
		for e in StoryState.journal:
			out.append(_journal_part(e))
		if StoryState.journal.is_empty():
			out.append({"text": I18n.t("journal_empty"), "color": DESC_C})
		return out
	var base: String = story.txt(it.get("desc", ""))
	if it.has("desc_fixed") and StoryState.has(str(it.get("fixed_flag", "musicbox_fixed"))):
		base = story.txt(it["desc_fixed"])
	if base != "":
		out.append({"text": base, "color": DESC_C})
	var bk = it.get("back", null)
	if bk is Dictionary and StoryState.has(str(bk.get("after", ""))):
		# 双面纸（大象的画）：翻过来看过以后，描述接上背面（「地图」）
		out.append({"text": story.txt(bk.get("name", "")) + ("：" if I18n.is_zh() else ": ") + story.txt(bk.get("desc", "")), "color": DESC_C})
	if it.has("desc_from_tag"):
		var tag := str(it["desc_from_tag"])
		for e in StoryState.journal:
			if str((e as Dictionary).get("tag", "")) == tag:
				out.append(_journal_part(e))
	return out


func _journal_part(e: Dictionary) -> Dictionary:
	var struck: bool = e.get("struck", false)
	return {"text": story.txt(e), "bullet": "· ", "color": STRUCK_C if struck else DESC_C, "struck": struck,
		"marked": e.get("marked", false)}


## 详情右边那行：材料 = 燃烧值 +n；纪念品 = 烧掉可得：约 n（只显示，不提供烧的按钮）；任务物品；其他私人物品照旧
func _burn_line(it: Dictionary) -> String:
	var c := str(it.get("category", ""))
	if c == "keepsake" and it.has("keepsake_burn"):
		return I18n.t("keepsake_burn") % int(it["keepsake_burn"])
	if c == "quest":
		return I18n.t("quest_item")
	if it.get("personal", false):
		return I18n.t("personal")
	return I18n.t("burn_value") % int(it.get("burn", 0))


## 背包「使用」
func _on_use_item() -> void:
	if _bag_sel >= Inventory.owned.size():
		return
	var id := Inventory.owned[_bag_sel]
	if id == "deer_bear":
		return
	var vs: String = story.item_view(id)
	if _first_photo_pending() and id != "elephant_drawing":
		return
	_close_panels(id == "elephant_drawing" and vs != "")
	if vs != "":
		story.play(vs)                                # 剧本 item_views：大象的画 → 全屏看画 → 闪回
		return
	if story.paper_viewable(id):
		_bag_after_story = true                       # 看完收起回到背包、还选着这张照片
		story.view_paper(id)                          # 双面纸：任何章节、任何时候「查看」= 全屏看、能翻到地图
		return
	story.use_item(id)


const DESC_H := 88.0


func _desc_line_h() -> float:
	return UITheme.font().get_height(14) + 2.0


func _desc_lines() -> int:
	return maxi(1, int((DESC_H + 2.0) / _desc_line_h()))


func _desc_max_skip() -> int:
	var desc: Control = _bag_w["desc"]
	return desc.max_skip()


## 翻到第 n 行（-1 = 最后一屏）
func _desc_goto(n: int) -> void:
	var desc: Control = _bag_w["desc"]
	if n < 0:
		n = _desc_max_skip()
	desc.skip = clampi(n, 0, _desc_max_skip())
	_desc_marks()


func _desc_scroll(d: int) -> bool:
	var desc: Control = _bag_w["desc"]
	var cur: int = desc.skip
	var n := clampi(cur + d, 0, _desc_max_skip())
	if n == cur:
		return _desc_max_skip() > 0
	_desc_goto(n)
	if desc.get_meta("item", "") == "journal":
		_sfx("page_turn", -16.0, 1.2)
	return true


func _desc_marks() -> void:
	var desc: Control = _bag_w["desc"]
	var cur: int = desc.skip
	(_bag_w["more_up"] as Control).visible = cur > 0
	(_bag_w["more_down"] as Control).visible = cur < _desc_max_skip()


func _on_desc_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP:
			_desc_scroll(-1)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_desc_scroll(1)


func _bag_select(i: int) -> void:
	_bag_sel = i
	_bag_refresh()


# ---------------------------------------------------------------- 文字（换语言时整体刷新）
func _retext() -> void:
	_title_label.text = I18n.t("title")
	_title_sub.text = I18n.t("title_sub")
	_start_btn.text = I18n.t("start")
	_skip_label.text = I18n.t("skip_again")
	_layout_title()
	for l in _lang_btns:
		var on: bool = l == GameSettings.lang
		(_lang_btns[l] as Button).add_theme_color_override("font_color", LANG_ON if on else LANG_OFF)
		(_lang_btns[l] as Button).mouse_default_cursor_shape = Control.CURSOR_ARROW if on else Control.CURSOR_POINTING_HAND
	_even(_burn_pop_sub, _burn_pop_sub.text, 14)
	_burn_pop_sub.text = I18n.t("to_launch") % Inventory.get_launch_burn()
	_update_hud()
	var w := _settings_widgets
	w["title"].text = I18n.t("settings")
	for k in ["language", "vol_master", "vol_music", "vol_sfx", "quality", "fullscreen"]:
		w["lbl_" + k].text = I18n.t(k)
	w["lang_a"].text = I18n.LANG_NAMES["en"]
	w["lang_b"].text = I18n.LANG_NAMES["zh"]
	for pre in ["q", "fs"]:
		var keys: Array = w[pre + "_keys"]
		w[pre + "_a"].text = I18n.t(keys[0])
		w[pre + "_b"].text = I18n.t(keys[1])
	w["close"].text = I18n.t("close")
	w["credits"].text = I18n.t("credits")
	w["back_title"].text = I18n.t("back_to_title")
	if _dlg_on and _dlg.has_meta("key"):
		_dlg_name.text = I18n.t(_dlg.get_meta("who"))
		_dlg_text.text = I18n.t(_dlg.get_meta("key"))
	if _bag.visible:
		_bag_refresh()
	# 设置面板的大小跟着文字变：重新居中
	_settings.reset_size()
	_center_settings.call_deferred()


## 标题界面三样东西水平居中（按整像素；拉开字距以后最后一个字后面那截字距不算）
func _layout_title() -> void:
	var f_title := UITheme.spaced_font(_title_spacing())
	_title_label.add_theme_font_override("font", f_title)
	_center_x(_title_label, f_title, _title_label.text, 42, _title_spacing())
	var f_sub := UITheme.spaced_font(SUB_SPACING)
	_title_sub.add_theme_font_override("font", f_sub)
	var sw := _center_x(_title_sub, f_sub, _title_sub.text, 14, SUB_SPACING)
	var mid := _title_sub.position.y + 7.0
	_title_lines[0].position = Vector2(_title_sub.position.x - 10.0 - _title_lines[0].size.x, mid)
	_title_lines[1].position = Vector2(_title_sub.position.x + sw + 10.0, mid)
	var bw := _center_x(_start_btn, UITheme.spaced_font(START_SPACING), _start_btn.text, 14, START_SPACING)
	_start_btn.size = Vector2(bw + START_SPACING, 20)
	_start_btn.position.y = START_Y
	_credits_btn.text = I18n.t("credits")
	var cw := _center_x(_credits_btn, UITheme.spaced_font(START_SPACING), _credits_btn.text, 12, START_SPACING)
	_credits_btn.size = Vector2(cw + START_SPACING, 18)
	_credits_btn.position.y = START_Y + 24.0


## 中文标题只有一个字，字距没用；英文拉开 3 像素（= 42 号字的 1 格）
func _title_spacing() -> int:
	return 0 if I18n.is_zh() else TITLE_SPACING


## 让 l 的文字在 cx 处水平居中（整像素），返回字宽（不含最后那截字距）
func _center_x(l: Control, f: Font, text: String, size: int, spacing: int, cx := 240.0) -> float:
	var w := f.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x - spacing
	l.position.x = floor(cx - w / 2.0)
	l.size.x = w + spacing + 2.0
	return w


## 居中的单行字：让「框宽 - 字宽」是偶数，字的像素格才和画面的像素格对齐（否则差半格）
func _even(l: Control, text: String, font_size: int) -> void:
	var w := UITheme.font().get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var base: float = l.get_meta("base_w", l.size.x)
	l.set_meta("base_w", base)
	l.size.x = base + float(int(round(base - w)) % 2)


func _center_settings() -> void:
	_settings.reset_size()
	_settings.position = ((Vector2(480, 270) - _settings.size) / 2).floor()


func _update_hud() -> void:
	_hud_burn_label.text = I18n.t("burn_total") % hud_fuel()


## 左上角燃料表的两个数 [现在, 需要]：飞行段（剧本 fuel 步骤设过 fuel_need）用 StoryState 的燃料，森林照旧按背包算
func hud_fuel() -> Array:
	if StoryState.fuel_on():
		var have := StoryState.fuel() if _fuel_shown < 0.0 else int(round(_fuel_shown))
		return [have, StoryState.fuel_need()]
	return [Inventory.burn_total(), Inventory.get_launch_burn()]


## 剧本 fuel 步骤 / 避碎石撞了一下以后调：燃料表亮起来，数字从旧的滚到新的（tick 声）；需要的量变了闪一下
func fuel_changed(from: int, need_from: int) -> void:
	_hud_burn.modulate.a = 1.0
	var to := StoryState.fuel()
	if _fuel_tw != null and _fuel_tw.is_valid():
		_fuel_tw.kill()
	if story != null and story.ff:
		_fuel_shown = -1.0
		_update_hud()
		return
	_fuel_tw = create_tween()
	if need_from != StoryState.fuel_need():
		_hud_burn_label.modulate = Color(1.7, 1.6, 1.3)
		_fuel_tw.tween_property(_hud_burn_label, "modulate", Color.WHITE, 0.6)
	if from != to:
		_fuel_shown = float(from)
		_fuel_tw.tween_method(_set_fuel_shown, float(from), float(to), clampf(absf(to - from) * 0.025, 0.2, 1.2))
	_fuel_tw.tween_callback(func():
		_fuel_shown = -1.0
		_update_hud())
	_update_hud()


func _set_fuel_shown(v: float) -> void:
	if int(round(v)) != int(round(_fuel_shown)) and int(round(v)) % 3 == 0:
		_sfx("tick", -16.0, 1.0)
	_fuel_shown = v
	_update_hud()


## 左上角「当前目标」（剧本顶层 objectives，第一个满足条件的）：show_fuel = 目标 + 燃烧值，不然只有目标。
## 换目标时淡入、翻页声。没有 objectives（或一条都不满足）就照旧只有燃烧值。开场（坠毁之前）不显示。
func _update_objective() -> void:
	if state in [S.HEADPHONES, S.INTRO, S.TITLE, S.CRASH] or not StoryState.has("crashed"):
		return
	# 新版开场：先看演出和想法，问完小鹿背包的事才给任务；不提前露出旧版燃料目标。
	var opening := chapter == "forest" and StoryState.has("c1_crashed") and not StoryState.has("c1_asked_bag") and not StoryState.has("c1_got_bag")
	_hud_burn.visible = not opening
	if opening:
		return
	var o: Dictionary = story.objective()
	var side_lines: PackedStringArray = []
	for so in story.side_objectives(chapter == "forest"):
		var line: String = story.txt(so)
		side_lines.append("•  " + ("[s]" + line + "[/s]" if so.get("completed", false) else line))
	if chapter == "forest" and StoryState.has("c1_rabbit_done"):
		var practice := I18n.pick({"zh": "陪兔子练舞", "en": "Practice dancing with the rabbit"})
		side_lines.append("•  " + ("[s]" + practice + "[/s]" if StoryState.has("c1_rabbit_helped") else practice))
	var side_line := ""
	if not side_lines.is_empty():
		side_line = I18n.pick({"zh": "支线", "en": "Side quests"}) + "\\n" + "\\n".join(side_lines)
	if chapter == "forest" and StoryState.has("c1_fixed"):
		side_line = "[font_size=13][s]" + I18n.pick({"zh": "修好飞船", "en": "Repair the ship"}) + "[/s][/font_size]\n" + side_line
	var key: String = str(not side_line.is_empty()) if o.is_empty() else str(story.txt(o)) + "|" + str(o.get("show_fuel", false))
	if _hud_side.text != side_line:
		_hud_side.text = side_line
		if side_line != "" and not _hud_side.visible:
			_hud_side.modulate.a = 0.0
			create_tween().tween_property(_hud_side, "modulate:a", 0.75, 0.6)
		_hud_side.visible = side_line != ""
	if key == _obj_key:
		return
	var first := _obj_key == "-"
	_obj_key = key
	if o.is_empty():
		_hud_obj.text = I18n.pick({"zh": "主线已完成", "en": "Main objective complete"}) if not side_line.is_empty() else ""
		_hud_obj.visible = not side_line.is_empty()
		var fuel_ok: bool = CHAPTER_GD.info(chapter).get("hud_fuel", true)    # 河流篇没有燃料表
		_hud_flame.visible = fuel_ok
		_hud_burn_label.visible = fuel_ok
		return
	_hud_obj.text = (I18n.pick({"zh": "主线 · ", "en": "Main · "}) if chapter == "forest" else "") + story.txt(o)
	_hud_obj.visible = true
	var fuel: bool = o.get("show_fuel", false)
	_hud_flame.visible = fuel
	_hud_burn_label.visible = fuel
	_update_hud()
	_hud_burn.modulate.a = 0.0
	create_tween().tween_property(_hud_burn, "modulate:a", 1.0, 0.6)
	if not first:
		_sfx("page_turn", -10.0)


# ======================================================================= 定时事件 / tween
func _run(events: Array) -> void:
	_seq = events
	_seq.sort_custom(func(a, b): return a[0] < b[0])
	_seq_t = 0.0


func _tw() -> Tween:
	var tw := create_tween()
	_tweens.append(tw)
	return tw


func _kill_cine() -> void:
	if is_instance_valid(_getup_qte):
		_getup_qte.cancel()
	_getup_qte = null
	_seq.clear()
	for tw in _tweens:
		if tw.is_valid():
			tw.kill()
	_tweens.clear()
	if is_instance_valid(_crash_bag):
		_crash_bag.queue_free()
	_crash_bag = null


func _set_state(s: S) -> void:
	state = s
	_state_t = 0.0


# ======================================================================= 1. 耳机提示
func _enter_headphones() -> void:
	_set_state(S.HEADPHONES)
	fade.color.a = 1.0
	_hp_root.modulate.a = 0.0
	var tw := _tw()
	tw.tween_interval(0.3)
	tw.tween_callback(_start_headphone_rain)
	tw.tween_property(_hp_root, "modulate:a", 1.0, 1.2)
	tw.tween_interval(1.2)
	tw.tween_callback(_leave_headphones)


func _start_headphone_rain() -> void:
	_opening_filter_to(OPENING_CLEAR_HZ)
	_title_rain_in(1.2)


func _leave_headphones() -> void:
	if state != S.HEADPHONES:
		return
	_set_state(S.INTRO)
	_title_bg_on()
	var tw := _tw()
	tw.tween_property(_hp_root, "modulate:a", 0.0, 0.8)
	_run([
		[1.8, func(): _opening_sfx("thunder_near_1", -16.0)],
		[4.4, func(): _opening_sfx("thunder_near_2", -17.0)],
		[5.4, _fade_from_black],
		[7.6, _show_title],
	])


func _title_rain_in(sec: float) -> void:
	if not _title_rain.playing:
		_title_rain.play()
	_fade_db(_title_rain, TITLE_RAIN_DB, sec)


func _opening_rain_to(alpha: float, sec: float) -> void:
	if not is_instance_valid(_opening_rain_fx):
		if alpha == 0.0:
			return
		# 沿用城市细雨的柔边雨丝，放在森林暗角、闪电和界面下面。
		var fx := preload("res://scripts/city_rain.gd").new()
		fx.name = "OpeningRain"
		fx.amount = 240
		fx.lifetime = 1.9
		fx.seed = 81
		fx.area = Rect2(-32, -12, 544, 290)
		fx.bottom = 278.0
		fx.y_dim = 278.0
		fx.speed = 132.0
		fx.slant = 0.14
		fx.length = 10.0
		fx.width = 1.3
		fx.color = Color(0.66, 0.70, 0.82, 0.55)
		fx.modulate.a = 0.0
		_opening_sky_layer().add_child(fx)
		_opening_sky_layer().move_child(fx, 0)
		_opening_rain_fx = fx
	if _opening_rain_tw != null and _opening_rain_tw.is_valid():
		_opening_rain_tw.kill()
	if alpha == 0.0 and sec == 0.0:
		_opening_rain_fx.queue_free()
		_opening_rain_fx = null
		return
	_opening_rain_tw = _opening_rain_fx.create_tween()
	_opening_rain_tw.tween_property(_opening_rain_fx, "modulate:a", alpha, sec)
	if alpha == 0.0:
		_opening_rain_tw.tween_callback(func():
			_opening_rain_fx.queue_free()
			_opening_rain_fx = null)


## 雨和下落时闪电冷光的那一层（见 _opening_sky 的说明）。第一次用时建。
func _opening_sky_layer() -> CanvasLayer:
	if _opening_sky == null:
		_opening_sky = CanvasLayer.new()
		_opening_sky.name = "OpeningSky"
		_opening_sky.layer = SKY_LAYER_DESCENT if _title_bg != null else SKY_LAYER_FOREST
		add_child(_opening_sky)
		_sky_flash = ColorRect.new()
		_sky_flash.name = "SkyFlash"
		_sky_flash.size = Vector2(480, 270)
		_sky_flash.color = Color(FLASH_TINT, 0.0)
		_sky_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_opening_sky.add_child(_sky_flash)
	return _opening_sky


func _opening_filter_to(hz: float, sec := 0.0) -> void:
	if _opening_filter_tw != null and _opening_filter_tw.is_valid():
		_opening_filter_tw.kill()
	if sec <= 0.0:
		_opening_filter.cutoff_hz = hz
		return
	# 按对数扫频，穿过云层时高频逐步回来。
	_opening_filter_tw = _tw()
	_opening_filter_tw.tween_method(
		func(value: float): _opening_filter.cutoff_hz = exp(value),
		log(_opening_filter.cutoff_hz), log(hz), sec
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _wind_in(sec := 3.5) -> void:
	if not _title_wind.playing:
		_title_wind.play()
	_fade_db(_title_wind, TITLE_WIND_DB, sec)


## 开始界面的背景（云层小镇）：盖在森林上面。森林这时候反正看不见，那几张满屏的图和雾先不画（手机上省一半填充）
func _title_bg_on() -> void:
	if _title_bg != null:
		return
	_title_bg = (load("res://scripts/title_cloud.gd") as GDScript).new()
	_title_bg.name = "TitleCloud"
	add_child(_title_bg)
	_title_forest_visible(false)


func _title_forest_visible(on: bool) -> void:
	for n in TITLE_HIDE_LAYERS:
		(get_node(n) as CanvasItem).visible = on


## 背景拿掉（落完了，或者跳关直接跳过了标题）
func _title_bg_off() -> void:
	if _title_bg == null:
		return
	_title_bg.queue_free()
	_title_bg = null
	_title_forest_visible(true)
	if _opening_sky != null:
		_opening_sky.layer = SKY_LAYER_FOREST
	if _title_wind.playing:
		_fade_db(_title_wind, -60.0, 1.2).tween_callback(_title_wind.stop)
	if _title_rain.playing:
		_fade_db(_title_rain, -60.0, 3.5).tween_callback(_title_rain.stop)


func _fade_from_black() -> void:
	_opening_filter_to(OPENING_CLOUD_HZ, 2.2)
	if not _title_wind.playing:
		_wind_in(2.2)
	_tw().tween_property(fade, "color:a", 0.0, 3.2).set_trans(Tween.TRANS_SINE)


# ======================================================================= 2. 标题
func _show_title() -> void:
	_set_state(S.TITLE)
	_title_thunder_at = 7.0
	_title_root.visible = true
	_title_root.modulate.a = 1.0
	_title_k = 0.0
	_title_label.modulate.a = 0.0
	_title_sub.modulate.a = 0.0
	_start_btn.modulate.a = 0.0
	_credits_btn.modulate.a = 0.0
	_lang_corner.modulate.a = 0.0
	for ln in _title_lines:
		ln.modulate.a = 0.0
	# 标题先慢慢浮出来（2.6 秒，同时往上飘 3 像素），副标题晚 0.8 秒，「开始」再晚一点
	var tw := _tw()
	tw.tween_property(self, "_title_k", 1.0, 2.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(_title_sub, "modulate:a", 1.0, 1.6).set_delay(0.8)
	tw.parallel().tween_property(_title_lines[0], "modulate:a", 1.0, 1.6).set_delay(0.8)
	tw.parallel().tween_property(_title_lines[1], "modulate:a", 1.0, 1.6).set_delay(0.8)
	tw.parallel().tween_property(_start_btn, "modulate:a", 1.0, 1.2).set_delay(1.6)
	tw.parallel().tween_property(_credits_btn, "modulate:a", 0.85, 1.2).set_delay(2.0)
	tw.parallel().tween_property(_lang_corner, "modulate:a", 1.0, 1.2).set_delay(1.6)
	# 不抢焦点：不然「开始」一出来就是高亮的。Enter / 空格照样能开始（见 _input），按方向键才聚焦。


func _skip_to_title() -> void:
	_kill_cine()
	_hp_root.modulate.a = 0.0
	fade.color.a = 0.0
	_title_bg_on()
	_opening_filter_to(OPENING_CLOUD_HZ)
	_title_rain_in(1.2)
	_wind_in(1.2)                                      # 跳过片头也淡进来，不一下子响
	_show_title()
	_kill_cine()
	_title_k = 1.0
	_title_sub.modulate.a = 1.0
	for ln in _title_lines:
		ln.modulate.a = 1.0
	_start_btn.modulate.a = 1.0
	_credits_btn.modulate.a = 0.85
	_lang_corner.modulate.a = 1.0


## 「全剧终」→ 制作人员放完（story_runner._credits_roll 调）：回标题 = 新游戏。名单页已经淡到黑；
## 还在响的长声音淡掉，重新载入后标题从黑里淡出来（_title_fade_in），一路不硬切。
const TITLE_FADE_META := "level_forest_title_fade"


func title_after_credits() -> void:
	(load("res://scripts/bgm.gd") as GDScript).get_bgm(get_tree()).forget()
	CHAPTER_GD.reset()
	Engine.set_meta(TITLE_FADE_META, true)
	if _story_auto != "":                      # 自测带着 --chapter=final：重新载入时别又进终章
		Engine.set_meta(CHAPTER_GD.PICK_META, true)
		Engine.set_meta(CHAPTER_GD.CHAPTER_META, "forest")
	(load("res://scripts/audio_fade.gd") as GDScript).release(self, 0.8)
	get_tree().reload_current_scene.call_deferred()


## 设置面板「返回标题」（11-06 作者）：和全剧终回标题同一条路（title_after_credits → _title_fade_in）。设置 = 暂停，游戏就停在这里：
## 整屏淡到黑（面板一起被盖住）；配乐慢慢淡掉，开始界面的风同时淡进来（根节点上临时一个，换场景不断，新关卡的风起来时它再淡掉），不留真空；
## 被暂停住的音效、环境声本来就没声音，音量悄悄收掉再取消暂停。没有存档，回标题 = 新游戏。
const BACK_VEIL := 0.8


func _back_to_title() -> void:
	if _leaving_title:
		return
	_leaving_title = true
	_sfx("ui_click", -10.0)
	print("BACK_TO_TITLE chapter=%s scene=%s" % [chapter, str(story._cur_scene)])
	(load("res://scripts/bgm.gd") as GDScript).get_bgm(get_tree()).stop(BACK_VEIL + 3.2)
	(load("res://scripts/audio_fade.gd") as GDScript).silence(self, BACK_VEIL)
	var w := AudioStreamPlayer.new()
	w.stream = _title_wind.stream
	w.bus = GameSettings.OPENING_BUS
	w.volume_db = -60.0
	w.process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().root.add_child(w)
	w.play()
	var wt := get_tree().create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	wt.tween_property(w, "volume_db", TITLE_WIND_DB, 1.0).set_trans(Tween.TRANS_SINE)
	wt.tween_interval(BACK_VEIL - 0.4)
	wt.tween_property(w, "volume_db", -60.0, 2.8).set_trans(Tween.TRANS_SINE)
	wt.tween_callback(w.queue_free)
	var veil := ColorRect.new()
	veil.color = Color(0, 0, 0, 0)
	veil.set_anchors_preset(Control.PRESET_FULL_RECT)
	veil.mouse_filter = Control.MOUSE_FILTER_STOP
	_pause_gate.ui_root.add_child(veil)
	var vt := veil.create_tween()                  # 这一层暂停时也走
	vt.tween_property(veil, "color:a", 1.0, BACK_VEIL).set_trans(Tween.TRANS_SINE)
	vt.tween_interval(0.1)
	vt.tween_callback(title_after_credits)         # 还暂停着换场景（_title_fade_in 才取消）：旧场景里等着的剧情不会被叫醒


func _title_fade_in() -> void:
	get_tree().paused = false                  # 从设置返回标题时一直暂停到这里
	_kill_cine()                               # 11-07 作者「返回标题……耳机还消不掉」：原来 _ready 先播了耳机的淡入 tween，这里只把透明度置 0，
	_set_state(S.INTRO)                        # tween 0.3 秒后又把提示淡到 1，压在标题上；状态已经不是 HEADPHONES，点哪都关不掉
	_hp_root.modulate.a = 0.0
	fade.color.a = 1.0
	_title_bg_on()
	_opening_filter_to(OPENING_CLOUD_HZ)
	_title_rain_in(2.8)
	_wind_in(2.8)                              # 环境音马上开始淡进来，和还在淡掉的片尾音乐交叉（不留真空）
	_run([
		[0.4, _fade_from_black],
		[1.0, _show_title],
	])
	if _story_auto != "":                      # 自测：看到标题就算走完（不然自动玩会按「开始」又玩一遍）；--title_again：接着按「开始」再玩一局
		get_tree().create_timer(1.9, false).timeout.connect(func():
			print("TITLE_AFTER_CREDITS state=%s fade=%.2f headphones=%.2f" % [S.keys()[state], fade.color.a, _hp_root.modulate.a])
			if not "--title_again" in OS.get_cmdline_user_args():
				get_tree().quit())
		get_tree().create_timer(4.0, false).timeout.connect(func():
			print("TITLE_AFTER_CREDITS +4s state=%s headphones=%.2f" % [S.keys()[state], _hp_root.modulate.a]))


func _open_credits() -> void:
	if _credits_page != null or (state in [S.HEADPHONES, S.INTRO, S.CRASH, S.CINE] and not _settings.visible):
		return
	var input_was: bool = chen.input_enabled   # 设置是剧情中途开的：回来还是原样，不把晨的输入打开
	var back: Control = _credits_btn if state == S.TITLE else _settings_widgets["credits"]
	_settings.visible = false
	_bag.visible = false
	_dim.visible = false
	_sett_dim.visible = false
	_sfx("ui_click", -10.0)
	chen.input_enabled = false
	_credits_page = (load("res://scripts/credits_page.gd") as GDScript).new()
	_credits_page.process_mode = Node.PROCESS_MODE_ALWAYS   # 从设置进来时游戏是暂停的；关掉回到设置，还是暂停
	_settings.get_parent().add_child(_credits_page)
	_credits_page.closed.connect(func():
		_credits_page = null
		_sfx("ui_click", -12.0, 0.85)
		chen.input_enabled = input_was
		if back == _credits_btn:
			if get_viewport().gui_get_focus_owner() != null:
				_credits_btn.grab_focus()
		else:
			_open_settings())


func _on_start() -> void:
	if state != S.TITLE or _settings.visible or _credits_page != null or _state_t < 0.3:
		return
	_sfx("ui_click", -8.0)
	_start_descent()


# ======================================================================= 3. 开场动画
func _hide_title() -> void:
	_title_root.visible = false


## 点开始：画面往下落（title_cloud.gd），穿过云层到全黑，再落就是森林。声音：风落到一半慢慢没了，鸟叫（森林的环境音）在全黑之前
## 就淡进来，两边交叠；全黑那一段响一声远雷。落到位接坠毁开场。
func _start_descent() -> void:
	if _title_bg == null or not _title_bg.has_method("descend"):
		_start_crash()
		return
	_set_state(S.CRASH)
	_start_btn.release_focus()
	var tw := _tw()
	tw.tween_property(_title_root, "modulate:a", 0.0, 0.6)
	tw.tween_callback(_hide_title)
	_title_forest_visible(true)              # 这一下如果卡，也卡在刚点的时候，下面还盖着小镇
	set_meta("qa_skip_t", story._game_t if story != null else 0.0)     # --qa_live：镜头这一下跳到落下去的高度，上面盖着整张小镇，看不见
	cam.position.x = TITLE_CAM_X
	_title_bg.descend(DESCENT_SEC)
	_descended = true
	_opening_filter_to(OPENING_CLEAR_HZ, DESCENT_SEC * 0.88)
	# 11-07 作者：雨不是落到底才有，一进云层就开始下（先稀、越往下越密，落到全黑之前已经是满的）；
	# 一路三次闪电：云里远的一下（暗、雷声晚到）→ 全黑里一下（整屏冷光）→ 快到林冠时近的一下（亮、雷几乎同时）。
	# 闪电的亮度和颜色跟坠毁时的 _flash 一样（偏青蓝的冷光，不是白闪）。
	_run([
		[DESCENT_SEC * 0.12, func(): _opening_rain_to(0.45, DESCENT_SEC * 0.25)],
		[DESCENT_SEC * 0.18, func(): _fade_db(_title_wind, -60.0, DESCENT_SEC * 0.5)],
		[DESCENT_SEC * 0.30, func(): _flash(0.35)],
		[DESCENT_SEC * 0.30 + 0.45, func(): _opening_sfx("thunder_near_2", -19.0, 0.9)],
		[DESCENT_SEC * 0.40, func(): _opening_rain_to(1.0, DESCENT_SEC * 0.3)],
		[DESCENT_SEC * 0.52, func(): _flash(0.7)],
		[DESCENT_SEC * 0.52 + 0.2, func(): _opening_sfx("thunder_near_3", -15.0, 0.95)],
		[DESCENT_SEC * 0.64, func():
			_rain.volume_db = -60.0
			_rain.play()
			_fade_db(_rain, RAIN_DB, DESCENT_SEC * 0.55)],
		[DESCENT_SEC * 0.70, func(): _flash(1.0)],
		[DESCENT_SEC * 0.72, func(): _opening_sfx("thunder_near_1", -12.0)],
	])


func _start_crash() -> void:
	_opening_filter_to(OPENING_CLEAR_HZ)
	_title_bg_off()
	if _title_rain.playing:                   # 11-07：雨声不随小镇一起淡掉，留到起身 QTE 里和雨丝一起停（qte_weather）
		_fade_db(_title_rain, CRASH_RAIN_DB, 1.0)
	_opening_rain_to(1.0, 0.65)
	if not _rain.playing:                     # 跳关直接到这（--stage、--beat）：没走下落
		_rain.play()
		_fade_db(_rain, RAIN_DB, 1.2)
	_set_state(S.CRASH)
	_start_btn.release_focus()
	var tw := _tw()
	tw.tween_property(_title_root, "modulate:a", 0.0, 0.6)
	tw.tween_callback(_hide_title)
	var tc := _tw()
	tc.tween_property(cam, "position:x", TITLE_CAM_X, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	# 11-07 作者：落到底、停住以后才进电影视角（黑边 BARS_SEC 滑入），黑边到位再等 SHIP_WAIT 秒飞船才进来。
	# 打雷挪到了下落途中（_start_descent）；这里只在跳关直接到坠毁（没走下落）时补那三下闪电，不然开场一声雷都没有。
	_bars_in(BARS_SEC)
	var seq: Array = []
	if not _descended:
		seq += [
			[0.7, func(): _flash(0.6)],
			[0.78, func(): _opening_sfx("thunder_near_1", -11.0)],
			[1.3, func(): _flash(0.3)],
			[1.36, func(): _opening_sfx("thunder_near_2", -14.0, 1.05)],
			[2.15, func(): _flash(1.0)],
			[2.2, func(): _opening_sfx("thunder_near_3", -10.0, 0.95)],
		]
	seq += [
		[SHIP_AT, _ship_in],
		[SHIP_AT + SHIP_TIME, _impact],
		[SHIP_AT + SHIP_TIME + ALIEN_THROW_DELAY, _alien_thrown if ALIEN_IN_FOREST else func(): pass],
		[ALIEN_GETUP_AT, _alien_get_up if ALIEN_IN_FOREST else func(): pass],
		[SHIP_AT + SHIP_TIME + THROW_T + THROW_SETTLE + 0.25, _begin_getup_qte],
	]
	_run(seq)


const SHIP_TIME := 2.4
const BARS_SEC := 0.8                     # 落到底以后电影黑边滑入多久
const SHIP_WAIT := 2.0                    # 11-07 作者：黑边到位后等这么久飞船才进来
const SHIP_AT := BARS_SEC + SHIP_WAIT     # 飞船进场（相对 _start_crash）。原来是 2.75
const DESCENT_SEC := 7.5                  # 开始界面落到森林：760 像素，最快约 150 像素 / 秒
const OPENING_CLEAR_HZ := 18000.0
const OPENING_CLOUD_HZ := 2300.0
const TITLE_RAIN_DB := -5.0
const CRASH_RAIN_DB := -9.0               # 落进森林以后的雨声（比标题时退一点，让鸟叫、雷、飞船出来）
const TITLE_WIND_DB := -27.0              # 云风只作标题背景，雨声在前
const TITLE_HIDE_LAYERS := ["Sky", "Ridge", "Far", "MidFar", "Mid", "Main", "Front"]    # 标题盖着时不画的满屏层


func _flash(peak: float) -> void:
	# 天光从林冠后面亮一下：很快亮起、闪一下、再慢慢退（退得比原来慢，更柔）
	var tw := _tw()
	tw.tween_property(self, "_flash_k", peak, 0.05).set_trans(Tween.TRANS_SINE)
	tw.tween_property(self, "_flash_k", peak * 0.35, 0.08)
	tw.tween_property(self, "_flash_k", peak * 0.8, 0.06)
	tw.tween_property(self, "_flash_k", 0.0, 0.9).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _apply_flash() -> void:
	var k := _flash_k
	for n in FLASH_LAYERS:
		var g: float = FLASH_LAYERS[n] * k
		(get_node(n) as CanvasItem).modulate = Color(1.0 + FLASH_GAIN.r * g, 1.0 + FLASH_GAIN.g * g, 1.0 + FLASH_GAIN.b * g)
	if _impact_k > 0.0:
		flash.color = Color(IMPACT_TINT, _impact_k * 0.16)
	else:
		flash.color = Color(FLASH_TINT, k * FLASH_TINT_A)
	# 下落途中：森林被开始界面盖着，闪电提亮的是小镇 / 云层那张图（同样偏青蓝），再加一层比森林稍厚的冷光（全黑那段只有它看得见）
	var tb: Node2D = _title_bg.get("_root") if _title_bg != null else null
	if tb != null:
		var g2 := k * 0.8
		tb.modulate = Color(1.0 + FLASH_GAIN.r * g2, 1.0 + FLASH_GAIN.g * g2, 1.0 + FLASH_GAIN.b * g2)
	if _sky_flash != null:
		_sky_flash.color = Color(FLASH_TINT, k * SKY_FLASH_A if _title_bg != null else 0.0)


# 飞船飞行图的中心到机头 / 喷口（tools/level1_art.py 跑完会打印这些数：斜 16°，船长 140）
const SHIP_NOSE := Vector2(-66, 23)
const SHIP_ENGINE := Vector2(71, -22)
# 坠毁图（斜 17°）里几个点，相对 wreck 锚点（船身中心的 x、地面）
const WRECK_NOSE := Vector2(-59, 0)       # 机头扎进土里的地方
const WRECK_HATCH := Vector2(20, -25)     # 舱门（没了），两个人从这里被甩出来
const WRECK_HOLE := Vector2(-1, -5)       # 船腹的破洞（余火）
const WRECK_ENGINE := Vector2(69, -36)    # 喷口（翘起来的那头，冒主烟柱）
const WRECK_FIN := Vector2(43, -52)       # 尾翼断口
const WRECK_CENTER := Vector2(0, -14)     # 船身中心（飞行图最后对齐到这，换成坠毁图时不跳）
# 另一个外星人：比晨晚一点被甩出来（弧线低、落得近），比晨早一点爬起来
const ALIEN_THROW_DELAY := 0.16
const ALIEN_THROW_TIME := 0.5
const ALIEN_GETUP_AT := SHIP_AT + 4.15    # 原来 6.9（飞船 2.75 进场时）；晨是飞船进场后 5.65 秒


func _ship_end() -> Vector2:
	# 最后一帧：飞行图的船身中心对上坠毁图的船身中心（稍微高一点，机头刚碰到地面）
	return Vector2(WRECK_X, _ground(WRECK_X)) + WRECK_CENTER + Vector2(0, -4)


func _ship_start() -> Vector2:
	return Vector2(cam.position.x + 240 + 110, -6)


func _ship_in() -> void:
	ship.visible = true
	ship.frame = 0
	ship.position = _ship_start()
	_opening_sfx("ship_whoosh", -12.0)
	puffs_back.add_source("trail", ship.position + SHIP_ENGINE, 46.0, puffs_back.PRESETS.trail)
	puffs_back.add_source("trail_sparks", ship.position + SHIP_ENGINE, 10.0, puffs_back.PRESETS.ember)
	_path_a = _ship_start()
	_path_b = _ship_end()
	_tw().tween_method(_ship_step, 0.0, 1.0, SHIP_TIME).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


var _path_a := Vector2.ZERO
var _path_b := Vector2.ZERO


func _ship_step(k: float) -> void:
	# 稍微往下弯的弧线，越来越快
	var p := _path_a.lerp(_path_b, k)
	p.y += sin(k * PI) * 10.0
	ship.position = p.round()
	puffs_back.set_source_pos("trail", ship.position + SHIP_ENGINE)
	puffs_back.set_source_pos("trail_sparks", ship.position + SHIP_ENGINE)


var _crash_bag: Sprite2D                  # 撞击时甩出的背包，跳过演出时一起清理


func _impact() -> void:
	ship.visible = false
	puffs_back.remove_source("trail")
	puffs_back.remove_source("trail_sparks")
	_show_wreck()
	var nose := wreck.position + WRECK_NOSE
	_opening_sfx("ship_impact", -7.0)
	_shake = 0.9
	_shake_amp = 6.0
	_flash_k = 0.0
	# 船大了，尘土和烟团也铺得开一点：机头那一大团，船腹擦地那一线
	puffs_front.burst(nose, 40, puffs_front.PRESETS.dust.merged({"spread": Vector2(16, 1)}))
	puffs_front.burst(nose + Vector2(46, 0), 22, puffs_front.PRESETS.dust.merged({"spread": Vector2(30, 1)}))
	puffs_back.burst(nose + Vector2(14, -10), 22, puffs_back.PRESETS.smoke_burst.merged({"spread": Vector2(16, 6)}))
	puffs_back.burst(wreck.position + WRECK_HOLE + Vector2(0, -8), 14, puffs_back.PRESETS.smoke_burst)
	puffs_front.burst(nose + Vector2(10, -6), 12, puffs_front.PRESETS.ember)
	var tw := _tw()
	_impact_k = 0.0
	tw.tween_property(self, "_impact_k", 1.0, 0.03)
	tw.tween_property(self, "_impact_k", 0.0, 0.4)
	_chen_thrown()
	preload("res://scripts/bag_burst.gd").launch(self, story.world)


func _show_wreck() -> void:
	wreck.visible = true
	wreck.texture = WRECK_TEX          # 起飞时换成过土坑（ship_crater.png），重开时换回来
	wreck.hframes = 1
	wreck.frame = 0
	# 主烟柱从喷口（翘起来的那头）冒，船腹破洞和舱门口各冒一点；火星很少，从破洞和喷口出来
	var tail := wreck.position + WRECK_ENGINE
	puffs_back.add_source("wreck", tail, 11.0, puffs_back.PRESETS.smoke.merged({"spread": Vector2(5, 3)}))
	puffs_back.add_source("wreck2", wreck.position + WRECK_HOLE, 4.0, puffs_back.PRESETS.smoke)
	puffs_back.add_source("wreck3", wreck.position + WRECK_HATCH + Vector2(0, -8), 2.5, puffs_back.PRESETS.smoke)
	puffs_front.add_source("embers", wreck.position + WRECK_HOLE + Vector2(0, -2), 1.5, puffs_front.PRESETS.ember)
	puffs_front.add_source("embers2", tail + Vector2(-2, 2), 1.0, puffs_front.PRESETS.ember)
	if not _crackle.playing:
		_crackle.play()
		_fade_db(_crackle, -16.0, 2.0)


## 晨被甩出来（10-29 重做，作者：「旋转太生硬」）：
##   抛物线：初速度来自撞地那一下船尾往上一甩的冲量（往右上），加重力 THROW_G；落点、飞多久定好，初速度反算出来。
##   旋转：一直用奥斯卡画的「趴着」那帧（身体横着），绕身体中心转；角速度一出舱口最大、按 THROW_TAU 指数衰减，
##     θ(t) = θ0 + ω0·τ·(1 − e^(−t/τ))：转得越来越慢，落地时脸朝下略往前栽（THROW_LAND_ROT），不匀速、不突然停。
##     一共只转七十多度（转得少、转得慢）；角度按 THROW_SNAP 一档一档（像素画转小角度出锯齿：整档更干净，0 = 连续）。
##   落地：一小团尘、镜头轻抖一下、一下很小的弹起（THROW_BOUNCE 像素）+ 往前滑 THROW_SLIDE 像素减速停住，栽下去的角度回正，然后趴着。
## 位置全部取整到像素；晨的帧不加速（lie 只有一帧）。
const THROW_T := 0.78              # 飞多久（秒）
const THROW_G := 640.0             # 重力（像素 / 秒²）
const THROW_ROT0 := -1.05          # 出舱口时的角度（弧度，负 = 头朝右上翘）
const THROW_LAND_ROT := 0.16       # 落地那一下（脸往前栽一点）
const THROW_TAU := 0.42            # 角速度衰减的时间常数
const THROW_SNAP := PI / 12.0      # 角度一档 15°（0 = 连续转）
const THROW_SLIDE := 10.0          # 落地后往前滑多远
const THROW_BOUNCE := 3.0          # 落地弹起多高
const THROW_SETTLE := 0.36         # 弹起 + 滑行 + 回正用多久
const LIE_C := Vector2(10, -9)     # 「趴着」那帧身体中心（相对晨的脚底锚点，朝右）
var _throw_p0 := Vector2.ZERO      # 身体中心的起点（世界）
var _throw_v0 := Vector2.ZERO


func _chen_thrown() -> void:
	chen.visible = true
	chen._set_facing(1)
	if not _has_getup:
		_chen_thrown_old()
		return
	chen.spr.play(&"lie")
	# 从舱门口（没了）里出来（10-29）：一开始画在船身后面（第一帧被船身挡住），飞到和船身一个像素都不重叠的时候
	# 再换到船身前面（换的那一下看不出来）。见 _throw_layer
	_throw_behind_start()
	# 从舱门口（没了）甩出来：落点 = 趴着的地方往回 THROW_SLIDE（落地后滑过去）
	_throw_p0 = wreck.position + WRECK_HATCH
	var p1 := Vector2(CHEN_X - THROW_SLIDE, _ground(CHEN_X) + 1.0) + LIE_C
	_throw_v0 = Vector2((p1.x - _throw_p0.x) / THROW_T, (p1.y - _throw_p0.y - 0.5 * THROW_G * THROW_T * THROW_T) / THROW_T)
	puffs_back.burst(_throw_p0 + Vector2(4, 0), 5, puffs_back.PRESETS.smoke_burst.merged({"vx": Vector2(10, 40), "spread": Vector2(3, 3)}))
	_thrown_step(0.0)
	var tw := _tw()
	tw.tween_method(_thrown_step, 0.0, THROW_T, THROW_T)          # 线性时间：曲线本身就是物理的，不再套缓动
	tw.tween_callback(_chen_landed)


func _throw_rot(t: float) -> float:
	var w0 := (THROW_LAND_ROT - THROW_ROT0) / (THROW_TAU * (1.0 - exp(-THROW_T / THROW_TAU)))
	return THROW_ROT0 + w0 * THROW_TAU * (1.0 - exp(-t / THROW_TAU))


## 身体中心在 c、转了 r：晨的节点放在「转回 0 时脚底该在的地方」，精灵绕身体中心转
func _lie_pose(c: Vector2, r: float) -> void:
	if THROW_SNAP > 0.0:
		r = snappedf(r, THROW_SNAP)
	chen.position = (c - LIE_C).round()
	chen.spr.rotation = r
	chen.spr.position = (LIE_C - LIE_C.rotated(r)).round()


func _thrown_step(t: float) -> void:
	var c := _throw_p0 + _throw_v0 * t + Vector2(0, 0.5 * THROW_G * t * t)
	_lie_pose(c, _throw_rot(t))
	_throw_layer(c, _throw_rot(t))


## 甩出来时晨在船身后面（_throw_idx = 原来在场景树里的位置；-1 = 已经在前面了）
var _throw_idx := -1
var _throw_px: PackedVector2Array = []     # 「趴着」那帧不透明像素相对身体中心的偏移（朝右）
var _wreck_img: Image


func _throw_behind_start() -> void:
	if _throw_idx >= 0:
		return
	if _throw_px.is_empty():
		var ft: Texture2D = chen.spr.sprite_frames.get_frame_texture(&"lie", 0)
		var img: Image = ft.get_image() if ft != null else null
		if img != null:
			var fx: float = -chen.spr.offset.x
			var fy: float = -chen.spr.offset.y
			for y in img.get_height():
				for x in img.get_width():
					if img.get_pixel(x, y).a > 0.1:
						_throw_px.append(Vector2(x - fx + 0.5, y - fy + 0.5) - LIE_C)
	if _wreck_img == null and wreck.texture != null:
		_wreck_img = wreck.texture.get_image()
	_throw_idx = chen.get_index()
	move_child(chen, wreck.get_index())             # 船图前面一格 = 被船身挡住


## 每一步：还在船身后面、而且这一帧和船身没有一个像素重叠了 → 换回前面
func _throw_layer(c: Vector2, r: float) -> void:
	if _throw_idx < 0:
		return
	if _wreck_img != null and not _throw_px.is_empty():
		if THROW_SNAP > 0.0:
			r = snappedf(r, THROW_SNAP)
		var o := wreck.position + wreck.offset
		var sz := _wreck_img.get_size()
		var cc := c.round()
		for p in _throw_px:
			var q := cc + p.rotated(r) - o
			for d in [Vector2.ZERO, Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:   # 外扩 1 像素，宁可晚换
				var qi := Vector2i((q + d).floor())
				if qi.x >= 0 and qi.y >= 0 and qi.x < sz.x and qi.y < sz.y and _wreck_img.get_pixelv(qi).a > 0.1:
					return
	_throw_front()


func _throw_front() -> void:
	if _throw_idx < 0:
		return
	if chen.get_parent() == self:
		move_child(chen, mini(_throw_idx, get_child_count() - 1))
	_throw_idx = -1


func _chen_landed() -> void:
	if not _has_getup:
		chen.spr.rotation = PI / 2.0
		puffs_front.burst(chen.position + Vector2(18, 0), 10, puffs_front.PRESETS.dust_small)
		_sfx("ship_impact", -22.0, 1.8)
		return
	_throw_front()
	var c0 := Vector2(CHEN_X - THROW_SLIDE, _ground(CHEN_X) + 1.0) + LIE_C
	var foot := chen.position + Vector2(LIE_C.x, 0)
	puffs_front.burst(foot + Vector2(4, 0), 9, puffs_front.PRESETS.dust_small.merged({"vx": Vector2(-10, 40)}))
	puffs_back.burst(foot + Vector2(-6, -1), 5, puffs_back.PRESETS.dust.merged({"vy": Vector2(-26, -8), "vx": Vector2(-30, 50)}))
	_sfx("ship_impact", -20.0, 1.8)
	_shake = maxf(_shake, 0.28)
	_shake_amp = 2.5
	var tw := _tw()
	tw.tween_method(func(k: float):
		var c := c0 + Vector2(THROW_SLIDE * (1.0 - (1.0 - k) * (1.0 - k)), -THROW_BOUNCE * sin(minf(k * 1.8, 1.0) * PI))
		_lie_pose(c, THROW_LAND_ROT * (1.0 - k) * cos(k * PI * 1.5)), 0.0, 1.0, THROW_SETTLE)
	tw.tween_callback(func():
		puffs_front.burst(chen.position + Vector2(24, 0), 3, puffs_front.PRESETS.dust_small)
		_chen_lying())


## 没有 lie / getup 动画时的老办法：站立帧转着飞、落地转 90°
func _chen_thrown_old() -> void:
	_path_a = wreck.position + WRECK_HATCH + Vector2(0, 20)
	_path_b = Vector2(CHEN_X, _ground(CHEN_X) + 1)
	chen.position = _path_a
	var tw := _tw()
	tw.tween_method(func(k: float):
		var p := _path_a.lerp(_path_b, k)
		p.y -= sin(k * PI) * 34.0
		chen.position = p.round()
		chen.spr.rotation = lerpf(-0.6, PI / 2.0 + TAU, k)
		chen.spr.position.y = -round(LIE_LIFT * k), 0.0, 1.0, 0.72).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.tween_callback(_chen_landed)


func _chen_lying() -> void:
	_throw_front()
	chen.visible = true
	chen.position = Vector2(CHEN_X, _ground(CHEN_X) + 1)
	if _has_getup:
		chen.spr.rotation = 0.0
		chen.spr.position = Vector2.ZERO
		chen.spr.play(&"lie")
		chen._set_facing(1)
		return
	chen._set_facing(1)
	chen.spr.rotation = PI / 2.0
	chen.spr.position.y = -LIE_LIFT


# ----------------------------------------------------------------------- 另一个外星人（npc_alien.gd）
var _alien_a := Vector2.ZERO
var _alien_b := Vector2.ZERO


func _alien_thrown() -> void:
	# 比晨晚 0.16 秒、弧线低、落得近（残骸尾巴旁边），转一圈多一点，脸朝下趴着，头朝右（朝晨那边）
	_alien_a = wreck.position + WRECK_HATCH + Vector2(2, 16)
	_alien_b = Vector2(ALIEN_X, _ground(ALIEN_X) + 1)
	alien.visible = true
	alien.throw_step(_alien_a, _alien_b, 0.0, 18.0, 0.0, PI / 2.0 + TAU)
	var tw := _tw()
	tw.tween_method(func(k: float): alien.throw_step(_alien_a, _alien_b, k, 18.0, 0.0, PI / 2.0 + TAU),
		0.0, 1.0, ALIEN_THROW_TIME).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.tween_callback(_alien_landed)


func _alien_landed() -> void:
	alien.lie(1)
	puffs_front.burst(alien.position + Vector2(12, 0), 8, puffs_front.PRESETS.dust_small)
	_sfx("ship_impact", -25.0, 2.0)


func _alien_get_up() -> void:
	if alien.spr.animation != &"lie":
		return
	var t: float = alien.get_up()
	var tw := _tw()
	# 梧桐版的 getup：第 4 帧（460ms 那张）跪起来，最后一帧站直
	tw.tween_interval(0.72)
	tw.tween_callback(func(): puffs_front.burst(alien.position + Vector2(-2, 0), 3, puffs_front.PRESETS.dust_small))
	tw.tween_interval(t - 0.72 - 0.15)
	tw.tween_callback(func(): puffs_front.burst(alien.position, 4, puffs_front.PRESETS.dust_small))


func _alien_stand() -> void:
	if not ALIEN_IN_FOREST:
		return
	alien.stand(ALIEN_X, _ground(ALIEN_X) + 1)


var _getup_qte: Node


func _begin_getup_qte() -> void:
	if state != S.CRASH or is_instance_valid(_getup_qte):
		return
	# 11-07 作者：雨和雷不在 QTE 一开始就收掉，而是在按 Q 的过程中慢慢停（每按一下雨稀一点、雷远一点，站起来时停完）。
	# 见 qte_weather / qte_thunder（getup_qte.gd 调）。
	_getup_qte = preload("res://scripts/getup_qte.gd").new()
	_getup_qte.name = "GetupQTE"
	_getup_qte.level = self
	_getup_qte.completed.connect(func():
		_getup_qte = null
		_qte_soft_end()
		_crash_done())
	add_child(_getup_qte)


## 11-05 夜测（--qa_live QA_CAMJUMP，真玩也有）：起身小游戏结束时（getup_qte.gd 的 cancel）把镜头一下子拉回 1 倍、
## 停回开始时的位置——画面一帧跳 21 像素、缩放也跳。那个文件不归这里改：结束的那一帧先把镜头放回小游戏最后的样子，
## 再慢慢拉回 1 倍，位置交给平时的跟随（本来就是缓缓跟过去的）。
var _qte_cam: Array = []
const QTE_UNZOOM := 0.6


## 起身 QTE 里的天气：k = 还剩多少（1 = 刚开始满雨，0 = 停了）。雨丝透明度和雨声一起跟着降；0 时雨丝、雨声都收掉。
func qte_weather(k: float, sec := 0.4) -> void:
	k = clampf(k, 0.0, 1.0)
	_opening_rain_to(k, sec)
	if _title_rain.playing:
		if k <= 0.0:
			_fade_db(_title_rain, -60.0, sec).tween_callback(_title_rain.stop)
		else:
			_fade_db(_title_rain, maxf(-60.0, CRASH_RAIN_DB + linear_to_db(k)), sec)


## 起身 QTE 里隔一阵的雷：k 同上，越往后闪得越暗、雷越远越轻（音调也低一点）
func qte_thunder(k: float) -> void:
	if k <= 0.05:
		return
	_flash(0.6 * k)
	var n := "thunder_near_%d" % (1 + randi() % 3)
	var db := -13.0 + linear_to_db(k)
	get_tree().create_timer(0.15 + 0.6 * (1.0 - k), false).timeout.connect(func():
		if state == S.CRASH:
			_opening_sfx(n, db, 0.85 + 0.15 * k))


func _qte_soft_end() -> void:
	if _qte_cam.size() != 2:
		return
	cam.position = _qte_cam[0]
	cam.zoom = _qte_cam[1]
	_qte_cam = []
	if absf(cam.zoom.x - 1.0) > 0.01:
		camera_zoom(1.0, QTE_UNZOOM)


func _chen_get_up() -> void:
	var spr: AnimatedSprite2D = chen.spr
	var tw := _tw()
	if _has_getup:
		# 奥斯卡画的爬起来：趴着 → 撑起上身 → 跪坐 → 站直（chen.gd 的 getup，播完自己回 idle）
		spr.play(&"getup")
		tw.tween_interval(GETUP_KNEEL_AT)
		tw.tween_callback(func(): puffs_front.burst(chen.position + Vector2(-3, 0), 4, puffs_front.PRESETS.dust_small))
		tw.tween_interval(GETUP_STAND_AT - GETUP_KNEEL_AT)
		tw.tween_callback(func(): puffs_front.burst(chen.position, 5, puffs_front.PRESETS.dust_small))
		return
	# 先动一下（抽一下），停一会儿，撑起来一半，再站直，落地压扁一下
	tw.tween_property(spr, "rotation", PI / 2.0 - 0.12, 0.12)
	tw.tween_property(spr, "rotation", PI / 2.0, 0.15)
	tw.tween_interval(0.45)
	tw.tween_method(_lean, PI / 2.0, 0.6, 0.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_interval(0.3)
	tw.tween_method(_lean, 0.6, 0.0, 0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_callback(_chen_stood)
	tw.tween_property(spr, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _chen_stood() -> void:
	chen.spr.scale = Vector2(1.12, 0.86)
	puffs_front.burst(chen.position, 6, puffs_front.PRESETS.dust_small)


func _lean(r: float) -> void:
	chen.spr.rotation = r
	chen.spr.position.y = -round(LIE_LIFT * sin(r))


func _chen_stand() -> void:
	if String(chen.spr.animation) in ["lie", "getup"]:
		chen.spr.play(&"idle")
	chen.spr.rotation = 0.0
	chen.spr.position = Vector2.ZERO
	chen.spr.scale = Vector2.ONE
	chen.position = Vector2(chen.position.x, _ground(chen.position.x) + 1)


func _crash_done() -> void:
	_kill_cine()
	_chen_stand()
	if ALIEN_IN_FOREST and not alien.is_up():
		_alien_stand()
	_bars_out(0.7)
	StoryState.set_flag("crashed")
	story.alarm(true)
	var h: String = story.hook("crash")
	_enter_play()
	if h != "":
		story.play(h)             # 剧本的 intro（播的时候锁晨，播完回到自由走）
	else:
		_say("who_chen", "line_crash")


func _skip_crash() -> void:
	# 跳过：直接到「晨已经站起来、对话刚出现」
	set_meta("qa_skip_t", story._game_t if story != null else 0.0)     # --qa_live：跳过时黑边一下子收起，不算镜头跳
	_kill_cine()
	_opening_rain_to(0.0, 0.0)
	if _title_rain.playing:
		_fade_db(_title_rain, -60.0, 0.8).tween_callback(_title_rain.stop)
	_title_root.visible = false
	_title_root.modulate.a = 0.0
	_flash_k = 0.0
	_impact_k = 0.0
	ship.visible = false
	puffs_back.remove_source("trail")
	puffs_back.remove_source("trail_sparks")
	if not wreck.visible:
		_show_wreck()
		puffs_back.burst(wreck.position + Vector2(10, -16), 14, puffs_back.PRESETS.smoke_burst)
	cam.position.x = TITLE_CAM_X
	_throw_front()
	chen.visible = true
	chen._set_facing(1)
	chen.position = Vector2(CHEN_X, _ground(CHEN_X) + 1)
	if ALIEN_IN_FOREST:
		_alien_stand()
	_skip_label.modulate.a = 0.0
	_bars_out(0.01)
	_crash_done()


# ======================================================================= 黑边
## 11-04（--qa_live 查出来的）：上一段剧情的黑边还在往外收（0.5 秒），下一段就开始放下来时，两个 tween 抢同一个属性：
## 收的那个先到点、把位置设到 270、回调把黑边藏起来，放的那个接着把它挪回 244——黑边看不见了，镜头的黑边偏移也跟着归零，
## 画面一下子跳 17 像素。所以黑边只留一个 tween：开新的之前先停掉旧的。
var _bars_tw: Tween


func _bars_kill() -> void:
	if _bars_tw != null and _bars_tw.is_valid():
		_bars_tw.kill()


func _bars_in(sec: float) -> void:
	_bars_kill()
	for b in _bars:
		b.visible = true
	var tw := _tw()
	_bars_tw = tw
	tw.tween_property(_bars[0], "position:y", 0.0, sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(_bars[1], "position:y", 270.0 - BAR_H, sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


func _bars_out(sec: float) -> void:
	_bars_kill()
	var tw := create_tween()
	_bars_tw = tw
	tw.tween_property(_bars[0], "position:y", -float(BAR_H), sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(_bars[1], "position:y", 270.0, sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.tween_callback(func():
		if _bars[1].position.y >= 270.0:          # 收到屏幕外了就藏起来（视口比 270 高时不在画面下沿露一条）
			for b in _bars:
				b.visible = false)


# ======================================================================= 4. 自由走
func _enter_play() -> void:
	_set_state(S.PLAY)
	chen.input_enabled = true
	chen.auto_dir = 0.0
	_walk_target = NAN
	_moved_from = chen.position.x
	_hint_wait = 0.0
	if not Inventory.owned.is_empty() and free_roam == "" and not story.bag_locked():       # 自由探索：背包、燃料不出来；第一关新版：背包还没拿回来
		_bag_btn.visible = true
		create_tween().tween_property(_bag_btn, "modulate:a", 1.0, 0.5)
		create_tween().tween_property(_hud_burn, "modulate:a", 1.0, 0.5)


func _leave_play_ui() -> void:
	create_tween().tween_property(_keys_hint, "modulate:a", 0.0, 0.3)


# ======================================================================= 5. 发光木头
func _start_pickup() -> void:
	_set_state(S.CINE)
	chen.input_enabled = false
	_walk_target = NAN
	_leave_play_ui()
	_bars_in(0.5)
	_dlg_hide(0.4)
	var side := -1.0 if chen.position.x < WOOD_X else 1.0
	_cine_target = WOOD_X + side * 13.0
	if absf(chen.position.x - _cine_target) <= 3.0:
		_cine_target = NAN
		_pickup_at_wood()
	else:
		chen.auto_dir = signf(_cine_target - chen.position.x)


func _pickup_at_wood() -> void:
	chen.auto_dir = 0.0
	chen._set_facing(1 if WOOD_X > chen.position.x else -1)
	create_tween().tween_property(wood_hint, "modulate:a", 0.0, 0.2)
	var h: String = story.hook("wood")
	if h != "":
		# 剧本接管台词：木头飞进背包以后播剧本里木头那个 scene（它的「弯腰捡」和「给木头」跳过），燃烧值照样滚
		_burn_sub_off = true
		_run([
			[0.15, _pk_crouch],
			[0.35, _pk_lift],
			[1.0, _pk_show_bag],
			[1.35, _wood_fly_to_bag],
			[2.15, _wood_story.bind(h)],
			[4.6, _burn_roll],
			[9.6, _burn_to_hud],
		])
		return
	_run([
		[0.15, _pk_crouch],           # 捡东西最低那帧在动画第 0.2 秒 → 正好 0.35 木头飞起来
		[0.35, _pk_lift],
		[1.0, _pk_show_bag],
		[1.35, _wood_fly_to_bag],
		[2.15, _say.bind("who_chen", "line_wood")],
		[4.6, _burn_roll],
		[9.6, _burn_to_hud],
		[10.3, _pickup_done],
	])


func _wood_story(h: String) -> void:
	await story.play_wood(h)
	StoryState.set_flag("got_wood")
	while not _seq.is_empty():
		await StoryState.frame(get_tree())
	await get_tree().create_timer(0.6, false).timeout
	_pickup_done()
	story.check_fuel_hook()


func _pk_crouch() -> void:
	if CHEN_GD.ANIMS.has("pickup"):
		chen.spr.play(&"pickup")      # 奥斯卡画的弯腰捡，播完自己回 idle
		return
	var tw := _tw()
	tw.tween_property(chen.spr, "scale", Vector2(1.06, 0.9), 0.12)
	tw.tween_property(chen.spr, "scale", Vector2.ONE, 0.2)


func _pk_lift() -> void:
	_sfx("pickup", -6.0)
	var tw := _tw()
	tw.tween_property(wood, "position", wood.position + Vector2(0, -18), 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(wood_glow, "scale", Vector2(1.5, 1.5), 0.55)
	puffs_front.burst(wood.position + Vector2(0, -4), 8, puffs_front.PRESETS.glint)


func _pk_show_bag() -> void:
	_bag_btn.visible = true
	_tw().tween_property(_bag_btn, "modulate:a", 1.0, 0.4)


func _wood_fly_to_bag() -> void:
	_path_a = wood.position
	var tw := _tw()
	tw.tween_method(_wood_fly_step, 0.0, 1.0, 0.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.tween_callback(_wood_in_bag)


func _wood_fly_step(k: float) -> void:
	# 目标是右上角背包图标在世界里的位置（镜头可能在动，每帧重算）
	var to := _screen_to_world(_bag_btn.position + _bag_btn.size / 2.0)
	var p := _path_a.lerp(to, k)
	p.y -= sin(k * PI) * 20.0
	wood.position = p.round()
	var s := lerpf(1.0, 0.45, k)
	wood.scale = Vector2(s, s)


func _wood_in_bag() -> void:
	wood.visible = false
	Inventory.add("glowing_wood")
	on_inventory_changed()
	_sfx("tick", -6.0, 0.8)
	_bag_btn.scale = Vector2(1.5, 1.5)
	_tw().tween_property(_bag_btn, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _screen_to_world(p: Vector2) -> Vector2:
	return cam.get_screen_center_position() - Vector2(240, 135) + p


func _burn_roll() -> void:
	var from := float(Inventory.base_burn)
	var to := float(Inventory.burn_total())
	_burn_shown = from
	_burn_pop.visible = true
	_burn_pop.position = Vector2(140, 34)
	_burn_pop.scale = Vector2.ONE
	_burn_pop_sub.modulate.a = 0.0
	_set_burn_pop(from)
	var tw := _tw()
	tw.tween_property(_burn_pop, "modulate:a", 1.0, 0.4)
	tw.tween_interval(0.4)
	tw.tween_method(_set_burn_pop, from, to, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_callback(_sfx.bind("burn_ding", -8.0, 1.0))
	if not _burn_sub_off:
		tw.tween_property(_burn_pop_sub, "modulate:a", 1.0, 0.6)


func _set_burn_pop(v: float) -> void:
	var n := int(round(v))
	if n != int(round(_burn_shown)) and n % 2 == 0:
		_sfx("tick", -14.0, 1.0 + (n - Inventory.base_burn) * 0.004)
	_burn_shown = v
	_burn_pop_num.text = str(n)
	_burn_pop_fill.size.x = round(120.0 * clampf(v / Inventory.get_launch_burn(), 0.0, 1.0))


func _burn_to_hud() -> void:
	_update_hud()
	var tw := _tw()
	tw.tween_property(_burn_pop, "modulate:a", 0.0, 0.5)
	tw.parallel().tween_property(_burn_pop, "position", Vector2(-60, -12), 0.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(_burn_pop, "scale", Vector2(0.4, 0.4), 0.5)
	tw.parallel().tween_property(_hud_burn, "modulate:a", 1.0, 0.5).set_delay(0.25)
	tw.tween_callback(_burn_pop.hide)


func _pickup_done() -> void:
	_kill_cine()
	_burn_pop.visible = false
	_hud_burn.modulate.a = 1.0
	_bars_out(0.6)
	_enter_play()


# ======================================================================= 对话框
func _say(who: String, key: String) -> void:
	_dlg.set_meta("who", who)
	_dlg.set_meta("key", key)
	_dlg_name.text = I18n.t(who)
	_dlg_text.text = I18n.t(key)
	_dlg_text.visible_characters = 0
	_dlg_chars = 0.0
	_dlg_cps = 14.0 if I18n.is_zh() else 30.0
	_dlg_age = 0.0
	_dlg_x = chen.position.x
	_dlg_on = true
	_dlg.visible = true
	_dlg.reset_size()
	if _dlg_tw != null and _dlg_tw.is_valid():
		_dlg_tw.kill()
	_dlg_tw = create_tween()
	_dlg_tw.tween_property(_dlg, "modulate:a", 1.0, 0.35)
	_place_dialogue()


func _dlg_hide(sec := 0.7) -> void:
	if not _dlg_on:
		return
	_dlg_on = false
	if _dlg_tw != null and _dlg_tw.is_valid():
		_dlg_tw.kill()
	_dlg_tw = create_tween()
	_dlg_tw.tween_property(_dlg, "modulate:a", 0.0, sec)
	_dlg_tw.tween_callback(_dlg.hide)


func _dlg_typing() -> bool:
	return _dlg_on and _dlg_text.visible_characters >= 0 and _dlg_text.visible_characters < _dlg_text.get_total_character_count()


func _place_dialogue() -> void:
	# 晨头顶：框的下沿在她头顶上 6 像素，水平居中跟着她，不出屏幕
	_dlg.reset_size()
	var sx := chen.position.x - (cam.get_screen_center_position().x - 240.0)
	var top := chen.position.y - 44.0
	var x := clampf(round(sx - _dlg.size.x / 2.0), 6.0, 474.0 - _dlg.size.x)
	_dlg.position = Vector2(x, round(top - 6.0 - _dlg.size.y))


func _update_dialogue(delta: float) -> void:
	if not _dlg.visible:
		return
	if _dlg_on:
		_dlg_age += delta
		_dlg_chars += _dlg_cps * delta
		var total := _dlg_text.get_total_character_count()
		_dlg_text.visible_characters = mini(int(_dlg_chars), total)
		if _dlg_text.visible_characters >= total:
			_dlg_text.visible_characters = -1
		if _dlg_age > DLG_TIME or (state == S.PLAY and absf(chen.position.x - _dlg_x) > DLG_WALK):
			_dlg_hide()
	_place_dialogue()


# ======================================================================= 面板
## 设置 = 暂停（任何时候都能开，scripts/pause_gate.gd）。晨的输入不用动：暂停时晨收不到，关掉原地接着走
func _open_settings() -> void:
	if _settings.visible or (_bag.visible and _first_photo_pending()):
		return
	_close_panels()
	_pause_tree(true)
	_sfx("ui_click", -10.0)
	_panel_prev_focus = get_viewport().gui_get_focus_owner()
	_sync_settings()
	_settings.visible = true
	_sett_dim.visible = true
	_center_settings()
	(_settings_widgets["lang_a"] as Button).grab_focus()


## 自动测试靠关卡的 _process 走（乱玩、截图），暂停了就走不动了：这些时候面板照开，不真暂停
func _pause_tree(on: bool) -> void:
	if _fuzz > 0.0 or _shot != "" or _shots_dir != "" or _autoplay or _browse > 0 or _debug_stage != "":
		return
	get_tree().paused = on


## 每帧（pause_gate._process，暂停时也跑）：齿轮一直在，只跟着全黑转场淡；制作人员页盖着时不用
func gear_tick() -> void:
	_gear.visible = _credits_page == null
	_gear.modulate.a = (GEAR_A if state == S.TITLE else GEAR_PLAY_A) * (1.0 - fade.color.a)
	if _settings.visible and get_tree().paused:
		var f := get_viewport().gui_get_focus_owner()     # 方向键别把焦点走到面板外面暂停着的按钮（对话的选项）上
		if f != null and not _settings.is_ancestor_of(f):
			(_settings_widgets["lang_a"] as Button).grab_focus()


## pause_gate._input：比所有小游戏、对话框都先收到。Esc 开 / 关设置，点齿轮开 / 关；暂停时制作人员页的按键也从这里给
func gate_input(event: InputEvent) -> void:
	if _autoplay or _shots_dir != "" or _shot != "" or _story_auto != "" or story == null:
		return
	gate_event(event)


func gate_event(event: InputEvent) -> void:
	if _leaving_title:                             # 返回标题淡到黑的路上：按什么都不算
		_handled()
		return
	if _credits_page != null:
		if get_tree().paused:
			_credits_page.handle(event)
			_handled()
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and _gear.get_global_rect().grow(2.0).has_point(event.position):
		if event.pressed:
			if _settings.visible:
				_close_panels()
			else:
				_open_settings()
		_handled()
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		if _settings.visible or _bag.visible:
			_close_panels()
		elif _esc_is_back():
			return
		else:
			_open_settings()
		_handled()


## Esc 只是「退出这个界面」的（通讯器翻聊天记录、能关的特写）：先退出，再按才开设置。
## 别的（通讯器 / 驾驶舱的选择）Esc 不替玩家选，直接开设置
func _esc_is_back() -> bool:
	if story.mech_node != null and story.mech_node.has_method("can_quit") and story.mech_node.can_quit():
		return true                    # 能退出的小游戏（煮锅、来客册）开着：Esc 先退小游戏，面板外才开设置
	return story.closeup_ui != null and story.closeup_ui.is_open() and story.closeup_ui._can_close()


func _toggle_bag() -> void:
	if _bag.visible:
		_close_panels()
		return
	if state != S.PLAY or Inventory.owned.is_empty() or story.bag_locked():
		return
	_close_panels()
	_sfx("ui_click", -10.0)
	_panel_prev_focus = null
	# 11-04 作者「打开背包的时候还在播放制作人员」：奔跑片头的名字还没放完就打开背包 → 名字散掉收起来（主题曲照放）
	var rc := get_node_or_null("RunCredits")
	if rc != null and rc.has_method("finish"):
		rc.finish(0.6)
	_bag.visible = true
	_dim.visible = true
	_bag_sel = clampi(_bag_sel, 0, mini(BAG_SLOTS, Inventory.owned.size()) - 1)
	_bag_refresh()
	chen.input_enabled = false
	chen.auto_dir = 0.0
	_walk_target = NAN
	_bag_slots[_bag_sel].grab_focus()
	if not _bag_seen:
		_bag_seen = true
		_bag_btn.modulate = Color(1, 1, 1, 1)


func _first_photo_pending() -> bool:
	return chapter == "forest" and StoryState.has("c1_got_bag") and not StoryState.has("c1_chase_done") \
		and Inventory.owned.has("elephant_drawing") and story.item_view("elephant_drawing") != ""


func _close_panels(viewing_photo := false) -> void:
	if _bag.visible and _first_photo_pending() and not viewing_photo:
		return
	var was := _settings.visible or _bag.visible
	var bag_was := _bag.visible
	var settings_was := _settings.visible
	_settings.visible = false
	_bag.visible = false
	_dim.visible = false
	_sett_dim.visible = false
	if was:
		_sfx("ui_click", -12.0, 0.85)
	if settings_was:
		_pause_tree(false)
	if bag_was and state == S.PLAY:
		chen.input_enabled = true
	if state == S.TITLE:
		if _panel_prev_focus == _start_btn:
			_start_btn.grab_focus()
	elif _panel_prev_focus != null and is_instance_valid(_panel_prev_focus) and _panel_prev_focus.is_visible_in_tree():
		_panel_prev_focus.grab_focus()
	else:
		var f := get_viewport().gui_get_focus_owner()
		if f != null:
			f.release_focus()


# ======================================================================= 输入
func _input(event: InputEvent) -> void:
	if not is_inside_tree():
		return                                # 换章 / 重开时这一帧可能已经不在树里了
	if _autoplay or _shots_dir != "" or _shot != "" or _story_auto != "":
		_handled()
		return
	# 最近一次用的是鼠标还是键盘（互动提示画小鼠标还是「E」）
	if event is InputEventMouseButton and event.pressed:
		story.hotspots.use_mouse = true
	elif event is InputEventKey and event.pressed:
		story.hotspots.use_mouse = false
	# F12：开发者面板（只在 debug 构建）
	if DEV_GD.is_toggle_event(event) and OS.is_debug_build():
		toggle_dev()
		_handled()
		return
	# 制作人员页开着：按键 / 点击都给它（不能跳，菜单点进来的 Esc 退回）
	if _credits_page != null:
		_credits_page.handle(event)
		_handled()
		return
	# 章节结束卡：3 秒以后按任意键回标题
	if story.ended:
		_handled()
		if _end_t > 3.0 and ((event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed)):
			_end_t = -100.0                       # 只重开一次
			if _fuzz > 0.0:
				_fuzz_t = _fuzz                    # 乱玩：走到结束卡就算玩完
				return
			CHAPTER_GD.reset()                     # 回标题 = 新游戏（从森林开始）
			(load("res://scripts/audio_fade.gd") as GDScript).release(self, 0.8)   # 还在响的长声音淡掉，不被重新载入掐断
			get_tree().reload_current_scene.call_deferred()
		return
	# 剧情在播：按键 / 点击给对话框（确认、点选）；鹿带路时方向键照常走
	if story.busy and not _settings.visible and not _bag.visible:
		if story.closeup_ui != null and story.closeup_ui.is_open() and story.closeup_ui.handle_input(event):
			_handled()
			return
		if story.dlg.handle_input(event):
			_handled()
			return
		if event is InputEventMouseButton and story.dlg.pick_buttons_shown():
			return                                # 点选按钮自己接（按下和松开都要放过去）
		if not story.free_walk and (event is InputEventKey or event is InputEventMouseButton):
			if not (event is InputEventKey and event.keycode == KEY_ESCAPE):
				_handled()
				return
	if event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.keycode
		if k == KEY_ESCAPE:
			if _settings.visible or _bag.visible:      # 开设置在 gate_input；走到这里的是通讯器、特写没接的 Esc
				_close_panels()
			_handled()
			return
		if k in TEST_SCENES and state == S.TITLE and OS.is_debug_build() and not (_settings.visible or _bag.visible):
			_handled()
			_open_test_scene(TEST_SCENES[k])
			return
		if k in [KEY_TAB, KEY_B, KEY_I]:
			if not _settings.visible:
				_toggle_bag()
			_handled()
			return
		# 背包开着、描述比框长：↑↓ 滚描述（不长就照常在格子里移动）
		if _bag.visible and k in [KEY_UP, KEY_DOWN] and _desc_max_skip() > 0:
			_desc_scroll(-1 if k == KEY_UP else 1)
			_handled()
			return
		if _bag.visible and k in [KEY_E, KEY_SPACE, KEY_ENTER, KEY_KP_ENTER, KEY_Z] and _bag_sel < Inventory.owned.size() \
				and (story.item_view(Inventory.owned[_bag_sel]) != "" or story.paper_viewable(Inventory.owned[_bag_sel])):
			_handled()
			_on_use_item()                            # 剧本 item_views：E / 空格 = 「查看」
			return
	if _settings.visible or _bag.visible:
		return
	var confirm: bool = event.is_action_pressed("ui_accept") or (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT)
	match state:
		S.HEADPHONES:
			_handled()
		S.TITLE:
			# 「开始」平时不拿焦点（不然一出来就是高亮的）：Enter / 空格直接开始，方向键才把焦点给它
			if event.is_action_pressed("ui_accept"):
				_handled()
				_on_start()
			elif get_viewport().gui_get_focus_owner() == null and (event.is_action_pressed("ui_up") \
					or event.is_action_pressed("ui_down") or event.is_action_pressed("ui_left") or event.is_action_pressed("ui_right")):
				_handled()
				_start_btn.grab_focus()
		S.INTRO:
			if confirm:
				_handled()                        # 11-07 作者：耳机提示 → 标题这一段不许用空格 / 回车 / 点击跳过（_skip_to_title 只留给 --stage=title）
		S.CRASH:
			if confirm:
				_handled()                        # 11-04 作者：开场坠机是关键演出，不许跳过（_skip_crash 只留给 --stage / 自动玩）
		S.PLAY, S.CINE:
			if free_roam != "" and state == S.PLAY and event is InputEventKey and event.pressed and not event.echo \
					and event.keycode in [KEY_UP, KEY_W, KEY_DOWN, KEY_S] and not story.busy:
				free_stairs(1 if event.keycode in [KEY_UP, KEY_W] else -1)     # 自由探索的多层小屋：↑ 上楼、↓ 下楼（也可以在楼梯口按 E）
			elif state == S.PLAY and event is InputEventKey and event.pressed and not event.echo \
					and event.keycode in [KEY_E, KEY_SPACE, KEY_ENTER, KEY_KP_ENTER, KEY_Z] and not story.hotspots.near.is_empty():
				_handled()
				_interact(story.hotspots.near)
			elif event.is_action_pressed("ui_accept") and _dlg_typing():
				_dlg_chars = 9999.0
				_handled()
			elif state == S.PLAY and story.bark.busy() and ((event is InputEventKey and event.pressed and not event.echo \
					and event.keycode in [KEY_E, KEY_SPACE, KEY_ENTER, KEY_KP_ENTER, KEY_Z]) \
					or (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT)):
				_handled()
				story.bark.skip()                # 11-04 作者「这个对话框消不掉」：飘着的那一句，按一下 / 点一下就收


## 这个输入用掉了（乱玩时偶尔在换场景的那一帧，viewport 已经没了：不报错）
func _handled() -> void:
	var vp := get_viewport()
	if vp != null:
		vp.set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
	# 鼠标只能点够得着的东西（走到跟前才能点）；点空地、点远处的东西晨都不动
	# （10-30 作者：点地走容易点不到东西，晨就走到一边去了；「够不着的东西那就不能点啊」）
	if not _free() or _settings.visible or _bag.visible:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if _dlg_typing():
			_dlg_chars = 9999.0
		var sp: Vector2 = (event as InputEventMouseButton).position
		var wp: Vector2 = cam_left() + sp     # 用事件自己的位置（乱玩模式的假点击也对）
		var p: Dictionary = story.hotspots.at_point(wp) if state == S.PLAY else {}
		if p.is_empty() or not story.hotspots.in_range(p, chen.position.x):
			return                            # 点空地、点够不着的东西：什么也不做
		_interact(p)
		get_viewport().set_input_as_handled()


func _load_achievements() -> void:
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/achievements.json"))
	if data is Dictionary:
		_achievement_data = data.get("achievements", [])
	_achievement_seen.load(ACHIEVEMENT_SAVE)
	_achievement_progress = StoryState.progress()
	for entry: Dictionary in _achievement_data:
		if _achievement_met(entry):
			_achievement_seen.set_value("unlocked", str(entry["id"]), true)


func _achievement_met(entry: Dictionary) -> bool:
	var any_flags: Array = entry.get("any", [])
	return StoryState.all_of(entry.get("all", [])) and (any_flags.is_empty() or not StoryState.none_of(any_flags))


func _update_achievements() -> void:
	if _achievement_progress == StoryState.progress() or story.ff:
		return
	_achievement_progress = StoryState.progress()
	for entry: Dictionary in _achievement_data:
		var id := str(entry["id"])
		if _achievement_seen.has_section_key("unlocked", id) or not _achievement_met(entry):
			continue
		_achievement_seen.set_value("unlocked", id, true)
		if not GameSettings.no_save:
			_achievement_seen.save(ACHIEVEMENT_SAVE)
		_show_achievement(entry)


func _show_achievement(entry: Dictionary) -> void:
	if not is_instance_valid(_achievement_toasts):
		_achievement_toasts = CanvasLayer.new()
		_achievement_toasts.layer = 58
		add_child(_achievement_toasts)
		var stack := VBoxContainer.new()
		stack.position = Vector2(312, 14)
		stack.size.x = 154
		stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_achievement_toasts.add_child(stack)
	var stack := _achievement_toasts.get_child(0) as VBoxContainer
	var toast := PanelContainer.new()
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast.add_theme_stylebox_override("panel", UITheme.box(Color("#1e2926"), Color("#cdb57e"), 1, Vector4(6, 4, 6, 4)))
	stack.add_child(toast)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast.add_child(row)
	var icon := _label("★", 19, Color("#ffd779"))
	row.add_child(icon)
	var text := _label(I18n.pick({"zh": "成就解锁", "en": "Achievement unlocked"}) + "\n" + I18n.pick(entry), 12, UITheme.TEXT)
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text)
	toast.modulate.a = 0.0
	var tween := toast.create_tween()
	tween.tween_property(toast, "modulate:a", 1.0, 0.25)
	tween.tween_interval(2.5)
	tween.tween_property(toast, "modulate:a", 0.0, 0.55)
	tween.tween_callback(toast.queue_free)


# ======================================================================= 每帧
func _process(delta: float) -> void:
	_t += delta
	_update_achievements()
	_update_stroll(delta)             # 要在晨自己的 _process 之前（晨是这个节点的子节点，排在后面）
	_state_t += delta
	_stage_t += delta
	_frame += 1
	# 定时事件
	if not _seq.is_empty():
		_seq_t += delta
		while not _seq.is_empty() and _seq[0][0] <= _seq_t:
			var e: Array = _seq.pop_front()
			(e[1] as Callable).call()
	if _skip_armed > 0.0:
		_skip_armed -= delta
		if _skip_armed <= 0.0:
			create_tween().tween_property(_skip_label, "modulate:a", 0.0, 0.4)

	_update_walls()
	_update_portal(delta)
	_guard_forest_cast()
	if free_roam != "":
		_free_tick()
	else:
		_update_objective()
	_update_front(delta)
	_update_camera(delta)
	if is_instance_valid(_getup_qte):
		_qte_cam = [cam.position, cam.zoom]
	_apply_flash()
	_update_world(delta)
	_update_dialogue(delta)
	_update_hints(delta)
	_update_key_prompt(delta)
	var cc := cam.get_screen_center_position()
	story.world.update(delta, cc)
	_update_room_mask(cc)
	story.hotspots.active = state == S.PLAY and not story.busy and not _settings.visible and not _bag.visible
	story.hotspots.update(delta, chen, cc - Vector2(240, 135), get_global_mouse_position())
	_update_edge_arrow(cc)
	if story.ended and _end_t >= 0.0:
		_end_t += delta

	# 11-04 作者「上面文字被切掉了一些」：剧情黑边放下来时左上角的目标（主目标 + 可选那一行）会被上边的黑边压住一半。
	# 黑边放多少，目标就淡多少（黑边收起来再回来）
	if _bars.size() > 0 and _hud_obj != null:
		var bk := clampf((_bars[0].position.y + BAR_H) / BAR_H, 0.0, 1.0)
		_hud_obj.modulate.a = 1.0 - bk
		# 11-04 --qa_live：没有黑边时，说话的人站得高（树屋里、画面外的声音），对话框会盖到左上角的目标上，字叠字。
		# 对话框和目标那一块碰上了，目标（连燃料表）淡到 HUD_UNDER，框走了再回来
		var under := _hud_covered()
		_hud_dim = HUD_UNDER if under else move_toward(_hud_dim, 1.0, delta * 3.0)    # 框一出来立刻让开，框走了慢慢回来
		for n2: CanvasItem in [_hud_obj, _hud_side, _hud_flame, _hud_burn_label]:
			if n2 != null:
				n2.self_modulate.a = _hud_dim

	if state == S.TITLE or _title_root.visible:
		_update_title(delta)
	if _title_bg != null:
		# 11-07：下落在低帧率时会放慢，等画面滚动结束再拉电影黑边。
		if state == S.CRASH and _title_bg.finished():
			_start_crash()
		elif state in [S.PLAY, S.CINE]:      # F12 跳关之类从标题直接进了游戏
			_title_bg_off()

	_debug_tick()
	if _fuzz > 0.0:
		_fuzz_tick(delta)
		_softlock_tick(delta)


func _update_title(delta: float) -> void:
	if state == S.TITLE and _state_t >= _title_thunder_at:
		_title_thunder_at += 11.0
		_opening_sfx("thunder_near_2", -17.0)
	# 标题：淡入时往上飘 3 像素（整像素）；之后很慢地呼吸（7 秒一次，亮度只差一点）
	var breath := 0.9 + 0.1 * sin(_t * TAU / 7.0)
	_title_label.modulate.a = _title_k * breath
	_title_label.position.y = TITLE_Y + roundf(3.0 * (1.0 - _title_k))
	# 「开始」：悬停 / 聚焦时变亮，两边的小横线从 0 伸到 8 像素
	var hot := _start_hover or _start_btn.has_focus()
	_start_hot = move_toward(_start_hot, 1.0 if hot else 0.0, delta * 6.0)
	var w := roundf(8.0 * _start_hot)
	var y := _start_btn.position.y + 10.0
	_start_marks[0].size.x = w
	_start_marks[1].size.x = w
	_start_marks[0].position = Vector2(_start_btn.position.x - 6.0 - w, y)
	_start_marks[1].position = Vector2(_start_btn.position.x + _start_btn.size.x - START_SPACING + 7.0, y)
	# 字色跟着 _start_hot 渐变（悬停 / 聚焦 / 方向键选中都一样，不是一下子跳亮）
	var fc := START_COLOR.lerp(START_HOT, _start_hot)
	if fc != _start_fc:
		_start_fc = fc
		for k in ["font_color", "font_hover_color", "font_focus_color", "font_pressed_color", "font_hover_pressed_color"]:
			_start_btn.add_theme_color_override(k, fc)
	var a := _start_btn.modulate.a
	for m in _start_marks:
		m.modulate.a = a * _start_hot * 0.8
	if not hot:
		_start_btn.self_modulate.a = 0.78 + 0.12 * sin(_t * 1.6)    # 没碰它的时候很轻地呼吸
	else:
		_start_btn.self_modulate.a = 1.0


func _update_camera(delta: float) -> void:
	match state:
		S.HEADPHONES, S.INTRO, S.TITLE:
			# 标题：镜头慢慢左右漂（50 秒一个来回，±18 像素）
			cam.position.x = TITLE_CAM_X + 18.0 * sin(_t * TAU / 50.0)
		S.PLAY, S.CINE:
			if not is_nan(_cam_override.x):
				# 11-04 作者「底下为什么有绿边」：_cam_override 存的是不算黑边的镜头位置；黑边收起来时这一点跟着回去，
				# 不然停在「黑边放下时往下挪了」的高度，黑边一收，画面底下就露出地面以下的空色
				# 11-05 夜测（QA_CAMJUMP c1_crash）：起身小游戏拉近时镜头低 16 像素，一停回来黑边让位一下子重算，画面一帧跳 16 像素。
				# 亮着的时候让位量每秒最多变 BAR_DY_RATE 像素（黑边本身滑进滑出比这慢，平时看不出差别）；黑着照旧直接到位
				var want_dy := _bar_cam_dy(_cam_override.y)
				_cam_bar_dy = want_dy if fade.color.a > 0.5 else move_toward(_cam_bar_dy, want_dy, BAR_DY_RATE * delta)
				cam.position = Vector2(_cam_override.x, _cam_override.y + _cam_bar_dy).round()
			elif _cam_hold > 0.0:
				_cam_hold -= delta
			else:
				cam.position.x = lerpf(cam.position.x, _cam_target(), 1.0 - exp(-FOLLOW * delta))
	var ck: Node2D = story.world.cockpit if story != null and story.world != null and story.world.cockpit != null and story.world.in_cockpit() else null
	if ck != null and is_nan(_cam_override.x):
		# 驾驶舱：船上下挪 = 镜头反向偏移（晨、室内、物件一起动；船外背景在 CanvasLayer 里不动）。ship_y() 是整数像素
		cam.position.y = 135.0 - ck.ship_y()
	elif _title_bg != null and _title_bg.descending:
		cam.position.y = _title_bg.forest_cam_y()         # 开始界面往下落：森林跟着上来（落到位正好是 135）
	elif is_nan(_cam_override.x):
		# 平时镜头高度固定（多房间章节：房间的中线）；从别处回来时慢慢落回去
		var cy: float = story.world_cam_y() if story != null and story.world != null else 135.0
		var base := cam.position.y - _cam_bar_dy
		base = cy if absf(base - cy) < 0.5 else lerpf(base, cy, 1.0 - exp(-3.0 * delta))
		_cam_bar_dy = _bar_cam_dy(base)
		cam.position.y = base + _cam_bar_dy
	if _shake > 0.0:
		_shake -= delta
		var a := _shake_amp * clampf(_shake / 0.8, 0.0, 1.0)
		cam.offset = Vector2(round(_rng.randf_range(-a, a)), round(_rng.randf_range(-a, a)))
	else:
		cam.offset = Vector2.ZERO


## 多房间章节（河岸、妮芙家、市集、旧街、仓库、南桥……）里，森林的角色和林子里的动物一律不出现、不跑：
## 鹿、弥洛、外星人同伴藏起来停掉；ForestShadows（林子深处的鹿 / 驼鹿 / 狐狸剪影）停掉，连它开场搬出去的 Deep 层
## （驼鹿那层，forest_shadows.tscn 的 deep_before 把它挪到 level 底下，_start_chapter 藏 ForestShadows 藏不到它）。
## 10-30 作者：旧街水里、仓库柜子上站着一只第一章的「鹿」，其实是 Deep 层的驼鹿剪影。不靠 story_runner，每帧都管。
func _guard_forest_cast() -> void:
	if story == null or story.world == null or not story.world.is_stage(story.world.room):
		return
	for n in [story.deer, story.miluo, alien, shadows, shadows.get("deep") if shadows != null else null]:
		if n is CanvasItem and is_instance_valid(n):
			var c := n as CanvasItem
			if c.visible:
				c.visible = false
			if c.process_mode != Node.PROCESS_MODE_DISABLED:
				c.process_mode = Node.PROCESS_MODE_DISABLED


## 自测用：鹿、弥洛、外星人同伴、林子剪影（ForestShadows / Deep 层）哪些还亮着（「无」= 都藏好了）
func _forest_cast_seen() -> String:
	var out: Array[String] = []
	var d: Node = shadows.get("deep") if shadows != null else null
	for pair in [["鹿", story.deer], ["弥洛", story.miluo], ["外星人", alien], ["林子剪影", shadows], ["驼鹿层", d]]:
		var c = pair[1]
		if c is CanvasItem and is_instance_valid(c) and (c as CanvasItem).is_visible_in_tree():
			out.append(str(pair[0]))
	return "、".join(out) if not out.is_empty() else "无"


## 多房间章节：正在显示的房间上下以外盖黑。房间是上下摞着的（市集在河岸正上方），窗口比 16:9 高、
## 或者镜头被拉到房间外面时（竖直平移渐黑时镜头往上 / 下多走的那一段，story_runner._pan_to），不能露出别的房间。
## 森林、驾驶舱没有 stage，不盖。
var _room_mask: Array[ColorRect] = []


func _update_room_mask(cc: Vector2) -> void:
	var w: Node2D = story.world if story != null else null
	var top := INF
	var bot := -INF
	if w != null and state != S.TITLE:
		for r in w.stages:
			var sg: Node2D = w.stages[r]
			if not sg.is_visible_in_tree():
				continue
			top = minf(top, sg.origin.y)
			bot = maxf(bot, sg.origin.y + sg.size.y)
			if sg._sky_up != null and sg._sky_up.visible:
				top = minf(top, sg.origin.y + sg._sky_up.position.y)      # 多层小屋往上看补的那片天
	if not _room_mask.is_empty() and not is_instance_valid(_room_mask[0]):
		_room_mask.clear()
	if top == INF:
		for m in _room_mask:
			m.visible = false
		return
	if _room_mask.is_empty():
		for i in 2:
			var m := ColorRect.new()
			m.name = "RoomMask%d" % i
			m.color = Color.BLACK
			m.mouse_filter = Control.MOUSE_FILTER_IGNORE
			m.z_as_relative = false
			m.z_index = 4000
			m.size = Vector2(4000, 2000)
			w.add_child(m)
			_room_mask.append(m)
	_room_mask[0].position = Vector2(roundf(cc.x) - 2000.0, top - 2000.0)
	_room_mask[1].position = Vector2(roundf(cc.x) - 2000.0, bot)
	for m in _room_mask:
		m.visible = true


## 镜头不声不响地停一下（远处有东西走过的时候）
var _cam_hold := 0.0
var _cam_bar_dy := 0.0                     # 剧情黑边放下来时镜头往下挪的那一点（_bar_cam_dy）


## 剧情黑边放下来的时候（10-31 作者：旧街挂钩那里镜头把晨和妮芙压在画面最底边）：地面低的地方（旧街右半段地面在 236）
## 脚贴着下面那条黑边。镜头跟着黑边往下挪，最多一条黑边高（BAR_H），让脚落回 BAR_FEET_Y 上下；挪出房间的那一截
## 正好被下面的黑边盖住。挪多少跟着黑边放下 / 收起的进度走，收起来的同时回原位，房间外面一直露不出来。
const BAR_FEET_Y := 212.0
func _bar_cam_dy(cy: float) -> float:
	if _bars.size() < 2 or not _bars[1].visible or story == null or story.chen == null:
		return 0.0
	var k := clampf((270.0 - _bars[1].position.y) / BAR_H, 0.0, 1.0)
	var feet: float = story.chen.position.y - (cy - 135.0)
	return floorf(k * clampf(feet - BAR_FEET_Y, 0.0, float(BAR_H)))
var _cam_override := Vector2(NAN, NAN)    # 剧本让镜头去别处（树冠缺口）：镜头就在这，不跟晨


## 镜头移到 to（世界坐标的镜头中心），sec 秒，到了返回。ease：默认两头都缓；竖直平移的前半段 EASE_IN、后半段 EASE_OUT
func camera_pan(to: Vector2, sec: float, ease := Tween.EASE_IN_OUT) -> void:
	_kill_cam_pan()
	_cam_override = cam.position - Vector2(0.0, _cam_bar_dy)
	var tw := create_tween()
	_cam_pan_tw = tw
	tw.tween_property(self, "_cam_override", to, sec).set_trans(Tween.TRANS_SINE).set_ease(ease)
	while tw.is_valid() and tw.is_running():          # 被别的镜头指令停掉也会返回（停掉的 tween 不发 finished）
		if not is_inside_tree():
			return                        # 开发者面板重开本章：这个节点已经不在场景树里了
		await StoryState.frame(get_tree())


var _cam_pan_tw: Tween


## 新的镜头指令来了：还在移的那一下停掉（不然它会把镜头拽回去）
func _kill_cam_pan() -> void:
	if _cam_pan_tw != null and _cam_pan_tw.is_valid():
		_cam_pan_tw.kill()
	_cam_pan_tw = null


## 镜头回去跟着晨（慢慢跟回去，不跳）
func camera_release() -> void:
	_kill_cam_pan()
	_cam_override = Vector2(NAN, NAN)


## 镜头直接停在 p 不跟晨（剧本 camera hold / fade_to 的 cam：让人走出 / 走进画面）
func camera_hold_at(p: Vector2) -> void:
	var target := (p - Vector2(0.0, _cam_bar_dy)).round()       # 存不算黑边的位置（见 _update_camera）
	# 11-05 夜测（--qa_live QA_CAMJUMP，真玩也有）：坠毁后起身的小游戏结束时把镜头停回它记下的位置，一帧跳 21 像素。
	# 画面亮着、要停的地方离现在超过 HOLD_GLIDE：缓缓移过去（黑着、像素块盖着照旧直接停；驾驶舱冲刺那种每帧小步的不受影响）
	var cur := cam.position - Vector2(0.0, _cam_bar_dy)
	if fade.color.a < 0.5 and _pixel_fx == null and cur.distance_to(target) > HOLD_GLIDE and state in [S.PLAY, S.CINE]:
		camera_pan(target, clampf(cur.distance_to(target) / 600.0, 0.3, 0.8))
		return
	_kill_cam_pan()
	_cam_override = target


const HOLD_GLIDE := 24.0
const BAR_DY_RATE := 60.0


func cam_hold(sec: float) -> void:
	_cam_hold = sec


## 镜头跟着晨（往她面朝的方向多看一点）；在树屋里往屋子中心收一点
func _cam_target() -> float:
	var t: float = chen.position.x + chen.facing * LOOK
	if story != null and story.world.in_room():
		t = lerpf(t, float(story.world.house["cx"]), 0.55)
	if story != null and story.world.cockpit != null and story.world.in_cockpit():
		t = story.world.cockpit.center().x           # 驾驶舱一屏：镜头不动
	var sg: Node2D = story.world.cur_stage() if story != null and story.world != null else null
	if sg != null:
		if sg.is_house:
			t = lerpf(t, sg.center().x, 0.55)           # 小屋里往屋子中心收一点（树屋同款）
		t = sg.clamp_cam_x(t)                          # 多房间章节：镜头夹在房间里
	return t


func _update_world(delta: float) -> void:
	# 光柱呼吸（和 forest_test 一样）
	if shafts.visible:
		var i := 0
		for s in shafts.get_children():
			(s as CanvasItem).modulate.a = 0.75 + 0.25 * sin(_t * 0.6 + i * 1.9)
			i += 1
	# 飞船喷口火焰两帧
	if ship.visible:
		_ship_frame_t += delta
		if _ship_frame_t > 0.08:
			_ship_frame_t = 0.0
			ship.frame = 1 - ship.frame
	# 发光木头：光晕慢慢呼吸，偶尔冒一颗光点
	if wood.visible:
		var b := 0.78 + 0.22 * sin(_t * 2.2) + 0.06 * sin(_t * 7.3)
		wood_glow.modulate.a = b
		(wood.get_node("Sprite") as CanvasItem).modulate = Color(1, 1, 1).lerp(Color(1.12, 1.06, 0.95), 0.5 + 0.5 * sin(_t * 2.2))
		if state in [S.PLAY, S.TITLE, S.CRASH] and _rng.randf() < delta * 1.2:
			puffs_front.burst(wood.position + Vector2(0, -4), 1, puffs_front.PRESETS.glint)
	# 自由走：鼠标点了地面就走过去；走到木头旁边进入拾取
	if _free():
		if not is_nan(_walk_target):
			var d := _walk_target - chen.position.x
			var keys := Input.get_axis("ui_left", "ui_right") != 0.0 or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_D)
			if keys or absf(d) <= 4.0 + chen.stop_distance():     # 有惯性：提前松手，滑过去正好停住
				_walk_target = NAN
				chen.auto_dir = 0.0
				if keys:
					_walk_goal = NAN
			else:
				chen.auto_dir = signf(d)
		if state == S.PLAY and free_roam == "" and wood_available() and absf(chen.position.x - WOOD_X) <= PICK_DIST:
			chen.auto_dir = 0.0
			_pending_hs = {}
			_start_pickup()
		elif state == S.PLAY:
			_update_interact()
	elif state == S.CINE and not is_nan(_cine_target):
		var d := _cine_target - chen.position.x
		if absf(d) <= 3.0 + chen.stop_distance() or signf(d) != chen.auto_dir:
			_cine_target = NAN
			_pickup_at_wood()


## 自由走：鼠标点过的 hotspot 走到了就互动；走进 trigger:"enter" 的点自动触发
func _update_interact() -> void:
	if story.busy or _settings.visible or _bag.visible:
		return
	if chapter == "forest" and _story_auto == "" and story.world.room == "forest" \
			and StoryState.has("c1_follow") and not StoryState.has("c1_run") and not StoryState.has("c1_got_bag") \
			and Input.is_key_pressed(KEY_SHIFT):
		story.play("c1_run")
		return
	if not _pending_hs.is_empty():
		var p: Dictionary = _pending_hs
		var h: Dictionary = p["h"]
		if not story.hotspots.usable(h):
			_pending_hs = {}
		elif story.hotspots.in_range(p, chen.position.x) and (is_nan(_walk_target) or absf(chen.position.x - float(p["x"])) <= 8.0):
			_pending_hs = {}
			_interact(p)
			return
		elif is_nan(_walk_target) and chen._vel <= 0.0:
			_pending_hs = {}            # 走到头了还够不着（被看得见的边挡住）：算了
	var a: Dictionary = story.hotspots.auto_trigger(chen.position.x)
	if not a.is_empty():
		if story.quick.is_quick(a["h"]):
			story.trigger(a)              # 走过去就捡：不停下、不锁人（story_quick.gd）
			return
		_interact(a)


func _interact(p: Dictionary) -> void:
	if story.busy or state != S.PLAY:
		return
	if free_roam != "":
		_free_use(p)                      # 自由探索：hotspot 只有进出口，不播剧情、直接换过去
		return
	chen.auto_dir = 0.0
	_walk_target = NAN
	_pending_hs = {}
	# 按下的瞬间：物件闪一下、箭头按下去、一声轻的确认音，晨朝它转身（story.trigger 里转）
	if not story.hotspots.is_enter(p["h"]):
		story.hotspots.pressed(p)
		_sfx("tick", -12.0, 1.25)
	story.trigger(p)


## 屏幕边上的引导箭头：主线下一个地方（等人的鹿 / 会推进剧情的点）在屏幕外时，指向那边
func _update_edge_arrow(cc: Vector2) -> void:
	var side := 0
	var y := 180.0
	if free_play() and free_roam == "":
		var t: Dictionary = story.main_target()
		if not t.is_empty():
			var sx := float(t["x"]) - (cc.x - 240.0)
			if sx < -4.0:
				side = -1
			elif sx > 484.0:
				side = 1
			y = round(float(story.world.ground_at(clampf(float(t["x"]), cc.x - 240.0, cc.x + 240.0)))) - 34.0
	story.dlg.edge_arrow(side, y)


const WALL_SLIDE := 3.0

## 左右不可见的墙：自由走时顶着墙按方向键就松手（不原地跑），位置也夹回来
func _update_walls() -> void:
	if state == S.HEADPHONES or state == S.INTRO or state == S.TITLE or state == S.CRASH:
		return
	var w: Vector2 = free_walls() if free_roam != "" else story.world.walls(chen.position.x)
	# 墙变了（上了楼、换了一段）晨在墙外：每帧最多 WALL_SLIDE 像素走回来，不一帧夹回去（11-04 --qa_live：一下子跳 5 像素）
	if chen.position.x < w.x:
		chen.position.x = move_toward(chen.position.x, w.x, WALL_SLIDE)
	elif chen.position.x > w.y:
		chen.position.x = move_toward(chen.position.x, w.y, WALL_SLIDE)
	if not is_nan(_walk_target):
		_walk_target = clampf(_walk_target, w.x, w.y)
	var dir := Input.get_axis("ui_left", "ui_right")
	if Input.is_key_pressed(KEY_A):
		dir -= 1.0
	if Input.is_key_pressed(KEY_D):
		dir += 1.0
	var into := (chen.position.x <= w.x + 1.0 and dir < 0.0) or (chen.position.x >= w.y - 1.0 and dir > 0.0)
	if into and chen.input_enabled and _free():
		chen.input_enabled = false
		_wall_block = true
	elif _wall_block and not into:
		_wall_block = false
		if _free() and not _settings.visible and not _bag.visible:
			chen.input_enabled = true


## 前景层（Front，近黑的树干）：晨在树屋里 → 整层淡到 0；剧情播放时它的不透明像素挡住了说话的人或晨 → 淡到 FRONT_DIM，
## 这一段剧情播完再淡回来；平时照旧。按屏幕位置在 front.png 上取样判断（取不到图就不判断）。
const FRONT_DIM := 0.15
var _front_img: Image
var _front_latch := false


func _update_front(delta: float) -> void:
	var front: CanvasItem = $Front
	var target := 1.0
	if story.world.in_room():
		target = 0.0
	elif story.busy:
		if not _front_latch:
			for n in [chen, story.npc(story.speaking)]:
				if n != null and (n as Node2D).visible and _front_covers(n):
					_front_latch = true
		if _front_latch:
			target = FRONT_DIM
	else:
		_front_latch = false
	front.modulate.a = move_toward(front.modulate.a, target, delta * 2.0)


## 这个角色身上（脚到头、左右各几像素）有没有好几处被前景层的不透明像素盖住
func _front_covers(n: Node2D) -> bool:
	var spr: Sprite2D = $Front/Sprite
	if _front_img == null:
		_front_img = spr.texture.get_image()
		if _front_img != null and _front_img.is_compressed():
			_front_img.decompress()
	if _front_img == null:
		return false
	var inv := spr.get_global_transform_with_canvas().affine_inverse()
	var left := cam_left()
	var w := _front_img.get_width()
	var h := _front_img.get_height()
	var hits := 0
	for dx in [-9.0, -5.0, 0.0, 5.0, 9.0]:
		for dy in [4.0, 14.0, 24.0, 34.0, 44.0]:
			var p: Vector2 = inv * (n.position - left + Vector2(dx, -dy))
			var px := int(fposmod(floorf(p.x), float(w)))
			var py := int(floorf(p.y))
			if py >= 0 and py < h and _front_img.get_pixel(px, py).a > 0.5:
				hits += 1
	return hits >= 3


## 两段之间走过去（顶着走一小会儿 → 黑屏换过去）：
##   树屋段往左走到头（回旧路的入口 house_return）→ 搭了桥就到林间空地右边（wall_glade 左边一点），没搭桥到 road_return / 布条那里；
##   林间空地往右走到头（wall_glade，搭了桥、去过树屋以后）→ 树屋段左边（treehouse_approach）。
##   10-29 作者：空地右边原来是空气墙、还看得见树屋；树屋段整体往右挪了 500，两段互相看不见，中间靠这条路连着。
var _portal_t := 0.0
var _walk_goal := NAN              # 走去哪（没被墙夹之前的；走过入口用）


func _update_portal(delta: float) -> void:
	var w: Node2D = story.world
	if not w.stages.is_empty():
		_update_stage_portal(delta)
		return
	if not free_play() or not w.markers.has("house_return"):
		_portal_t = 0.0
		return
	var dir := Input.get_axis("ui_left", "ui_right")
	if Input.is_key_pressed(KEY_A):
		dir -= 1.0
	if Input.is_key_pressed(KEY_D):
		dir += 1.0
	var area: String = w.area_of(chen.position.x)
	# 换过去以后晨从 from 走几步到 to（到达，见 story_runner.gd 的 portal_to）：from 就在那一段的入口边上
	var from := NAN
	var to := NAN
	if free_roam != "":
		# 自由探索：两段之间的入口不看剧情（没搭桥、没到过树屋也能走）；旧路段一直到林间空地的尽头
		var a_end := _free_a_end()
		if area == "trees" and chen.position.x <= w.b_start() + 8.0 and (dir < 0.0 or (not is_nan(_walk_goal) and _walk_goal < w.b_start())):
			from = a_end - 6.0
			to = from - ARRIVE_DIST
		elif area == "road" and chen.position.x >= a_end - 8.0 and (dir > 0.0 or (not is_nan(_walk_goal) and _walk_goal > a_end)):
			to = (w.mx("treehouse_approach") if w.markers.has("treehouse_approach") else w.b_start() + 30.0) + ARRIVE_DIST / 2.0
			from = maxf(w.b_start() + 4.0, to - ARRIVE_DIST)
	elif area == "trees":
		var at_edge: bool = chen.position.x <= w.b_start() + 8.0
		var goal_left: bool = not is_nan(_walk_goal) and _walk_goal < w.b_start()
		if at_edge and (dir < 0.0 or goal_left):
			if w.bridged() and w.markers.has("wall_glade"):
				from = w.mx("wall_glade") - 6.0
				to = from - ARRIVE_DIST
			elif w.markers.has("road_return"):
				from = w.mx("road_return")
				to = w.mx("road_arrive") if w.markers.has("road_arrive") else from - ARRIVE_DIST
			else:
				to = w.mx("cloth")
	# 11-04 作者「从树屋过得来但是回不去」：新第一关不设旧的 at_treehouse，晨在弥洛家醒来（c1_woke）就算去过树屋
	elif area == "road" and w.bridged() and w.markers.has("wall_glade") and (StoryState.has("at_treehouse") or StoryState.has("c1_woke")):
		var edge: float = w.mx("wall_glade")
		var goal_right: bool = not is_nan(_walk_goal) and _walk_goal > edge
		if chen.position.x >= edge - 8.0 and (dir > 0.0 or goal_right):
			to = (w.mx("treehouse_approach") if w.markers.has("treehouse_approach") else w.b_start() + 30.0) + ARRIVE_DIST / 2.0
			from = maxf(w.b_start() + 4.0, to - ARRIVE_DIST)
	if is_nan(to):
		_portal_t = 0.0
		return
	_portal_t += delta
	if _portal_t > 0.35:
		_portal_t = 0.0
		_walk_target = NAN
		_walk_goal = NAN
		story.portal_to(to, from)


## 多房间章节：顶着房间两头的墙走 0.35 秒 → 去 room.json portals 里那一头连着的房间（剧本 fade_to 那套转场）
func _update_stage_portal(delta: float) -> void:
	var sg: Node2D = story.world.cur_stage()
	if sg == null or not free_play() or story.mech_wait:
		_portal_t = 0.0
		return
	var dir := Input.get_axis("ui_left", "ui_right")
	if Input.is_key_pressed(KEY_A):
		dir -= 1.0
	if Input.is_key_pressed(KEY_D):
		dir += 1.0
	var wl: Vector2 = free_walls() if free_roam != "" else sg.walls()
	var edge := ""
	if chen.position.x <= wl.x + 1.0 and (dir < 0.0 or (not is_nan(_walk_goal) and _walk_goal < wl.x)):
		edge = "left"
	elif chen.position.x >= wl.y - 1.0 and (dir > 0.0 or (not is_nan(_walk_goal) and _walk_goal > wl.y)):
		edge = "right"
	var pt: Dictionary = {}
	if edge != "":
		for p in sg.portals():
			if p is Dictionary and str(p.get("edge", "")) == edge and (sg.portal_open(p) or free_roam != ""):
				pt = p
				break
	if pt.is_empty():
		_portal_t = 0.0
		return
	_portal_t += delta
	if _portal_t > 0.35:
		_portal_t = 0.0
		_walk_target = NAN
		_walk_goal = NAN
		story.portal_room(pt)


## 自由走（含鹿带路时：剧情没播完但晨能自己走）
func _free() -> bool:
	return state == S.PLAY or (state == S.CINE and story != null and story.free_walk)


func _update_hints(delta: float) -> void:
	# 木头上方的小箭头：能走以后 2.5 秒出现，上下浮 1 像素，很淡地闪
	if state == S.PLAY and wood.visible and free_roam == "":
		_hint_wait += delta
		if _hint_wait > 2.5:
			wood_hint.visible = true
			wood_hint.position.y = -16.0 - (1.0 if fmod(_t, 1.2) < 0.6 else 0.0)
			wood_hint.modulate.a = clampf((_hint_wait - 2.5) / 0.8, 0.0, 1.0) * (0.55 + 0.35 * sin(_t * 3.0))
	# 「← →」：能走以后 1.5 秒还没动就在晨脚下出现，动了就消失
	var show_keys := state == S.PLAY and wood.visible and free_roam == "" and not is_nan(_moved_from) \
		and absf(chen.position.x - _moved_from) < 14.0 and _state_t > 1.5 and not _bag.visible and not _settings.visible
	var target_a := (0.35 + 0.2 * sin(_t * 2.6)) if show_keys else 0.0
	_keys_hint.modulate.a = move_toward(_keys_hint.modulate.a, target_a, delta * 1.5)
	if _keys_hint.modulate.a > 0.0:
		var sx := chen.position.x - (cam.get_screen_center_position().x - 240.0)
		_keys_hint.position = Vector2(round(sx - 20.0), chen.position.y + 6.0)


# ======================================================================= 给剧本引擎用（story_runner.gd 调）
func story_begin(bars: bool) -> void:
	_set_state(S.CINE)
	chen.input_enabled = false
	chen.auto_dir = 0.0
	_walk_target = NAN
	_walk_goal = NAN                  # 过场前点的地方作废（不然播完以后走到入口边上会自己换过去）
	_pending_hs = {}
	_leave_play_ui()
	_dlg_hide(0.3)
	_story_bars = bars
	if bars:
		_bars_in(0.5)


func story_end() -> void:
	camera_release()                  # 剧本停住的镜头（camera / fade_to cam）播完一律放开，免得自由走的时候镜头不跟
	if _story_bars:
		_bars_out(0.5)
	_story_bars = false
	_enter_play()
	if _bag_after_story:
		_bag_after_story = false
		_bag_sel = maxi(0, Inventory.owned.find("elephant_drawing"))
		_toggle_bag()




## 对话框 / 头顶气泡现在压没压到左上角的目标那一块（主目标、「（可选）」、燃料表）
func _hud_covered() -> bool:
	if story == null or story.dlg == null:
		return false
	var hud := Rect2(_hud_burn.position, _hud_burn.size)
	if _hud_side != null and _hud_side.visible and _hud_side.text != "":
		hud = hud.merge(Rect2(_hud_burn.position + _hud_side.position, _hud_side.size))
	for box_name in ["_box"]:
		for host in [story.dlg, story.bark]:
			var b = host.get(box_name) if host != null else null
			if b is Control and (b as Control).is_visible_in_tree() and Rect2((b as Control).global_position, (b as Control).size).grow(2.0).intersects(hud):
				return true
	return false


## 树冠缺口那一屏（story_world.gd 的 treeline_view_in / out 调）：左上角的目标 / 燃料和右上角的背包淡出，
## 这一屏结束再淡回原来的透明度（藏着的时候背包点不到）
var _hud_saved := {}
func hud_fade(hide: bool, sec: float) -> void:
	for n: Control in [_hud_burn, _bag_btn]:
		if hide:
			if not _hud_saved.has(n):
				_hud_saved[n] = n.modulate.a
			create_tween().tween_property(n, "modulate:a", 0.0, sec)
		elif _hud_saved.has(n):
			create_tween().tween_property(n, "modulate:a", float(_hud_saved[n]), sec)
	_bag_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE if hide else Control.MOUSE_FILTER_STOP
	if not hide:
		_hud_saved.clear()


## 鹿带路：剧情没播完，晨先自己走（黑边收起）
func story_free(on: bool) -> void:
	chen.input_enabled = on
	if on:
		camera_release()
	_walk_target = NAN
	if on and _story_bars:
		_bars_out(0.4)
		_story_bars = false


func bars_on() -> bool:
	return _bars[0].position.y > -BAR_H + 1.0


func cam_left() -> Vector2:
	return cam.get_screen_center_position() - Vector2(240, 135) / cam.zoom.x     # 拉近时看到的世界小一圈


func free_play() -> bool:
	return state == S.PLAY and not _settings.visible and not _bag.visible and not story.busy


func walk_to(x: float) -> void:
	_walk_target = x
	_walk_goal = x


## 过场里的「到达」（10-29）：晨走几步到 x 停住。走路的速度（STROLL_SPEED，比跑慢得多），慢慢起步、慢慢停；
## 动画照旧是跑的那几帧、100ms 一帧，只改移动速度。玩家能动的时候（过场播完了）立刻松手，绝不推着玩家走。
const ARRIVE_DIST := 40.0          # 到达走多远（几步）
const STROLL_SPEED := 55.0         # 像素 / 秒
const STROLL_EASE := 0.35          # 起步 / 停下各用多久（秒）
var _stroll_x := NAN
var _stroll_t := 0.0


func stroll_to(x: float) -> void:
	var dir := signf(x - chen.position.x)
	if dir == 0.0 or absf(x - chen.position.x) < 1.0:
		return
	_stroll_x = x
	_stroll_t = 0.0
	chen._set_facing(int(dir))
	chen.auto_dir = dir
	var t := 0.0
	var limit := absf(x - chen.position.x) / STROLL_SPEED + 2.0
	while not is_nan(_stroll_x) and t < limit:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()
	_stroll_x = NAN
	chen.auto_dir = 0.0
	t = 0.0
	while chen._vel > 0.0 and t < 0.5:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()


func strolling() -> bool:
	return not is_nan(_stroll_x)


## 每帧（在晨自己算速度之前）把她的速度按到这一帧该有的走路速度：chen.gd 会再往 RUN_SPEED 加一帧的加速度，这里先减掉
func _update_stroll(delta: float) -> void:
	if is_nan(_stroll_x):
		return
	var px: float = chen.position.x if is_nan(chen._x) else chen._x
	var d := _stroll_x - px
	if player_free() or chen.auto_dir == 0.0 or signf(d) != chen.auto_dir or absf(d) < 0.6:
		_stroll_x = NAN
		chen.auto_dir = 0.0
		chen._vel = minf(chen._vel, 20.0)
		return
	_stroll_t += delta
	var a := STROLL_SPEED / STROLL_EASE
	var v := STROLL_SPEED * smoothstep(0.0, STROLL_EASE, _stroll_t + delta)
	v = maxf(minf(v, sqrt(2.0 * a * absf(d))), 8.0)
	chen._vel = maxf(0.0, v - chen.RUN_SPEED / chen.ACCEL_TIME * delta)


## 玩家能自己走了（自由走 / 鹿带路时）：过场里的走位一律松手
func player_free() -> bool:
	return state == S.PLAY or (story != null and story.free_walk and chen.input_enabled)


func walking() -> bool:
	return not is_nan(_walk_target) or chen._vel > 0.0


func wood_available() -> bool:
	return wood.visible and not story.world.in_room()


## 跳节拍：木头直接进背包，剧本里木头那个 scene 瞬间过一遍
func ff_take_wood() -> void:
	wood.visible = false
	wood_hint.visible = false
	if not Inventory.has("glowing_wood"):
		Inventory.add("glowing_wood")
	on_inventory_changed()
	var h: String = story.hook("wood")
	if h != "":
		await story.play_wood(h)
	StoryState.set_flag("got_wood")


## 背包变了：HUD、背包图标、燃烧值够了设 fuel_full
func on_inventory_changed() -> void:
	_update_hud()
	if not Inventory.owned.is_empty() and not story.bag_locked():
		_bag_btn.visible = true
		_bag_btn.modulate.a = 1.0
	if Inventory.burn_total() > Inventory.base_burn and _seq.is_empty():
		_hud_burn.modulate.a = 1.0          # 木头拾取过场里先不亮（燃烧值滚完才收进左上角）
	if Inventory.burn_total() >= Inventory.get_launch_burn():
		StoryState.set_flag("fuel_full")
	if _bag.visible:
		_bag_refresh()


func bag_target() -> Vector2:
	return _bag_btn.position + _bag_btn.size / 2.0


func bag_bump() -> void:
	_sfx("tick", -6.0, 0.8)
	_bag_btn.scale = Vector2(1.5, 1.5)
	create_tween().tween_property(_bag_btn, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## 剧本 key_prompt：屏幕下方一行提示，不锁人。until = run（按住 Shift 跑起来一会儿）/ bag（打开背包）/ photo（查看背包照片）/ ""（只看时间）
func key_prompt(text: String, until: String, sec: float, delay := 0.0) -> void:
	_key_prompt.text = text
	_kp_until = until
	_kp_left = INF if sec <= 0.0 and until != "" else sec
	_kp_done = 0.0
	_kp_delay = delay              # 晚几秒再出（「按 Tab 打开背包」：先让奔跑的片头字幕播完）；这期间已经做到了就不出


func _update_key_prompt(delta: float) -> void:
	var on := _kp_left > 0.0
	if on and _kp_delay > 0.0:
		_kp_delay -= delta
		if (_kp_until == "bag" and _bag.visible) or (_kp_until == "run" and chen._vel > CHEN_GD.RUN_SPEED * 1.1):
			_kp_left = 0.0
		_key_prompt.modulate.a = move_toward(_key_prompt.modulate.a, 0.0, delta * 1.5)
		return
	if on:
		_kp_left -= delta
		var did := false
		match _kp_until:
			"run":
				did = StoryState.has("c1_run") or StoryState.has("c1_got_bag") or chen._vel > CHEN_GD.RUN_SPEED * 1.1
			"bag":
				did = _bag.visible or (_story_auto != "" and _kp_left < 12.0)
			"photo":
				did = story.played.has("c1_drawing")
		_kp_done = _kp_done + delta if did else 0.0
		if _kp_done > (0.6 if _kp_until == "run" else 0.0):
			_kp_left = 0.0
	var show: bool = _kp_left > 0.0 and not _settings.visible and not _bag.visible and not story.dlg.is_open()
	var target := (0.75 + 0.15 * sin(_t * 3.0)) if show else 0.0
	_key_prompt.modulate.a = move_toward(_key_prompt.modulate.a, target, delta * (2.5 if show else 1.5))


## 八比特转场（fade_to style pixel）：屏幕分成 16 像素的格子，按打乱的顺序一格一格盖黑（100ms 一档，8 档）；
## 盖满以后换成平常的黑幕，揭开时反过来。
const PIXEL_CELL := 16
const PIXEL_STEPS := 8


func pixel_to_black(sec: float) -> void:
	await _pixel_run(sec, true)
	fade.color.a = 1.0
	_pixel_fx.queue_free()
	_pixel_fx = null


func pixel_from_black(sec: float) -> void:
	fade.color.a = 0.0
	await _pixel_run(sec, false)
	_pixel_fx.queue_free()
	_pixel_fx = null


func _pixel_run(sec: float, cover: bool) -> void:
	if _pixel_fx != null and is_instance_valid(_pixel_fx):
		_pixel_fx.queue_free()
	_pixel_fx = Control.new()
	_pixel_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pixel_fx.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.get_parent().add_child(_pixel_fx)
	fade.get_parent().move_child(_pixel_fx, fade.get_index() + 1)
	var fx := _pixel_fx
	fx.set_meta("k", 0 if cover else PIXEL_STEPS)
	fx.draw.connect(func():
		var k: int = fx.get_meta("k")
		var cols := int(ceil(480.0 / PIXEL_CELL))
		var rows := int(ceil(270.0 / PIXEL_CELL)) + 1
		for cy in rows:
			for cx in cols:
				var h := absi(hash(Vector2i(cx, cy))) % PIXEL_STEPS     # 每格第几档盖上（同一格永远同一档）
				if h < k:
					fx.draw_rect(Rect2(cx * PIXEL_CELL, cy * PIXEL_CELL, PIXEL_CELL, PIXEL_CELL), Color.BLACK))
	fx.queue_redraw()
	var per := sec / float(PIXEL_STEPS)
	for i in PIXEL_STEPS:
		await get_tree().create_timer(per, false).timeout
		if not is_instance_valid(fx):
			return
		fx.set_meta("k", (i + 1) if cover else (PIXEL_STEPS - 1 - i))
		fx.queue_redraw()


## 镜头拉近 / 拉回（剧本 camera zoom；奔跑片头、玩具熊那一下）。换房间时回到 1。
func camera_zoom(z: float, sec: float) -> void:
	if _zoom_tw != null and _zoom_tw.is_valid():
		_zoom_tw.kill()
	if sec <= 0.0:
		cam.zoom = Vector2(z, z)
		return
	_zoom_tw = create_tween()
	_zoom_tw.tween_property(cam, "zoom", Vector2(z, z), sec).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	await _zoom_tw.finished


## 黑幕只留一个 tween（11-04 连拍：河流篇起飞自己起了 1.2 秒的淡出、fade_to 又起一个淡出、换房间后再淡入，
## 两个 tween 抢 fade 的透明度，驾驶舱亮一下、又黑、再亮）：开新的之前停掉旧的，后来的说了算
var _fade_tw: Tween


func fade_to_black(sec: float) -> void:
	await _fade_go(1.0, sec)


func fade_from_black(sec: float) -> void:
	await _fade_go(0.0, sec)


func _fade_go(a: float, sec: float) -> void:
	if _fade_tw != null and _fade_tw.is_valid():
		_fade_tw.kill()
	var tw := create_tween()
	_fade_tw = tw
	tw.tween_property(fade, "color:a", a, sec).set_trans(Tween.TRANS_SINE)
	while tw.is_valid() and tw.is_running():          # 被后来的停掉也返回（停掉的 tween 不发 finished）
		await StoryState.frame(get_tree())


## 换了位置：黑屏换地方时镜头直接跳过去、雾直接到位（进出屋不黑屏，镜头照常跟）；屋里雨声小一点
func on_room_changed(snap := true) -> void:
	if snap and cam.zoom.x != 1.0:
		camera_zoom(1.0, 0.0)
	_walk_target = NAN
	_walk_goal = NAN
	_pending_hs = {}
	if snap:
		_snap_camera()
		story.world.fog_k = story.world.fog_at(cam.position.x)
	if chapter != "forest":
		_sync_forest_layers()
		_hum_to(story.world.room == "cockpit")       # 引擎声跟着房间：回驾驶舱淡进来、落地到别的房间淡掉（同一个播放器，不重开）
		_birds_to(_birds_db_for(story.world.room))   # 鸟叫跟着房间（尾声森林 / 芦苇地 / 停着的驾驶舱），别的房间淡掉
		return                                       # 驾驶舱里没有雨
	_fade_db(_rain, RAIN_ROOM_DB if story.world.in_room() else RAIN_DB, 1.2)      # 房间的环境音在 room_stage.ambient_enter 里同时淡进来，两边交叉


## 别的章节里的鸟叫（11-05 qa_audio：终章落地后芦苇地 → 尾声森林 57 秒没有任何环境声）：森林章同一条 forest_birds（_rain），
##   尾声森林 RAIN_DB；芦苇地同一条轻 4 dB（场上没别的环境声）；落地后停在芦苇地的驾驶舱（e1_phone，hum_done 以后）隔着壳 -30；
##   树屋和别的房间 RAIN_ROOM_DB（-60，作者：进屋鸟叫淡出）。都是 2 秒交叉淡化，同一个播放器只改音量。
func _birds_db_for(room: String) -> float:
	if room == "forest":
		return RAIN_DB
	if room == "reed_field":
		return RAIN_DB - 4.0
	if room == "cockpit" and _hum_done:
		return -30.0
	return RAIN_ROOM_DB


func _birds_to(db: float) -> void:
	if _rain == null or not is_instance_valid(_rain):
		return
	if db > RAIN_ROOM_DB and not _rain.playing:
		_rain.volume_db = -60.0
		_rain.play()
	_fade_db(_rain, db, 2.0)


## 别的章节里回到森林（终章尾声：森林路口 → 树屋，docs/第三章计划.md 第十节）：_start_chapter 藏起来的森林图层再显示出来，
## 离开森林（去房间 / 驾驶舱）再藏起来，鹿和弥洛也一起藏（她们留在森林里）。不开雨（尾声是后来回访）；
## 飞船、外星同伴、发光木头、蛇都不出来（船早就飞走了）。都是在黑屏里换的（fade_to），看不到切换那一下。
const FOREST_LAYERS := ["Sky", "Ridge", "Far", "ForestShadows", "Deep", "MidFar", "Mid", "Main", "PuffsBack", "PuffsFront", "Front",
	"StoryProps", "StoryFogProps", "TreehouseFront"]
var _forest_on := false


func _sync_forest_layers() -> void:
	var on: bool = story.world.room in ["forest", "treehouse"]
	if on == _forest_on:
		return
	_forest_on = on
	for n in FOREST_LAYERS:
		var node := get_node_or_null(n)
		if node is CanvasItem:
			(node as CanvasItem).visible = on
		elif node != null and node.has_method("set_visible"):
			node.call("set_visible", on)
	shafts.visible = on
	if not on:
		story.deer.visible = false
		story.miluo.visible = false
	print("FOREST_LAYERS %s room=%s" % ["on" if on else "off", story.world.room])


func _snap_camera() -> void:
	cam.position = Vector2(_cam_target(), story.world_cam_y() if story != null and story.world != null else 135.0)
	cam.reset_smoothing()


## 剧本里不是图的物件：ship:launch = 晨上船（_board_ship：绕到船尾、换到飞船后面、走到舱门被船身挡住、淡掉、舱门声）；
## 鹿往旁边让开（别被船和尘土盖住）。点火、离地都在 story_takeoff 里（剧本 end_chapter 时）。
func _on_pseudo_prop(id: String, st: String) -> void:
	if id == "ship" and st == "launch":
		_deer_clear()
		if story.ff or not chen.visible:
			chen.visible = false
			return
		_board_ship()


## 鹿站得离船太近：走到船尾右边一点（起飞的船、尘土都别盖住它）
func _deer_clear() -> void:
	var deer: Node2D = story.deer
	var safe := wreck.position.x + DEER_BOARD_DX
	if deer.visible and deer.position.x < safe:
		if deer.has_method("walk_to"):
			deer.call("walk_to", safe)
		else:
			deer.run_to(safe)


# ----------------------------------------------------------------------- 上船（10-29 作者：「主角离开时图层改到飞船后面，从这里进入」）
## 平面侧视里「走到船的另一侧」= 先绕过船尾（船尾右边、和船身不重叠的地方才换图层，换的那一下看不出来），
## 换到飞船后面，回头往舱门走：腿从船腹底下露出来、上身被船身挡住；最后一小段边走边按 4 档淡掉（从另一侧的舱门进去了），
## 停一下，舱门「哐」一声，船身轻轻一沉。不黑屏、不突然消失。
const BOARD_AROUND := 112.0        # 绕到船尾右边哪（相对 wreck.x）：船图最右是 +92（喷口），晨半宽约 13，留几像素
const BOARD_HATCH := 20.0          # 走到哪停（= WRECK_HATCH.x，舱门正后面）
const BOARD_FADE := 26.0           # 离舱门还有这么远开始淡
const DEER_BOARD_DX := 168.0       # 鹿让到哪（相对 wreck.x）= 剧本的 deer_board：晨绕船尾的那段路（到 BOARD_AROUND + 半宽）右边
const BOARD_CHEN_HALF := 14.0      # 晨站着的半宽
const BOARD_DEER_HALF := 22.0      # 鹿的半宽（头到尾的一半，留一点）
var _boarding := false
var _chen_idx := -1                # 上船前晨在场景树里的位置（起飞完 / 重开时放回去）


func _board_ship() -> void:
	_boarding = true
	var around := wreck.position.x + BOARD_AROUND
	var hatch := wreck.position.x + BOARD_HATCH
	# 鹿还在让开：等它让出晨要走的那段（绕船尾那一下不和鹿交错）。鹿还在往右走的话，晨走过去这 ~0.8 秒里它还会再让出
	# 一截（WALK_SPEED × 0.8），所以不用等它完全停下
	var deer: Node2D = story.deer
	var wt := 0.0
	while deer.visible and wt < 5.0:
		var moving: bool = (deer.has_method("is_walking") and bool(deer.call("is_walking"))) or deer.is_running()
		var need := around + BOARD_CHEN_HALF + BOARD_DEER_HALF + 4.0 - (24.0 if moving else 0.0)
		if deer.position.x >= need or (not moving and deer.position.x < chen.position.x):
			break
		await StoryState.frame(get_tree())
		wt += get_process_delta_time()
	if absf(around - chen.position.x) > 8.0:
		await _cine_walk(around)        # 已经站在船尾边上（和鹿道别的地方）就不再挪那几个像素（起步又停，像抽了一下）
	# 绕过船尾了：换到飞船后面（船图 Wreck 前面一格；这时晨和船身不重叠）
	_chen_idx = chen.get_index()
	move_child(chen, wreck.get_index())
	await get_tree().create_timer(0.15, false).timeout
	chen._set_facing(-1)
	await get_tree().create_timer(0.1, false).timeout
	var fade_from := hatch + BOARD_FADE
	chen.auto_dir = -1.0
	var t := 0.0
	while chen.position.x > hatch + 2.0 and t < 4.0:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()
		var k := clampf((fade_from - chen.position.x) / BOARD_FADE, 0.0, 1.0)
		chen.modulate.a = 1.0 - floorf(k * 4.0) / 4.0
	chen.auto_dir = 0.0
	chen.visible = false
	chen.modulate.a = 1.0
	await get_tree().create_timer(0.35, false).timeout
	_sfx("metal_clank", -9.0, 0.72)                  # 舱门关上
	var w0 := wreck.position
	wreck.position = w0 + Vector2(0, 1)              # 船身轻轻一沉
	await get_tree().create_timer(0.1, false).timeout
	_sfx("small_click", -10.0, 0.8)
	wreck.position = w0
	await get_tree().create_timer(0.3, false).timeout
	_boarding = false


## 过场里让晨自己走到 x（锁着操作；走路动画照常 100ms 一帧，chen.gd 自己管）
func _cine_walk(x: float) -> void:
	var dir := signf(x - chen.position.x)
	if dir == 0.0:
		return
	chen.auto_dir = dir
	var t := 0.0
	while signf(x - chen.position.x) == dir and absf(x - chen.position.x) > 2.0 + chen.stop_distance() and t < 4.0:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()
	chen.auto_dir = 0.0
	t = 0.0
	while chen._vel > 0.0 and t < 1.0:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()


func _restore_chen_order() -> void:
	if _chen_idx >= 0 and chen.get_parent() == self:
		move_child(chen, mini(_chen_idx, get_child_count() - 1))
	_chen_idx = -1


# ----------------------------------------------------------------------- 起飞（10-29 重做）
## 坠毁图拆成两层：船身（_lift：art/level1/ship_lift.png，按角度预先画好的帧，-17°..+10° 每 1° 一帧，硬边像素，
## 「转」= 换帧，不旋转图片）和留在原地的土（Wreck 节点换成 ship_crater.png：0 帧 = 和坠毁图里一样的土，
## 1 帧 = 机头拔出来以后的坑）。-17° 那帧 + 土 和坠毁图逐像素一样，换的那一下不跳。
## 扎在土里的那截机头：_lift 用 shader 按坠毁图的地面线裁掉，船升起来它就从土里「拔」出来。
##   1. 预热 TAKEOFF_WARM 秒：引擎声；喷口里亮起暗暗的余火（闪两下再亮住），船身 1 像素的抖越来越密，
##      船身外一圈热光（scripts/ship_glow.gd 的 heat = 1：暖红，推进器那头最亮；10-30 作者：「最开始上升的时候没有外侧的光，
##      我觉得红光不错」）慢慢亮到 TAKEOFF_GLOW_WARM，船腹底下的尘土往两边吹
##   2. 离地 TAKEOFF_LIFT 秒：竖直升 TAKEOFF_RISE 像素（smoothstep，速度先加后减），边升边把机头摆平到 TAKEOFF_LEVEL_ANG；
##      热光托底 TAKEOFF_GLOW_WARM、再跟着竖直速度往上加（ship_glow.drive），悬停时收到一点底，尾焰点着以后慢慢熄；机头拔出土的时候土块往下掉（落到地上停住、慢慢淡掉），坑露出来、扬一小团尘
##   3. 悬停 TAKEOFF_HOVER 秒：上下 1 像素慢慢起伏，泛光留一点底
##   4. 走：尾焰点着（两帧 100ms 交替），机头继续慢慢抬到 TAKEOFF_PITCH_ANG；速度从 0 开始 ease-in（v = TAKEOFF_ACC·t²），
##      方向一直是机头朝向（角度连续变，所以路径是一条往左上弯的平滑曲线），出了画面左边 → 停 0.6 秒 → 淡到黑
## 镜头：预热那 1.5 秒慢慢摆到 wreck.x + TAKEOFF_CAM_DX，然后不动：船飞出画面，留下土坑和鹿。绝不往后倒，方向一直和机头一致。
const LIFT_TEX := preload("res://art/level1/ship_lift.png")
const CRATER_TEX := preload("res://art/level1/ship_crater.png")
const WRECK_TEX := preload("res://art/level1/ship_wreck.png")
const SHIP_GLOW := preload("res://scripts/ship_glow.gd")
const LIFT_META := "res://art/level1/ship_lift.json"
const LIFT_ANG0 := -17             # ship_lift.png 第 0 列的角度（度；负 = 机头朝左下）
const LIFT_N := 28                 # 列数（-17..+10）
const LIFT_FRAME := Vector2i(204, 120)
const LIFT_ENGINE := Vector2(72, -1)       # 喷口在船自己坐标里（机头朝左、x 往尾巴）
const LIFT_NOSE_LOW := Vector2(-58, 16)    # 机头下沿（拔出土的那一点）
const TAKEOFF_WARM := 1.5
const TAKEOFF_LIFT := 2.3
const TAKEOFF_RISE := 30.0
const TAKEOFF_LEVEL_ANG := -4.0
const TAKEOFF_HOVER := 0.7
const TAKEOFF_PITCH_ANG := 9.0
const TAKEOFF_PITCH_T := 1.6       # 从摆平抬到 TAKEOFF_PITCH_ANG 用多久（和加速同时开始）
const TAKEOFF_ACC := 150.0         # 速度 = TAKEOFF_ACC · t²（像素 / 秒）
const TAKEOFF_GLOW_WARM := 0.55   # 预热时热光亮到多少（离地后按竖直速度再往上，满亮约 1）
const TAKEOFF_CAM_DX := 70.0       # 起飞时镜头停在哪（相对 wreck.x）：船在画面左半边、鹿在右边，船往左飞有地方
const CLIP_SHADER := "shader_type canvas_item;\nuniform float clip_y = 100000.0;\nvarying float wy;\n" + \
	"void vertex() { wy = (MODEL_MATRIX * vec4(VERTEX, 0.0, 1.0)).y; }\n" + \
	"void fragment() { if (wy >= clip_y) { discard; } }\n"
var _lift: Sprite2D
var _lift_glow: Node2D
var _lift_hull := {}               # 角度（整数度）→ [tops, bots]（ship_lift.json）
var _lift_ang := 0.0               # 现在的角度（度，连续；显示时取最近的整数帧）
var _lift_row := 0                 # 0 喷口不亮 / 1 余火 / 2、3 尾焰两帧
var _lift_pos := Vector2.ZERO      # 船身中心（世界，小数；显示取整）
var _lift_hull_ang := 999


func story_takeoff() -> void:
	if chapter != "forest":
		# 驾驶舱章节结束：没有起飞过场，黑边 + 淡到黑，再出结束卡
		_bars_in(0.6)
		if _engine_hum != null:
			_fade_db(_engine_hum, -60.0, 1.6)
		await fade_to_black(1.6)
		_end_t = 0.0
		return
	var t := 0.0
	while _boarding and t < 6.0:
		await StoryState.frame(get_tree())
		t += get_process_delta_time()
	chen.visible = false
	_bars_in(0.6)
	_deer_clear()
	_fade_db(_crackle, -80.0, 1.0)
	for k in ["wreck", "wreck2", "wreck3", "embers", "embers2"]:
		puffs_back.remove_source(k)
		puffs_front.remove_source(k)
	if not wreck.visible:
		_show_wreck()
		for k in ["wreck", "wreck2", "wreck3", "embers", "embers2"]:
			puffs_back.remove_source(k)
			puffs_front.remove_source(k)
	_lift_setup()
	camera_pan(Vector2(wreck.position.x + TAKEOFF_CAM_DX, 135.0), TAKEOFF_WARM)   # 镜头慢慢摆好、然后不动：船从左边飞出画面
	var w0 := wreck.position
	var c0 := _lift_pos
	# ---- 1. 预热
	_sfx("engine_start", -4.0)
	t = 0.0
	var ign := [0.15, 0.25, 0.4, 0.5, 0.62]          # 喷口余火：亮、灭、亮、灭、亮住
	while t < TAKEOFF_WARM:
		if not is_inside_tree():
			return                        # 开发者面板重开本章：这个节点已经不在场景树里了
		await StoryState.frame(get_tree())
		var dt := get_process_delta_time()
		t += dt
		var k := t / TAKEOFF_WARM
		var on := 0
		for a in ign:
			if t >= a:
				on = 1 - on
		_lift_row = on
		var jit := Vector2.ZERO
		if _rng.randf() < 0.08 + 0.4 * k:
			jit.x = _rng.randi_range(-1, 1)
		_lift_pos = c0 + jit
		_lift_glow.strength = TAKEOFF_GLOW_WARM * smoothstep(0.2, 1.0, k)
		_lift_glow.step(dt)
		_lift_show()
		if _rng.randf() < dt * (4.0 + 14.0 * k):
			var gx := c0.x + _rng.randf_range(-40.0, 60.0)
			puffs_back.burst(Vector2(gx, _ground(gx)), 1, puffs_back.PRESETS.dust_small.merged(
				{"vx": Vector2(-30, -8) if gx < c0.x else Vector2(8, 30), "vy": Vector2(-8, -2)}))
	_lift_row = 1
	_lift_glow.hold = TAKEOFF_GLOW_WARM               # 托底：升的时候至少这么亮（再按竖直速度往上加），也让它一直是热光
	_lift_glow.hold_goal = TAKEOFF_GLOW_WARM
	# ---- 2. 离地（反重力：竖直往上，机头慢慢摆平）
	_shake = 0.5
	_shake_amp = 1.0
	var popped := false
	t = 0.0
	var y_prev := c0.y
	while t < TAKEOFF_LIFT:
		if not is_inside_tree():
			return                        # 开发者面板重开本章：这个节点已经不在场景树里了
		await StoryState.frame(get_tree())
		var dt := get_process_delta_time()
		t += dt
		var k := clampf(t / TAKEOFF_LIFT, 0.0, 1.0)
		var y := c0.y - TAKEOFF_RISE * smoothstep(0.0, 1.0, k)
		_lift_ang = lerpf(float(LIFT_ANG0), TAKEOFF_LEVEL_ANG, smoothstep(0.25, 1.0, k))
		_lift_pos = Vector2(c0.x, y)
		_lift_glow.drive((y - y_prev) / maxf(dt, 0.001), dt)
		y_prev = y
		_lift_show()
		# 机头拔出土：那一点还在地面以下时往下掉土块；一出来就露出坑、扬一小团尘
		var nose := _lift_pos + LIFT_NOSE_LOW.rotated(deg_to_rad(_lift_ang))
		if not popped:
			if _rng.randf() < dt * 16.0:
				_drop_clod(Vector2(nose.x + _rng.randf_range(-4.0, 14.0), minf(nose.y, w0.y) - _rng.randf_range(0.0, 6.0)), w0.y)
			if nose.y < w0.y - 1.0:
				popped = true
				wreck.frame = 1
				puffs_back.burst(Vector2(nose.x + 6.0, w0.y), 8, puffs_back.PRESETS.dust.merged({"spread": Vector2(12, 1), "vy": Vector2(-30, -8)}))
				for i in 5:
					_drop_clod(nose + Vector2(_rng.randf_range(-2.0, 20.0), _rng.randf_range(-3.0, 2.0)), w0.y)
		elif _rng.randf() < dt * 3.0 and k < 0.75:
			_drop_clod(nose + Vector2(_rng.randf_range(0.0, 30.0), -2.0), w0.y)   # 船腹上沾的最后几块
	# ---- 3. 悬停
	var hover := _lift_pos
	_lift_glow.hold_goal = 0.3                       # 悬停：慢慢收到一点底
	t = 0.0
	y_prev = hover.y
	while t < TAKEOFF_HOVER:
		await StoryState.frame(get_tree())
		var dt := get_process_delta_time()
		t += dt
		var y := hover.y - roundf(sin(t / TAKEOFF_HOVER * PI))
		_lift_pos = Vector2(hover.x, y)
		_lift_glow.drive(0.0, dt)
		_lift_show()
	_lift_pos = hover
	# ---- 4. 尾焰点着，机头抬起，沿机头方向 ease-in 加速飞走
	_sfx("ship_whoosh", -5.0, 0.85)
	_sfx("engine_boost", -8.0)
	_shake = 0.5
	_shake_amp = 1.5
	puffs_back.add_source("trail", _lift_engine(), 26.0, puffs_back.PRESETS.trail)
	puffs_back.add_source("trail_sparks", _lift_engine(), 6.0, puffs_back.PRESETS.ember)
	t = 0.0
	var a0 := _lift_ang
	var p := _lift_pos
	while t < 5.0:
		await StoryState.frame(get_tree())
		var dt := get_process_delta_time()
		t += dt
		_lift_row = 2 + int(t / 0.1) % 2
		_lift_ang = lerpf(a0, TAKEOFF_PITCH_ANG, smoothstep(0.0, 1.0, t / TAKEOFF_PITCH_T))
		var a := deg_to_rad(_lift_ang)
		var v := TAKEOFF_ACC * t * t
		p += Vector2(-cos(a), -sin(a)) * v * dt      # 机头朝向（机头朝左：-x；角度正 = 机头往上）
		_lift_pos = p
		_lift_glow.strength = move_toward(_lift_glow.strength, 0.0, 0.5 * dt)   # 尾焰点着以后热光慢慢收掉（不按速度再亮）
		_lift_glow.step(dt)
		_lift_show()
		puffs_back.set_source_pos("trail", _lift_engine())
		puffs_back.set_source_pos("trail_sparks", _lift_engine())
		if _lift_pos.x < cam_left().x - 120.0 or _lift_pos.y < -80.0:
			break
	puffs_back.remove_source("trail")
	puffs_back.remove_source("trail_sparks")
	_lift.visible = false
	await get_tree().create_timer(0.6, false).timeout
	await fade_to_black(1.6)
	_restore_chen_order()
	camera_release()
	_end_t = 0.0
	_fade_db(_rain, -60.0, 3.0)                      # 一直淡到听不见（换章节重新载入时就不是被掐断的）


## 起飞用的船身：Wreck 前面（Wreck 换成土，盖在船身上面：扎进土里那截被土挡住）、带裁地面的 shader 和泛光
func _lift_setup() -> void:
	if _lift == null:
		_lift = Sprite2D.new()
		_lift.name = "LiftShip"
		_lift.texture = LIFT_TEX
		_lift.hframes = LIFT_N
		_lift.vframes = 4
		_lift.centered = false
		_lift.offset = -Vector2(LIFT_FRAME / 2)
		var sh := Shader.new()
		sh.code = CLIP_SHADER
		var m := ShaderMaterial.new()
		m.shader = sh
		_lift.material = m
		add_child(_lift)
		_lift_glow = SHIP_GLOW.new()
		_lift_glow.use_parent_material = true          # 泛光也按地面线裁（船还在土里时不画进地里）
		_lift_glow.full_speed = 20.0                   # 离地最快约 20 像素 / 秒 = 满亮
		_lift.add_child(_lift_glow)
		var meta = JSON.parse_string(FileAccess.get_file_as_string(LIFT_META)) if FileAccess.file_exists(LIFT_META) else null
		if meta is Dictionary:
			var hull: Dictionary = meta.get("hull", {})
			for k in hull:
				var h: Dictionary = hull[k]
				var tops := PackedInt32Array()
				var bots := PackedInt32Array()
				for v in h.get("top", []):
					tops.append(int(v) - LIFT_FRAME.y / 2 if int(v) >= 0 else -1)
				for v in h.get("bot", []):
					bots.append(int(v) - LIFT_FRAME.y / 2 if int(v) >= 0 else -1)
				_lift_hull[int(k)] = [tops, bots]
	move_child(_lift, wreck.get_index())
	_lift.modulate = wreck.modulate
	(_lift.material as ShaderMaterial).set_shader_parameter("clip_y", wreck.position.y)
	_lift_pos = wreck.position + WRECK_CENTER
	_lift_ang = float(LIFT_ANG0)
	_lift_row = 0
	_lift_hull_ang = 999
	_lift_glow.strength = 0.0
	_lift_glow.heat = 1.0                              # 起飞一直是热光（暖红，推进器那头最亮）
	_lift_glow.heat_goal = 1.0
	_lift_glow.hold = 0.0
	_lift_glow.hold_goal = 0.0
	_lift.visible = true
	wreck.texture = CRATER_TEX
	wreck.hframes = 2
	wreck.frame = 0
	_lift_show()


func _lift_show() -> void:
	var ai := clampi(roundi(_lift_ang), LIFT_ANG0, LIFT_ANG0 + LIFT_N - 1)
	_lift.frame = _lift_row * LIFT_N + (ai - LIFT_ANG0)
	_lift.position = _lift_pos.round()
	if ai != _lift_hull_ang and _lift_hull.has(ai):
		_lift_hull_ang = ai
		var h: Array = _lift_hull[ai]
		_lift_glow.set_hull(-LIFT_FRAME.x / 2, h[0], h[1])


func _lift_engine() -> Vector2:
	return _lift.position + LIFT_ENGINE.rotated(deg_to_rad(_lift_ang))


## 一块土：一像素，有重力，落到地面（floor）停住、慢慢淡掉（puffs.gd 的 floor）
func _drop_clod(p: Vector2, floor_y: float) -> void:
	puffs_front.burst(p, 1, puffs_front.PRESETS.clod.merged({"floor": floor_y - 1.0}))


# ======================================================================= 章节（scripts/chapter_flow.gd）
## 剧本 end_chapter 演完（森林：起飞、黑屏）以后：有下一章就带着状态换过去（返回 true，不出结束卡）。
## 测试（自动玩、乱玩、--dev_test、截图、命令行 --beat）默认不接，照旧出结束卡；加 --story_chain 才接。
func chapter_next() -> bool:
	var nxt := str(CHAPTER_GD.info(chapter).get("next", ""))
	if nxt == "" or not FileAccess.file_exists(str(CHAPTER_GD.info(nxt).get("story", ""))):
		return false
	var testing := _story_auto != "" or _fuzz > 0.0 or "--dev_test" in OS.get_cmdline_user_args() or _shot != "" \
		or _shots_dir != "" or _autoplay or _beat_cli
	if testing and not _story_chain:
		return false
	print("CHAPTER %s → %s" % [chapter, nxt])
	CHAPTER_GD.go(get_tree(), nxt)
	return true


## 进别的章节（不播开场 / 标题 / 坠毁）：森林的图层都藏起来，晨站到驾驶座，黑屏淡入，播这一章的入口 scene（play = false：跳节拍自己播）
func _start_chapter(play: bool) -> void:
	var info: Dictionary = CHAPTER_GD.info(chapter)
	_kill_cine()
	_hp_root.modulate.a = 0.0
	_title_root.visible = false
	for n in ["Sky", "Ridge", "Far", "ForestShadows", "Deep", "MidFar", "Mid", "Main", "PuffsBack", "Wreck", "Ship", "Alien", "Wood",
			"PuffsFront", "Front", "StoryProps", "StoryFogProps", "TreehouseFront", "Deer", "Snake"]:
		var node := get_node_or_null(n)
		if node is CanvasItem:
			(node as CanvasItem).visible = false
		elif node != null and node.has_method("set_visible"):
			node.call("set_visible", false)
	shafts.visible = false
	_rain.stop()
	_crackle.stop()
	chen.set_env("")
	var room := str(info.get("room", "forest"))
	story.world.set_room(room, true)
	var x: float = story.world.resolve("cockpit_seat")["x"] if room == "cockpit" else chen.position.x
	if story.world.is_stage(room):
		var sp := str(info.get("spawn", ""))
		x = story.world.resolve(sp)["x"] if sp != "" and story.world.has_marker(sp) else story.world.stage(room).walls().x + 60.0
	story._place(chen, x, room)
	chen.visible = true
	chen._set_facing(-1 if room == "cockpit" else 1)   # 驾驶舱：机头在左边，看着前窗
	_snap_camera()
	# 驾驶舱里低低的引擎声：一个播放器放整章（真循环，不重开），进出驾驶舱只淡音量（_hum_to；on_room_changed 跟着房间）
	var hum := "res://audio/sfx/flight_engine_loop.wav"
	if room == "cockpit" and ResourceLoader.exists(hum):
		_engine_hum = AudioStreamPlayer.new()
		_engine_hum.name = "EngineHum"                 # 复制出来的循环流没有路径，--qa_audio 认不出名字，节点名顶上
		_engine_hum.stream = _ambient_stream(hum)
		_engine_hum.bus = "SFX"
		_engine_hum.volume_db = -60.0
		add_child(_engine_hum)
		_engine_hum.play()
		_fade_db(_engine_hum, HUM_DB, 2.0)
	fade.color.a = 1.0
	_enter_play()
	_hud_burn.modulate.a = 0.0
	if story.world.is_stage(room) and play:
		# 河流篇开场（方案 5.2）：接飞行一「卡进狭窄的水道」——黑场 0.6 秒以内，镜头从水面缓缓抬到岸上
		var top := Vector2(_cam_target(), story.world_cam_y())
		camera_hold_at(top + Vector2(0, 60))
		fade_from_black(0.6)
		(func():
			await camera_pan(top, 2.4)
			camera_release()).call()
	else:
		fade_from_black(0.9)
	var start := str(info.get("start", ""))
	if play and start != "" and story.has_scene(start):
		story.play.call_deferred(start)


## F12「状态」页点一个还没设的 flag：从现在的样子接着把剧情瞬间过一遍到它（和 --beat 同一套 fast_forward，
## 前置的 flag、给 / 收的物品、NPC 位置、房间、桥、雾、当前目标都是真播出来的）。剧情在播、不能自由走、或者从现在走不到 → false
func dev_complete(flag: String) -> bool:
	if story.busy or not free_play() or StoryState.has(flag) or story.mech_wait:
		return StoryState.has(flag)       # 小游戏在等玩家互动（mech_wait）时也不补：用跳节拍
	story.ff = true
	story.dlg.instant = true
	if chapter != "forest":
		story.ff_stop = true
		story._ff_target = flag
	_dlg_hide(0.01)
	var ok: bool = await story.fast_forward(flag)
	_ff_done(flag, ok)
	on_room_changed()
	_hud_burn.modulate.a = 1.0 if Inventory.burn_total() > Inventory.base_burn or StoryState.fuel_on() else 0.0
	return ok


## 跳节拍 / dev_complete 快进完：收尾（进 PLAY、碰到章节结尾就播起飞、别的章节停在目标后面的接着播）
func _ff_done(flag: String, ok: bool) -> void:
	story.ff = false
	story.dlg.instant = false
	print("STORY_BEAT %s %s  flags=%s  items=%s  x=%.0f room=%s" % [flag, "ok" if ok else "NOT REACHED",
		", ".join(StoryState.flag_order), ", ".join(Inventory.owned), chen.position.x, story.world.room])
	chen.visible = chapter != "forest" or not StoryState.has("launched")
	if state != S.PLAY:
		_enter_play()
	var fb: Dictionary = story.dev_flashback_take()    # F12「闪回」按钮：跳完节拍从闪回前几步开始播（story_runner.gd FLASHBACK_DEV）
	if not fb.is_empty():
		story.ff_hit_end = false
		story.ff_resume = ""
		story.play.call_deferred(str(fb["scene"]), true, int(fb["index"]))
	if story.ff_hit_end:
		story.ff_hit_end = false
		story.play_end()
	elif story.ff_resume != "":
		var rs: String = story.ff_resume         # 别的章节：停在目标后面，剩下的一段正常播
		story.ff_resume = ""
		story.play.call_deferred(rs)
	story.ff_stop = false


## --beat=flag：坠毁跳过，剧情瞬间过一遍到那个 flag
func _jump_beat(flag: String) -> void:
	story.ff = true
	story.dlg.instant = true
	if chapter == "forest":
		_skip_to_title()
		_start_crash()
		_skip_crash()
	else:
		# 别的章节：入口 scene 瞬间播一遍（入口一路 goto 下去的都算，可能比目标多走几步），再按 hotspot 往下跳
		var st0 := str(CHAPTER_GD.info(chapter).get("start", ""))
		story.ff_stop = true
		story._ff_target = flag
		if st0 != "" and story.has_scene(st0) and not StoryState.has(flag):
			await story.play(st0, false)
	_dlg_hide(0.01)
	var ok: bool = await story.fast_forward(flag)
	_ff_done(flag, ok)
	for n in _dbg_hide:
		var node := find_child(n, true, false)
		if node is CanvasItem:
			(node as CanvasItem).visible = false
		elif node != null and node.has_method("set_visible"):
			node.call("set_visible", false)
	if not is_nan(_dbg_chen_x):
		chen.position.x = _dbg_chen_x
		chen.position.y = round(chen.ground_fn.call(_dbg_chen_x)) + 1
		_snap_camera()
	if _dbg_bag != "":
		_toggle_bag()
		var i := Inventory.owned.find(_dbg_bag)
		if i >= 0:
			_bag_select(i)
			_bag_slots[i].grab_focus()
			if _dbg_bag_line >= 0:
				(func(): _desc_goto(_dbg_bag_line)).call_deferred()
	on_room_changed()
	_hud_burn.modulate.a = 1.0 if Inventory.burn_total() > Inventory.base_burn or StoryState.fuel_on() else 0.0
	_stage_t = 0.0


# ======================================================================= 调试：跳段、截图
func _jump(stage: String) -> void:
	match stage:
		"headphones":
			pass
		"title":
			_skip_to_title()
		"settings":
			_skip_to_title()
			_open_settings()
		"crash":
			_skip_to_title()
			_start_crash()
		"play":
			_skip_to_title()
			_start_crash()
			_skip_crash()
		"wood", "burn":
			_skip_to_title()
			_start_crash()
			_skip_crash_instant()
			_dlg_hide(0.01)
			chen.position.x = WOOD_X - 40.0
			cam.position.x = chen.position.x + LOOK
			_walk_target = WOOD_X
		"bag":
			_skip_to_title()
			_start_crash()
			_skip_crash_instant()
			_dlg_hide(0.01)
			wood.visible = false
			Inventory.add("glowing_wood")
			on_inventory_changed()
			_update_hud()
			_hud_burn.modulate.a = 1.0
			_bag_btn.visible = true
			_bag_btn.modulate.a = 1.0
			chen.position.x = WOOD_X - 8.0
			cam.position.x = chen.position.x + LOOK
			_toggle_bag()
	_stage_t = 0.0


# ======================================================================= 调试：乱玩（--story_fuzz）和卡死检测
func toggle_dev() -> void:
	if not OS.is_debug_build():
		return
	if _dev == null:
		_make_dev(true)
	else:
		_dev.toggle()


func _make_dev(show: bool) -> void:
	_dev = DEV_GD.new()
	_dev.name = "DevPanel"
	_dev.level = self
	_dev.visible = show
	add_child(_dev)
	var tab := _dev_tab
	if free_roam != "" and not " ".join(OS.get_cmdline_user_args()).contains("--dev_tab="):
		tab = 4                               # 自由探索：一打开就是「探索」页
	_dev.call("_set_tab", tab)


## 面板「传送」：晨直接到 marker（room_* 进屋、别的出屋），剧情在播就先不动
func dev_teleport(name: String) -> void:
	if story.busy:
		return
	var r: Dictionary = story.world.resolve(name)
	if not r["ok"]:
		return
	var room: String = "treehouse" if name.begins_with("room_") else ("cockpit" if name.begins_with("cockpit_") else "forest")
	if story.world.room_of_marker(name) != "":
		room = story.world.room_of_marker(name)
	elif not story.world.stages.is_empty() and room == "forest":
		return                              # 多房间章节：森林的 marker 不传
	if (room == "cockpit") != (story.world.room == "cockpit"):
		return                              # 驾驶舱和森林不在同一章：不传送过去
	story._teleport(room, float(r["x"]), [], true)
	_walk_target = NAN


# ======================================================================= 调试：自由探索（F12「探索」/ --free=）
## 进哪个场景：面板选的（DEV_FREE_META，重新载入后还在）> 命令行 --free=（只第一次）。章节跟着场景走（CHAPTER_META + PICK_META）
func _free_pick() -> void:
	if not OS.is_debug_build():
		return
	if _free_cli != "" and not Engine.has_meta(FREE_CLI_META):
		Engine.set_meta(FREE_CLI_META, true)
		if FREE_ROOMS.has(_free_cli):
			Engine.set_meta(DEV_FREE_META, _free_cli)
		elif ResourceLoader.exists("res://scenes/%s.tscn" % _free_cli):
			_open_test_scene.call_deferred("res://scenes/%s.tscn" % _free_cli)      # 小样场景：直接换过去（Esc 回来）
		else:
			push_warning("--free= 没有这个场景：%s（有：%s）" % [_free_cli, ", ".join(FREE_ROOMS.keys())])
	if not Engine.has_meta(DEV_FREE_META):
		return
	var fid := str(Engine.get_meta(DEV_FREE_META))
	var fch := str(Engine.get_meta(DEV_FREE_CH_META)) if Engine.has_meta(DEV_FREE_CH_META) else str(FREE_ROOMS.get(fid, ""))
	if not CHAPTER_GD.CHAPTERS.has(fch):
		return
	free_roam = fid
	Engine.set_meta(CHAPTER_GD.CHAPTER_META, fch)
	Engine.set_meta(CHAPTER_GD.PICK_META, true)
	for m in [DEV_BEAT_META, DEV_STAGE_META]:
		if Engine.has_meta(m):
			Engine.remove_meta(m)


## 不播开场、标题、坠毁、章节入口 scene：晨直接站在场景里能走。剧本关掉（story.free_roam：play / trigger / 卡关提示都不做），
## hotspot 换成只有进出口的一套（_free_exits），按 E / 点它直接换过去
func _start_free() -> void:
	story.free_roam = true
	_beat = ""
	_debug_stage = ""
	_kill_cine()
	_hp_root.modulate.a = 0.0
	_title_root.visible = false
	if chapter == "forest":
		fade.color.a = 0.0
		if not _rain.playing:
			_rain.play()
		_fade_db(_rain, RAIN_DB, 1.0)
		_show_wreck()
		chen.visible = true
		_chen_stand()
		chen._set_facing(1)
		story._place(chen, CHEN_X, "forest")
		_enter_play()
	else:
		_start_chapter(false)
	story.hotspots.defs = _free_exits()
	_free_spawn(free_roam)
	if _free_pos != "":
		free_place(_free_pos)
	elif not is_nan(_dbg_chen_x):
		story._place(chen, _dbg_chen_x, story.world.room)
		_snap_camera()
	for n in _dbg_hide:
		var node := find_child(n, true, false)
		if node is CanvasItem:
			(node as CanvasItem).visible = false
	_stage_t = 0.0
	var w := free_walls()
	print("FREE_ROAM %s chapter=%s room=%s walk=%d..%d x=%d exits=%d" % [free_roam, chapter, story.world.room, w.x, w.y,
		chen.position.x, story.hotspots.defs.size()])
	if "--free_npcs" in OS.get_cmdline_user_args():
		free_show_npcs(true)
	if _free_check:
		_free_tour.call_deferred()


## 一开始站哪：forest = 坠毁现场；river = 河岸的出舱口（章节的 spawn）；别的房间名（拍截图用）= 那个房间的左头（小屋：中间）
func _free_spawn(id: String) -> void:
	var w: Node2D = story.world
	if id in ["forest", "river", "cockpit"] and str(FREE_ROOMS[id]) == chapter:
		return                                     # 已经在 _start_free / _start_chapter 里站好了
	id = str(FREE_ALIAS.get(id, id))
	var x := chen.position.x
	if id == "treehouse":
		var hw: Vector2 = w.house["walk"]
		x = (hw.x + hw.y) / 2.0
	elif w.is_stage(id):
		var sg: Node2D = w.stage(id)
		if sg.has_levels():
			sg.chen_lv = 0
			sg.chen_stair = -1
		var fw := _free_walls_of(sg)
		x = (fw.x + fw.y) / 2.0 if sg.is_house else fw.x + 40.0
	story._teleport(id, x, [], true)
	_walk_target = NAN
	_hum_to(id == "cockpit", 0.8)              # 终章从驾驶舱起（_start_chapter 开的引擎声），探索直接站到别的房间：淡掉，不掐断
	_enter_play()


## 驾驶舱引擎声淡进 / 淡出（一直在放，只改音量；重复进出不重开，也不会两个 tween 抢）
func _hum_to(on: bool, sec := 1.0) -> void:
	if _engine_hum == null or not is_instance_valid(_engine_hum) or _hum_done:
		return
	_fade_db(_engine_hum, HUM_DB if on else -60.0, sec)


## 往前一冲以后（船落地 / 离开了）：引擎声淡掉，这一章不再回来——尾声回停着的驾驶舱（e1_phone，窗外 yard_parked）不该再响
func hum_done() -> void:
	_hum_to(false, 1.6)
	_hum_done = true


## 进出口：剧本里 scene 会 fade_to 到别的房间 / 森林另一段的 hotspot（同一个地方、同一个去处只留一个；不看 need / not，
## 第一个 fade_to 就是去处），room.json 里带 x 的 portal（仓库回旧街这种剧本里没有点的），多层小屋每段楼梯的两头（上楼 / 下楼）。
## 去驾驶舱（起飞）、走进去就触发的（trigger:"enter"）不算。返回 hotspot 的 defs：{id, at, room, label, free_to | free_stairs}
func _free_exits() -> Array:
	var w: Node2D = story.world
	var out: Array = []
	var seen := {}
	for h in story.all_hotspot_defs:            # 旧流程退休的点（retired）也算：自由探索照旧能进出树屋、回旧路
		if not h is Dictionary or story.hotspots.is_enter(h) or h.get("at") == null:
			continue
		var f := _first_fade(str(h.get("scene", "")), {})
		var src := str(h.get("room", "forest"))
		var dst := str(f.get("room", ""))
		if dst == "" or dst == "cockpit" or src == "cockpit":
			continue
		var fr: Dictionary = w.resolve(f.get("at", 0))
		var hr: Dictionary = w.resolve(h["at"])
		if not fr["ok"] or not hr["ok"]:
			continue
		if dst == src and (w.is_stage(src) or w.area_of(float(fr["x"])) == w.area_of(float(hr["x"]))):
			continue                                   # 同一个房间、同一段：不是换地方
		var key := "%s|%s|%s|%s" % [src, str(h["at"]), dst, w.area_of(float(fr["x"])) if dst == "forest" else ""]
		if seen.has(key):
			continue
		seen[key] = true
		seen["%s>%s" % [src, dst]] = true
		out.append({"id": "free_exit_%d" % out.size(), "at": h["at"], "room": src, "label": h.get("label", {"zh": dst, "en": dst}),
			"free_to": {"room": dst, "at": f.get("at", 0)}})
	for r in w.stages:
		var sg: Node2D = w.stages[r]
		for pt in sg.portals():
			if not pt is Dictionary or not pt.has("x") or seen.has("%s>%s" % [r, str(pt.get("to", ""))]):
				continue
			var to := str(pt.get("to", ""))
			if w.stage(to) == null:
				continue
			seen["%s>%s" % [r, to]] = true
			var nm := _free_room_name(to)
			out.append({"id": "free_exit_%d" % out.size(), "at": sg.origin.x + float(pt["x"]), "room": str(r),
				"label": {"zh": nm, "en": to}, "free_to": {"room": to, "at": str(pt.get("at", ""))}})
		if sg.has_levels():
			for si in sg._stairs.size():
				var st: Dictionary = sg._stairs[si]
				for e in [[st["a"], st["xa"], st["b"]], [st["b"], st["xb"], st["a"]]]:
					var nm := "%s%s_%d_%d" % [FREE_STAIR, r, si, int(e[0])]
					sg.markers[nm] = float(e[1])
					sg._marker_lv[nm] = int(e[0])
					w.markers[nm] = sg.origin.x + float(e[1])
					w._marker_room[nm] = str(r)
					var up: bool = int(e[2]) > int(e[0])
					out.append({"id": "free_exit_%d" % out.size(), "at": nm, "room": str(r),
						"label": {"zh": "上楼" if up else "下楼", "en": "Upstairs" if up else "Downstairs"},
						"free_stairs": int(e[2]) - int(e[0])})
	return out


## 房间的中文名（data/dev_names.json 的 rooms，没有就原 id）
func _free_room_name(r: String) -> String:
	var d = JSON.parse_string(FileAccess.get_file_as_string("res://data/dev_names.json"))
	if d is Dictionary and d.get("rooms", {}) is Dictionary:
		return str(d["rooms"].get(r, r))
	return r


## scene 里（顺着 goto / if 往下）第一个 fade_to：{room, at}；没有 = {}
func _first_fade(sid: String, seen: Dictionary) -> Dictionary:
	if sid == "" or seen.has(sid) or not story.scenes.has(sid):
		return {}
	seen[sid] = true
	for st in story.scenes[sid]:
		if not st is Dictionary:
			continue
		var d := str(st.get("do", ""))
		if d == "fade_to":
			return {"room": str(st.get("room", "forest")), "at": st.get("at", 0)}
		var nx: Array = []
		if d == "goto":
			nx = [str(st.get("scene", ""))]
		elif d == "if":
			nx = [str(st.get("then", "")), str(st.get("else", ""))]
		for n in nx:
			var f := _first_fade(n, seen)
			if not f.is_empty():
				return f
	return {}


## 按 E / 点了一个进出口：上下楼就沿石阶走过去；别的直接换过去（剧本的 fade_to 那套转场：小屋前墙、竖直平移、黑一下）
func _free_use(p: Dictionary) -> void:
	var h: Dictionary = p["h"]
	chen.auto_dir = 0.0
	_walk_target = NAN
	_pending_hs = {}
	story.hotspots.pressed(p)
	_sfx("tick", -12.0, 1.25)
	if h.has("free_stairs"):
		free_stairs(int(h["free_stairs"]))
		return
	if not h.has("free_to"):
		return
	story.busy = true
	story_begin(false)
	await story._fade_to(h["free_to"])
	if not is_inside_tree():
		return
	story.busy = false
	story_end()


## 自由探索能走的左右：剧情加的墙（walk_when、小游戏改的范围、导绳、倒木、塌陷口）都不算。
## 森林还是两段（旧路段一直到林间空地的尽头 / 树屋段），中间靠入口换过去
func free_walls() -> Vector2:
	var w: Node2D = story.world
	var sg: Node2D = w.cur_stage()
	if sg != null:
		return _free_walls_of(sg)
	if w.in_room() or w.room == "cockpit":
		return w.walls(chen.position.x)
	if chen.position.x < w.area_split():
		return Vector2(w.mx("wall_left"), _free_a_end())
	return Vector2(w.b_start(), w.mx("wall_right"))


## 旧路段的右头（搭了桥的样子：林间空地的尽头）
func _free_a_end() -> float:
	var w: Node2D = story.world
	return w.mx("wall_glade") if w.markers.has("wall_glade") else w.mx("wall_road")


func _free_walls_of(sg: Node2D) -> Vector2:
	var v: Vector2 = sg._v2(sg.cfg.get("walk", [16, sg.size.x - 16]), Vector2(16, sg.size.x - 16))
	if sg.has_levels():
		v = sg.level_walk(sg.chen_lv)
		if sg.chen_stair >= 0:
			var st: Dictionary = sg._stairs[sg.chen_stair]
			v = Vector2(minf(st["xa"], st["xb"]), maxf(st["xa"], st["xb"]))
	return Vector2(sg.origin.x + v.x, sg.origin.x + v.y)


## 一键到左头 / 中间 / 右头（left / mid / right；--chen_x= 拍截图用）
func free_place(where: String) -> void:
	var w := free_walls()
	var x := (w.x + w.y) / 2.0
	if where == "left":
		x = w.x + 12.0
	elif where == "right":
		x = w.y - 12.0
	_walk_target = NAN
	story._place(chen, x, story.world.room)
	_snap_camera()


## 多层小屋：沿石阶走到上一层 / 下一层（dir = 1 / −1）。没有爬楼梯的帧，走路动画沿斜线走（和剧情里 _lv_walk 一样）
func free_stairs(dir: int) -> void:
	var sg: Node2D = story.world.cur_stage()
	if sg == null or not sg.has_levels() or _free_climb:
		return
	var route: Array = sg.route(sg.chen_lv, sg.chen_lv + dir)
	if route.is_empty():
		return
	_free_climb = true
	for e in route:
		await _free_walk(float(e["x0"]))
		if not _free_climb:
			return
		sg.chen_stair = int(e["si"])
		await _free_walk(float(e["x1"]))
		if not _free_climb:
			return
		sg.chen_stair = -1
		sg.chen_lv = int(e["to"])
	_free_climb = false


func _free_walk(x: float) -> void:
	walk_to(x)
	var t := 0.0
	while not is_nan(_walk_target) and t < 10.0 and _free_climb:
		await get_tree().process_frame
		if not is_inside_tree():
			return
		t += get_process_delta_time()
	_walk_target = NAN
	chen.auto_dir = 0.0
	chen.position.x = round(x)                 # 被方向键打断也落到楼梯口，不停在楼梯半路


## 每帧：目标、燃料、背包按钮都藏着；角色和路人按 free_npcs 藏 / 显示
func _free_tick() -> void:
	_hud_burn.modulate.a = 0.0
	_bag_btn.visible = false
	for n in free_people():
		if not free_npcs:
			(n as CanvasItem).visible = false


## 场景里的人：剧本的角色（鹿、弥洛、妮芙、阿汀……）+ 房间 walkers 路人（+ 森林的外星人同伴）
func free_people() -> Array:
	var out: Array = []
	for n in [story.deer, story.miluo, alien]:
		if n != null:
			out.append(n)
	for k in story.npcs:
		out.append(story.npcs[k])
	for r in story.world.stages:
		for wk in story.world.stages[r].walkers:
			out.append(wk["npc"])
	return out


## 面板「角色」：路人照常走；本章剧本里的角色一字排开站在晨右边（看图用，森林的鹿 / 弥洛也算，河流篇里不放它们）
func free_show_npcs(on: bool) -> void:
	free_npcs = on
	if not on:
		_free_tick()
		return
	for r in story.world.stages:
		for wk in story.world.stages[r].walkers:
			(wk["npc"] as CanvasItem).visible = true
	var names: Array = story._npc_names.keys()
	if not story.world.is_stage(story.world.room) and story.world.room != "cockpit":
		names = ["deer", "miluo"] + names
	var w := free_walls()
	var x := chen.position.x + 40.0
	for who in names:
		var n: Node2D = story.npc(str(who))
		if n == null or n == chen:
			continue
		if x > w.y - 10.0:
			x = w.x + 10.0
		story._place(n, x, story.world.room)
		n.visible = true
		n.modulate.a = 1.0
		x += 34.0


## --free_check：按进出口把这一章走一遍（真的走过去、真的按 E 那条路 _interact；走到边上的出口就顶着走过去），
## 每一步打印 FREE_TOUR（到没到），一路记有没有对话 / 点选 / 目标 / 剧情的 hotspot 出来过
const FREE_TOUR := {
	"forest": ["edge:right", "treehouse", "forest", "edge:left"],
	"river": ["river_home", "up", "up", "down", "down", "river_bank", "market", "stairwell", "oldstreet", "warehouse", "oldstreet", "southbridge",
		"edge:left"],
}


func _free_tour() -> void:
	await get_tree().create_timer(1.2).timeout
	if _free_shots != "":
		DirAccess.make_dir_recursive_absolute(_free_shots)
	var seen: Array = []
	var ok := 0
	var steps: Array = Array(_free_steps) if not _free_steps.is_empty() else FREE_TOUR.get(chapter, [])
	await _free_shot(0, "start")
	for i in steps.size():
		var step := str(steps[i])
		var room0: String = story.world.room
		var area0: String = story.world.area_of(chen.position.x)
		var sg: Node2D = story.world.cur_stage()
		var lv0: int = sg.chen_lv if sg != null else -1
		var how := await _free_tour_step(step, seen)
		var sg2: Node2D = story.world.cur_stage()
		var good := false
		match step:
			"up":
				good = sg2 != null and sg2.chen_lv == lv0 + 1
			"down":
				good = sg2 != null and sg2.chen_lv == lv0 - 1
			"edge:left", "edge:right":
				good = story.world.room != room0 or story.world.area_of(chen.position.x) != area0
			_:
				good = story.world.room == step
		if good:
			ok += 1
		print("FREE_TOUR %d %s: %s（%s）room=%s 层=%d x=%d 森林的角色/动物: %s" % [i + 1, step, "ok" if good else "FAILED", how, story.world.room,
			sg2.chen_lv if sg2 != null else -1, chen.position.x, _forest_cast_seen()])
		await _free_shot(i + 1, step.replace(":", "_"))
	print("FREE_CHECK %s 走了 %d / %d 步 ok，一路出现过: %s" % [chapter, ok, steps.size(), "、".join(seen) if not seen.is_empty() else "无"])
	get_tree().quit()


func _free_shot(i: int, nm: String) -> void:
	if _free_shots == "":
		return
	await get_tree().process_frame
	_save(_free_shots.path_join("%s_%02d_%s.png" % [chapter, i, nm]))


## 一步：走到去 step 的那个进出口、按 E（_interact）；edge:left / right = 顶着那一头走过去。等转场做完（story.busy 落下）
func _free_tour_step(step: String, seen: Array) -> String:
	var how := ""
	if step.begins_with("edge:"):
		var dir := -1.0 if step == "edge:left" else 1.0
		var w := free_walls()
		walk_to((w.x - 60.0) if dir < 0.0 else (w.y + 60.0))
		how = "顶着%s边走" % ("左" if dir < 0.0 else "右")
	else:
		var target: Dictionary = {}
		for p in story.hotspots.available():
			var h: Dictionary = p["h"]
			if (step == "up" and int(h.get("free_stairs", 0)) > 0) or (step == "down" and int(h.get("free_stairs", 0)) < 0) \
					or str((h.get("free_to", {}) as Dictionary).get("room", "")) == step:
				if not story.hotspots.same_level(h):
					continue
				if target.is_empty() or absf(float(p["x"]) - chen.position.x) < absf(float(target["x"]) - chen.position.x):
					target = p
		if target.is_empty():
			return "这里没有去那儿的进出口"
		how = "E %s" % story.txt(target["h"].get("label", {}))
		_pending_hs = target                    # 和鼠标点了它一样：走过去，到了就互动
		walk_to(float(target["x"]))
	var t := 0.0
	var started := false
	while t < 60.0:
		await get_tree().process_frame
		t += get_process_delta_time()
		_free_watch(seen)
		if step.begins_with("edge:") and not started:
			chen.auto_dir = -1.0 if step == "edge:left" else 1.0     # 顶着那一头一直走（像按住方向键）
		if story.busy or _free_climb:
			started = true
		elif started or (not story.busy and is_nan(_walk_target) and _pending_hs.is_empty() and not _free_climb and t > 0.6 \
				and not step.begins_with("edge:")):
			break
	await get_tree().create_timer(0.6).timeout
	return how


func _free_watch(seen: Array) -> void:
	var near: Dictionary = story.hotspots.near
	for k in [["对话", story.dlg.is_open()], ["点选", story.dlg.picking() or story.dlg.menu_open()],
			["剧情 hotspot", not near.is_empty() and not (near["h"] as Dictionary).has("free_to") and not (near["h"] as Dictionary).has("free_stairs")],
			["目标 / 燃料", _hud_burn.modulate.a > 0.01], ["背包按钮", _bag_btn.visible], ["剧情在播", story.played_order.size() > 0]]:
		if k[1] and not seen.has(k[0]):
			seen.append(k[0])


func _fuzz_key(k: int, pressed: bool) -> void:
	var e := InputEventKey.new()
	e.keycode = k as Key
	e.physical_keycode = k as Key
	e.pressed = pressed
	Input.parse_input_event(e)


func _fuzz_tick(delta: float) -> void:
	_fuzz_t += delta
	if state == S.PLAY or story.free_walk:
		_fuzz_xmin = minf(_fuzz_xmin, chen.position.x)
		_fuzz_xmax = maxf(_fuzz_xmax, chen.position.x)
	if _fuzz_t >= _fuzz:
		print("FUZZ_DONE seed=%d t=%.0f softlocks=%d state=%s x=%.0f..%.0f scenes=%d flags=%s" % [_fuzz_rng.seed, _fuzz_t, softlocks,
			S.keys()[state], _fuzz_xmin, _fuzz_xmax, story.played_order.size(), ", ".join(StoryState.flag_order)])
		get_tree().quit(1 if softlocks > 0 else 0)
		_fuzz = 0.0
		return
	if _fuzz_hold != 0:
		_fuzz_hold_t -= delta
		if _fuzz_hold_t <= 0.0:
			_fuzz_key(_fuzz_hold, false)
			_fuzz_hold = 0
	_fuzz_next -= delta
	if _fuzz_next > 0.0:
		return
	_fuzz_next = _fuzz_rng.randf_range(0.05, 0.7)
	var r := _fuzz_rng.randf()
	if r < 0.45:
		# 按住方向键一会儿（往右多一点，才走得远）
		if _fuzz_hold != 0:
			_fuzz_key(_fuzz_hold, false)
		var keys := [KEY_RIGHT, KEY_RIGHT, KEY_D, KEY_LEFT, KEY_A]
		_fuzz_hold = keys[_fuzz_rng.randi() % keys.size()]
		_fuzz_hold_t = _fuzz_rng.randf_range(0.1, 2.8)
		_fuzz_key(_fuzz_hold, true)
	elif r < 0.72:
		var keys := [KEY_E, KEY_SPACE, KEY_ENTER, KEY_Z]
		var k: int = keys[_fuzz_rng.randi() % keys.size()]
		_fuzz_key(k, true)
		_fuzz_key(k, false)
	elif r < 0.8:
		_fuzz_key(KEY_TAB, true)
		_fuzz_key(KEY_TAB, false)
	elif r < 0.84:
		_fuzz_key(KEY_ESCAPE, true)
		_fuzz_key(KEY_ESCAPE, false)
	elif r < 0.88:
		var k: int = [KEY_UP, KEY_DOWN][_fuzz_rng.randi() % 2]
		_fuzz_key(k, true)
		_fuzz_key(k, false)
	else:
		# 乱点：一半点在能互动的东西上（不在范围里就会先走过去），一半画面上随便一点
		var e := InputEventMouseButton.new()
		e.button_index = MOUSE_BUTTON_LEFT
		e.position = Vector2(_fuzz_rng.randf_range(0, 480), _fuzz_rng.randf_range(20, 260))
		var av: Array = story.hotspots.available()
		if not av.is_empty() and _fuzz_rng.randf() < 0.5:
			var p: Dictionary = av[_fuzz_rng.randi() % av.size()]
			e.position = story.hotspots.click_rect(p).get_center() - cam_left()
		e.global_position = e.position
		e.pressed = true
		get_viewport().push_input(e, true)
		var e2 := e.duplicate() as InputEventMouseButton
		e2.pressed = false
		get_viewport().push_input(e2, true)


## 卡死：该能走的时候晨收不到输入超过 3 秒，或者剧情某一步停了 20 秒还没有人在等的东西
func _softlock_tick(delta: float) -> void:
	var panels := _settings.visible or _bag.visible
	var dir := Input.get_axis("ui_left", "ui_right")
	var w: Vector2 = story.world.walls(chen.position.x)
	var pushing_wall := (chen.position.x <= w.x + 1.0 and dir < 0.0) or (chen.position.x >= w.y - 1.0 and dir > 0.0)
	var why := ""
	if story.ended or state in [S.HEADPHONES, S.INTRO, S.TITLE, S.CRASH]:
		why = ""
	elif state == S.PLAY and not panels and not story.busy and fade.color.a < 0.01 and not chen.input_enabled and not pushing_wall:
		why = "自由走但晨收不到输入"
	elif _free() and story.free_walk and not chen.input_enabled and not pushing_wall and not panels:
		why = "鹿带路时晨收不到输入"
	elif state == S.CINE and not story.busy and _seq.is_empty() and is_nan(_cine_target):
		why = "过场状态但没有剧情在播"
	elif story.busy and not story.free_walk and not story.dlg.is_open() and not story.dlg.picking() and story.cockpit_ui == null and not story.closeup_ui.is_open() and story.step_t > 20.0:
		why = "剧情一步停了 20 秒（STUCK_SCENE）"
	if why == "":
		_lock_t = 0.0
		_lock_reported = false
		return
	_lock_t += delta
	if _lock_t > 3.0 and not _lock_reported:
		_lock_reported = true
		softlocks += 1
		print("SOFTLOCK %s | t=%.1f state=%s busy=%s scene=%s step=%d free_walk=%s input=%s wall_block=%s panels=%s fade=%.2f x=%.0f room=%s seq=%d flags=%s" % [
			why, _fuzz_t, S.keys()[state], story.busy, story._cur_scene, story.step_i, story.free_walk, chen.input_enabled,
			_wall_block, panels, fade.color.a, chen.position.x, story.world.room, _seq.size(), ", ".join(StoryState.flag_order)])


## 跳段用：坠毁跳过，剧本的 intro 瞬间过完（直接能走）
func _skip_crash_instant() -> void:
	story.ff = true
	story.dlg.instant = true
	_skip_crash()
	story.ff = false
	story.dlg.instant = false


## --ui_tour=目录（夜测）：耳机页 → 标题 → 制作人员（每秒一张）→ 关掉 → 设置面板 → 关掉 → 英文标题，拍完退出。
var _ui_tour := ""
var _ui_touring := false


func _ui_tour_run() -> void:
	_ui_touring = true
	var d := _ui_tour
	var shot := func(n: String) -> void:
		RenderingServer.force_draw(false)
		var img := get_viewport().get_texture().get_image()
		if img.get_width() != 480:
			img.resize(480, 270, Image.INTERPOLATE_NEAREST)
		img.save_png(d.path_join(n + ".png"))
	shot.call("00_headphones")
	await get_tree().create_timer(1.0).timeout
	_leave_headphones()
	for i in 6:
		await get_tree().create_timer(0.5).timeout
		shot.call("01_intro_%d" % i)
	while state != S.TITLE:
		await get_tree().process_frame
	await get_tree().create_timer(1.5).timeout
	shot.call("02_title")
	_open_credits()
	for i in 22:
		await get_tree().create_timer(1.0).timeout
		shot.call("03_credits_%02d" % i)
	if _credits_page != null:
		_credits_page.close()
	await get_tree().create_timer(1.0).timeout
	shot.call("04_title_back")
	_open_settings()
	await get_tree().create_timer(0.6).timeout
	shot.call("05_settings")
	_close_panels()
	await get_tree().create_timer(0.6).timeout
	shot.call("06_title_after_settings")
	GameSettings.set_lang("en")
	await get_tree().create_timer(0.8).timeout
	shot.call("07_title_en")
	_open_settings()
	await get_tree().create_timer(0.6).timeout
	shot.call("08_settings_en")
	_close_panels()
	_open_credits()
	await get_tree().create_timer(3.0).timeout
	shot.call("09_credits_en")
	print("UI_TOUR_DONE")
	get_tree().quit()


func _debug_tick() -> void:
	if _ui_tour != "" and not _ui_touring and state == S.HEADPHONES and _state_t > 0.5:
		_ui_tour_run()
	if _browse > 0 and state == S.TITLE and _state_t > 0.5 and not Engine.has_meta("level_forest_browsed"):
		Engine.set_meta("level_forest_browsed", true)
		_open_test_scene(TEST_SCENES[KEY_F1 + _browse - 1], 2.5)
		_browse = 0
	elif _browse_out != "" and Engine.has_meta("level_forest_browsed") and state == S.TITLE and _state_t > 2.0:
		_save(_browse_out.path_join("back.png"))
		get_tree().quit()
	if _story_auto != "" and not _autoplay:
		if state == S.HEADPHONES and _state_t > 1.0:
			_leave_headphones()
		elif state == S.TITLE and _state_t > 1.2:
			_on_start()
	if _autoplay:
		if state == S.HEADPHONES and _state_t > 1.0:
			_leave_headphones()
		elif state == S.TITLE and _state_t > 1.2:
			_on_start()
		elif state == S.PLAY and _state_t > 2.0 and wood.visible and is_nan(_walk_target):
			_walk_target = WOOD_X
	if _shot != "" and _stage_t >= _shot_at:
		_save(_shot)
		_shot = ""
		get_tree().quit()
	if _shots_dir != "" and _frame >= _shots_start and (_frame - _shots_start) % _shots_every == 0:
		_save(_shots_dir.path_join("shot_%04d.png" % _shots_saved))
		_shots_saved += 1
		if _shots_saved >= _shots_count:
			get_tree().quit()


## n×n 的像素叉（两条 1 像素宽的对角线），当关闭按钮的图标
static func _pixel_cross(n: int, c: Color) -> ImageTexture:
	var img := Image.create_empty(n, n, false, Image.FORMAT_RGBA8)
	for i in n:
		img.set_pixel(i, i, c)
		img.set_pixel(n - 1 - i, i, c)
	return ImageTexture.create_from_image(img)


## --win=宽x高：退出全屏（macOS 退全屏有动画，等一下再改大小）
func _dbg_win(v: String) -> void:
	var wh := v.split("x")
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	for i in 3:
		await get_tree().create_timer(0.4).timeout
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		DisplayServer.window_set_size(Vector2i(int(wh[0]), int(wh[1])))
	print("WIN size=%s visible=%s aspect=%d" % [get_window().size, get_viewport().get_visible_rect().size, get_window().content_scale_aspect])


func _save(path: String) -> void:
	RenderingServer.force_draw(false)
	get_viewport().get_texture().get_image().save_png(path)


# ======================================================================= 调试：场景浏览（只在 debug 构建）
const BACK_META := "level_forest_back_to_title"


func _open_test_scene(path: String, auto_back := 0.0) -> void:
	if not ResourceLoader.exists(path):
		push_warning("没有这个测试场景：" + path)
		return
	var b := SceneBrowser.new()
	b.name = "SceneBrowser"
	b.scene_name = path.get_file().get_basename()
	b.auto_back = auto_back
	if auto_back > 0.0 and _browse_out != "":
		b.shot = _browse_out.path_join("scene.png")
	get_tree().root.add_child(b)
	get_tree().change_scene_to_file(path)


## 挂在 root 下（换场景不会被删），一直排在 root 的最后一个，所以 Esc 比测试场景自己先收到。
## Esc：回第一关的标题界面，然后把自己删掉。左上角一行很淡的小字提示。
class SceneBrowser extends Node:
	var scene_name := ""
	var auto_back := 0.0      # 调试（--browse）：过几秒自己回去，回去前存一张图到 shot
	var shot := ""
	var _t := 0.0

	func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		var layer := CanvasLayer.new()
		layer.layer = 120
		add_child(layer)
		var l := Label.new()
		l.theme = UITheme.get_theme()
		l.text = scene_name + "   Esc: back to title"
		l.add_theme_color_override("font_color", Color(0.75, 0.85, 0.8, 0.45))
		l.position = Vector2(6, 4)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		layer.add_child(l)
		# 几秒后淡掉，免得一直压在测试场景自己的界面上（飞行的进度条就在左上角）
		create_tween().tween_property(l, "modulate:a", 0.0, 1.0).set_delay(3.0)

	func _process(delta: float) -> void:
		var p := get_parent()
		if p != null and get_index() != p.get_child_count() - 1:
			p.move_child(self, -1)
		if auto_back > 0.0:
			_t += delta
			if _t >= auto_back:
				if shot != "":
					RenderingServer.force_draw(false)
					get_viewport().get_texture().get_image().save_png(shot)
				_back()

	func _input(e: InputEvent) -> void:
		if e is InputEventKey and e.pressed and not e.echo and e.keycode == KEY_ESCAPE:
			get_viewport().set_input_as_handled()
			_back()

	func _back() -> void:
		get_tree().paused = false
		Engine.set_meta(BACK_META, true)
		get_tree().change_scene_to_file(SELF_SCENE)
		queue_free()
